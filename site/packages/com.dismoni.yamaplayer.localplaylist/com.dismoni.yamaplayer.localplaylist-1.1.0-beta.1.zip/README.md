# DM YamaPlayer Local Playlist

YamaPlayer 1.5.18 のプレイリスト画面に、プレイヤー個人の「ローカルプレイリスト」を追加するアドオンです。ローカルプレイリストは、ワールドごとの自分の保存データ（VRChat の Persistence）に入り、次に入室したときにも残ります。再生・キュー・順送りは YamaPlayer 自身の仕組みを使います。YamaPlayer 本体のファイルは変更しません。

- 利用規約：[LICENSE.md](LICENSE.md)（日本語・正本） / [LICENSE.en.md](LICENSE.en.md)（英語・参考訳）
- 第三者のソフトウェア：[NOTICE.md](NOTICE.md)
- 更新履歴：[CHANGELOG.md](CHANGELOG.md)
- 正規の配布元（VPM）：`https://displaymonitor.github.io/dm-vpm/index.json`

## 主な機能

- 自分専用のローカルプレイリスト（最大 16 個・全プレイリストの合計で最大 150 曲。題名や URL が長いと、保存容量の上限で 150 曲より前に止まることがあります）。入室し直しても残ります
- 動画 URL の追加（タイトルは自動取得を試み、必ず確認してから登録）
- YouTube プレイリストからの一括追加（ローカルプレイリストの中の「YouTubeプレイリストを追加」）
- YamaPlayer のプレイリスト（インポートしたものなど）を、ローカルプレイリストに保存
- プレイリスト・曲の並べ替え、名前の変更、削除、キューへの追加
- 再生位置の移動ボタン（-60 / -30 / -10 / 10 / 30 / 60 秒）
- 再生に失敗したときの「もう一度再生」（PC のみ）
- 自動配置・セットアップ（シーンの YamaPlayer を探して接続します）

## 必要なもの

| 項目 | 版 |
|---|---|
| Unity | 2022.3（確認済み：2022.3.22f1） |
| VRChat SDK - Worlds | 3.10.5 以上 |
| YamaPlayer（`net.kwxxw.yama-stream`） | **1.5.18 に限る** |
| YamachanWebUnit（`net.kwxxw.yamachan-web-unit`） | **1.1.0 に限る** |

YamaPlayer と YamachanWebUnit は、VCC・ALCOM が依存パッケージとして一緒に入れます。先に、YamaPlayer の作者のリポジトリ `https://vpm.kwxxw.net/index.json` を VCC・ALCOM に追加してください。

## 対応状況

| 環境 | 状態 |
|---|---|
| PC（Windows） | 動作確認済み |
| Quest / Android | Android向けC#／UdonSharpコンパイル確認済み。Android SDK BuildおよびQuest実機動作は未検証。Android では、YouTube プレイリストの一括追加と、タイトルの自動取得は使えません（通信する前に止めて案内します）。曲は 1 曲ずつ追加し、タイトルを入力します。「もう一度再生」も出ません |

## 導入

1. VCC か ALCOM に、次の 2 つのリポジトリを追加します。
   - `https://displaymonitor.github.io/dm-vpm/index.json`（このアドオン）
   - `https://vpm.kwxxw.net/index.json`（YamaPlayer）
2. 設定で「プレリリースを表示（Show Pre-Release Packages）」を有効にします。この版（`1.1.0-beta.1`）はプレリリース（ベータ版）のため、有効にしないと一覧に出ません。
3. プロジェクトの「Manage Project」から「DM YamaPlayer Local Playlist」を追加します。
4. **YamaPlayer の「自動更新」を切ります。** シーンの YamaPlayer を選び、Inspector の「自動更新」のチェックを外してください。入れたままだと、YamaPlayer が新しい版へ更新され、このアドオンと合わなくなります。
5. Unity で YamaPlayer のあるシーンを開き、`Tools > DIS_MONI Tools > DM YamaPlayer Local Playlist > 自動配置・セットアップ (Auto Setup)` を実行します。
   - YamaPlayer が無いときは、何も置かずに止まります。複数あるときは、対象を選ぶ画面が出ます。
   - YamaPlayer の設定・プレイリスト・シーン上の既存オブジェクトは変更しません。実行の前後で比べて、結果を表示します。
   - 1.5.18 以外の YamaPlayer では、確認の画面で止まります。
6. 続けて出る「WebUnitを選択」は、**Official YamachanWebUnit** のまま「適用」を押します（下の「WebUnit について」）。
7. シーンを保存します。

## 使い方

- YamaPlayer の「プレイリスト」タブに、ローカルプレイリスト（星付きのフォルダ）が並びます。
- 「新しいプレイリストを作成」→「ローカルプレイリストを作成」で、名前を付けて作ります。
  - 同じ場所にある「プレイリストを作成」は、YamaPlayer 標準の一時的なプレイリストです。全員で共有され、ワールドを出ると消えます。
- ローカルプレイリストを開き、一番下の「追加する」から「動画URLを追加」か「YouTubeプレイリストを追加」を選びます。
- 一番上の「このプレイリストの操作」から、先頭から再生・全てキューへ・並べ替え・名前の変更・削除ができます。
- 動画の行を押すと、再生・キューへ・次に再生・並べ替え・削除ができます。

## WebUnit について

- このアドオンは、**公式の YamachanWebUnit 1.1.0** で動作します。
- WebUnit の設定欄（Inspector・自動配置・セットアップ）には「DM Modified WebUnit v5.4 (PC)」という項目がありますが、**この配布物には同梱されていないため選べません**。画面には「このパッケージには DM Modified WebUnit v5.4 は同梱されていません（Official YamachanWebUnit で動作します）。」と表示され、何も書き込みません。
- 公式の WebUnit で再生する曲（下の「WebUnit を通る曲」）では、再生を始めるときに数秒のフレーム停止が起きることがあります。

## Public・Group Public のインスタンスで再生するには

### WebUnit を通る曲
**再生用の VRCUrl が空で、元の YouTube の URL（`https://www.youtube.com/watch?v=…`）を WebUnit で解決する曲**だけが、WebUnit を通って再生されます。このとき、動画の取得と再生には `api.yamachan.moe` を使います。

- 当てはまる曲の例：YouTube プレイリストの取り込みで保存した曲。YamaPlayer のプレイリストから保存した曲のうち、元の URL だけを持つ曲。
- 当てはまらない曲：再生用の VRCUrl を持つ曲（URL の入力欄から追加した曲、ワールドに最初から設定された VRCUrl を持つ曲など）。これらは WebUnit を通らず、VRChat 標準の動画の再生で動きます。
- Android では、WebUnit を通る曲は再生できません（WebUnit を使う再生は PC だけです）。

### Public・Group Public で必要な 2 つの条件
VRChat は、Public と Group Public のインスタンスでは、許可された動画のドメインしか再生しません（[VRChat の公式の説明](https://creators.vrchat.com/worlds/udon/video-players/www-whitelist/)）。`api.yamachan.moe` は標準の許可リストに入っていないため、WebUnit を通る曲は、次の **2 つの別々の条件がどちらもそろわないと** 再生されず、YamaPlayer に「Access Denied」などのエラーが出ます。

1. **ワールド側の許可（ワールドの制作者が設定）**：VRChat の公式サイトに自分のアカウントでサインインし、「My Worlds」で対象のワールドを開き、「Edit World Info」の **Video Player Allowed Domains** に `api.yamachan.moe` を追加します（ワールドの再アップロードは要りません）。
2. **利用者側の URL の許可（再生する人が設定）**：VRChat の設定で **Allow Untrusted URLs** を有効にします。

- Private・Invite などのインスタンスでは、2. だけで再生できます。そのため、**Private や Build & Test で再生できても、Public で再生できるとは限りません**。Public で使う前に、Public のインスタンスで WebUnit を通る曲を 1 曲再生して確かめてください。
- 再生用の VRCUrl を持つ YouTube の曲は、YouTube が VRChat の標準の許可リストに入っているので、この 2 つの設定がなくても再生できます。

## 知られている制限

- 曲数の上限は、**全プレイリストの合計で 150 曲**です（プレイリストは 16 個まで）。上限を超える一括追加は、1 曲も追加しません。
- これとは別に、保存容量の上限があります。**題名や URL が長いと、150 曲より前に容量の上限に達することがあります**。例えば、題名が 60〜120 文字の曲ばかりだと 120 曲前後、URL を入力して追加した曲ばかりだと 135 曲前後で止まることがあります（どれも目安です）。上限に達した変更は保存せず、それまでのデータはそのまま残ります。
- 101 曲以上を保存した後で 1.0.1-rc.11 以前の版に戻すと、そのデータは「保存データが読めません」となり編集できません（データは消えず、この版に戻すと読めます）。
- YouTube プレイリストの取り込みは、YouTube の応答で一度に返る分（通常は最大 100 件程度）だけです。全曲の取得は保証しません。
- 取り込みとタイトルの取得には、VRChat の「Allow Untrusted URLs」が必要です。
- `www` の付かない YouTube のリンクや youtu.be のリンクからは、取り込みとタイトルの自動取得ができません（VRChat が転送先をたどらないため）。`https://www.youtube.com/...` の形で入力してください。
- YouTube Mix（`list=RD…`）は、Mix の動画を開いたページの URL の形のときだけ、最初に返る一覧（約 25 曲）を取り込めます。
- Build & Test（ローカルのテスト）では、保存データは本番のサーバーに残りません。保存の確認は、アップロードしたワールドで行ってください。
- 退出の直前に変更した内容は、保存が間に合わないことがあります。
- 保存データが読めない場合は、編集をロックし、データは消さずに残します。
- YamaPlayer は 1.5.18、YamachanWebUnit は 1.1.0 との組み合わせだけで確認しています。
- VCC では、更新に失敗したときに、入っていた版がプロジェクトから消える事象を確認しています。更新の前にプロジェクトのバックアップを取ってください。

## 更新と削除

- 更新：VCC・ALCOM で新しい版を選びます。シーンの設定と保存データ（保存キー）は変わりません。
- 削除：VCC・ALCOM でパッケージを外します。シーンに置かれた `PersistentMyList` は自動では消えないので、必要なら手で削除してください。プレイヤーの保存データは、ワールド側からは消せません。

© 2026 DISPLAY_MONITOR
