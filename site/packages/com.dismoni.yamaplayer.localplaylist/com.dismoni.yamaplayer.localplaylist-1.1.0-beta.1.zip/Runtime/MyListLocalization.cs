namespace DM.YamaMyList
{
    using UdonSharp;

    // All addon display copy lives here. Keys are local UI concepts; playlist/video names and
    // URLs are never passed through this table. This class has no state and no network traffic.
    // Language rule: "ja" / "ja-*" -> Japanese, everything else -> English.
    public static class MyListLocalization
    {
        public static bool IsJapanese(string language)
        {
            if (string.IsNullOrEmpty(language)) return false;
            string lower = language.ToLowerInvariant();
            return lower == "ja" || lower.StartsWith("ja-");
        }

        public static string Text(string key, bool ja)
        {
#if UNITY_ANDROID
            if (key == "android_import_unavailable") return ja ? "Quest / Androidでは一括取り込みを使用できません。動画を1曲ずつ追加し、曲名を入力してください。" : "Bulk import is unavailable on Quest / Android. Add videos individually and enter their titles.";
#endif
            // Playlist list rows
            if (key == "tracks_n") return ja ? "{n} 曲" : "{n} tracks";
            if (key == "tracks_kind") return ja ? "{n} 曲 · {kind}" : "{n} tracks · {kind}";
            if (key == "kind_persistent") return ja ? "ローカル" : "local";
            if (key == "kind_import") return ja ? "インポート" : "imported";
            // Create menu
            if (key == "new_playlist") return ja ? "新しいプレイリストを作成" : "Create a new playlist";
            if (key == "create_import") return ja ? "プレイリストを作成" : "Create a playlist";
            if (key == "create_import_sub") return ja ? "このプレイリストは一時的なもので、ワールドを退出すると保存されません。" : "This playlist is temporary and will not be saved after you leave the world.";
            if (key == "no_local_playlists") return ja ? "まだありません。ここから作成できます" : "None yet. Create one here.";
            if (key == "create_persistent") return ja ? "ローカルプレイリストを作成" : "Create a local playlist";
            if (key == "create_persistent_sub") return ja ? "このワールドに保存される自分専用のプレイリスト" : "Your own playlist, kept in this world";
            // Persistent track list
            if (key == "title_lookup_pending") return ja ? "タイトル取得中..." : "Loading title...";
            if (key == "untitled") return ja ? "タイトル未取得（以前のバージョンで保存）" : "No title (saved by an older version)";
            // Track actions (persistent track row)
            if (key == "back") return ja ? "戻る" : "Back";
            if (key == "play") return ja ? "再生" : "Play";
            if (key == "queue") return ja ? "キューへ" : "Queue";
            if (key == "play_next") return ja ? "次に再生" : "Play next";
            if (key == "up") return ja ? "上へ" : "Up";
            if (key == "down") return ja ? "下へ" : "Down";
            if (key == "remove") return ja ? "削除" : "Remove";
            // Persistent playlist header row (playlist-level actions)
            if (key == "playlist_header") return ja ? "このプレイリストの操作" : "Playlist actions";
            if (key == "playlist_header_sub") return ja ? "{n} 曲 · ローカル保存 · 押すと操作を表示" : "{n} tracks · saved · tap for actions";
            if (key == "play_from_start") return ja ? "先頭から再生" : "Play all";
            if (key == "queue_all") return ja ? "全てキューへ" : "Queue all";
            if (key == "rename") return ja ? "名前変更" : "Rename";
            if (key == "delete") return ja ? "削除" : "Delete";
            // URL rows at the end of the persistent list
            if (key == "list_up") return ja ? "リストを上へ" : "List up";
            if (key == "list_down") return ja ? "リストを下へ" : "List down";
            if (key == "delete_list_action") return ja ? "リスト削除" : "Delete list";
            if (key == "playlist_moved") return ja ? "「{name}」をプレイリスト一覧の {n} / {total} 番目へ移動しました" : "Moved \"{name}\" to position {n} of {total} in the playlist list";
            // "追加する >" and its two choices at the end of the persistent list
            if (key == "add_menu") return ja ? "追加する" : "Add";
            if (key == "add_video_url") return ja ? "動画URLを追加" : "Add a video URL";
            if (key == "add_video_url_sub") return ja ? "タイトルを取得（または入力）できた動画が登録されます" : "Saved once its title is read (or typed)";
            if (key == "add_youtube_playlist") return ja ? "YouTubeプレイリストを追加" : "Add a YouTube playlist";
            if (key == "add_youtube_playlist_sub") return ja ? "公開プレイリストの曲をまとめて追加" : "Adds every track of a public playlist (YamaPlayer's own import)";
            // A video waiting for its title (not saved yet)
            if (key == "title_failed_row") return ja ? "タイトルを取得できませんでした（未登録）" : "Could not get the title (not saved)";
            if (key == "title_failed_hint") return ja ? "押すと 再試行 / タイトルを入力して登録 / 入力し直す / キャンセル" : "Tap: retry / type a title and save / re-enter / cancel";
            if (key == "title_form_hint") return ja ? "自動取得できないURLです。押すと 再試行 / タイトル入力 / 入力し直す" : "Title cannot be read from this URL. Tap: retry / type a title / re-enter";
            if (key == "title_site_hint") return ja ? "自動取得できないURLです。押すと 再試行 / タイトル入力 / 入力し直す" : "Title cannot be read from this URL. Tap: retry / type a title / re-enter";
            if (key == "manual_title_action") return ja ? "タイトル入力" : "Type title";
            if (key == "title_confirm") return ja ? "タイトル" : "Title";
            if (key == "title_confirm_failure") return ja ? "タイトルを取得できませんでした。タイトルを入力してください。" : "Could not retrieve the title. Please enter a title.";
            if (key == "title_confirm_message") return ja ? "タイトルを確認・編集して登録してください。自動取得できない場合は入力してください。" : "Confirm or edit the title before registering. Enter a title if automatic lookup is unavailable.";
            if (key == "title_will_save") return ja ? "登録されるタイトル: {title}" : "Title to be saved: {title}";
            if (key == "title_enter") return ja ? "タイトルを入力してください" : "Enter a title";
            if (key == "title_empty_mark") return ja ? "（未入力）" : "(empty)";
            if (key == "title_confirmation_busy") return ja ? "先にタイトル確認を完了またはキャンセルしてください。" : "Finish or cancel the current title confirmation first.";
            if (key == "manual_title") return ja ? "タイトルを入力して登録" : "Type a title and save";
            if (key == "manual_title_message") return ja ? "この動画のタイトルを入力してください（1〜256文字）。\n{url}" : "Enter a title for this video (1-256 characters).\n{url}";
            if (key == "register") return ja ? "登録" : "Save";
            if (key == "title_required_input") return ja ? "タイトルを入力してください（空欄では登録できません）" : "Enter a title (it cannot be empty)";
            if (key == "retry") return ja ? "再試行" : "Retry";
            if (key == "reenter_url") return ja ? "入力し直す" : "Re-enter";
            // Delete dialog
            if (key == "delete_playlist") return ja ? "プレイリストの削除" : "Delete playlist";
            if (key == "delete_confirm") return ja ? "ローカルプレイリスト「{name}」を削除しますか？\n中の動画もすべて削除されます。" : "Delete the local playlist \"{name}\"?\nAll of its videos are deleted too.";
            if (key == "playlist_deleted") return ja ? "「{name}」を削除しました" : "Deleted \"{name}\"";
            if (key == "delete_failed") return ja ? "削除できませんでした。プレイリストを開き直してからお試しください" : "Could not delete. Open the playlist again and retry.";
            // Title-required add
            if (key == "added_title") return ja ? "「{title}」を追加しました" : "Added \"{title}\"";
            if (key == "title_lookup_started") return ja ? "タイトル取得中...（取得できたら登録されます）" : "Loading the title... (saved when it arrives)";
            if (key == "title_failed") return ja ? "タイトルを取得できませんでした（未登録）。行を押すと、再試行やタイトルの入力ができます" : "Could not get the title (not saved). Tap the row to retry or type a title.";
            if (key == "title_form_unsupported") return ja ? "この形式のURLからは自動でタイトルを取得できません（未登録）。行を押して、タイトルを入力して登録するか、www.youtube.com/watch?v=… の形式で入力し直してください" : "The title cannot be read from this URL form (not saved). Tap the row to type a title, or re-enter it as www.youtube.com/watch?v=…";
            if (key == "title_site_unsupported") return ja ? "このサイトのURLは自動でタイトルを取得できません（未登録）。行を押して、タイトルを入力して登録できます" : "The title cannot be read from this site (not saved). Tap the row to type a title and save.";
            if (key == "duplicate_pending") return ja ? "この動画はタイトル取得中です" : "This video is already waiting for its title";
            if (key == "pending_limit") return ja ? "タイトル取得待ちが多すぎます。少し待ってからお試しください" : "Too many videos are waiting for titles. Try again shortly.";
            if (key == "reenter_url_hint") return ja ? "「動画URLを追加」からURLを入力し直してください" : "Enter the URL again with \"Add a video URL\"";
            if (key == "import_no_titles") return ja ? "タイトルを読み取れた動画がないため、保存しませんでした" : "No track with a title was found; nothing was saved";
            if (key == "skipped_untitled_n") return ja ? "{n} 曲はタイトルがないため省きました" : "Skipped {n} without a title";
            if (key == "title_required") return ja ? "タイトルがないため保存しませんでした" : "Nothing was saved: a title is required";
            // YamaPlayer playlist header row (DM actions on a standard / imported playlist)
            if (key == "native_header") return ja ? "ローカルプレイリストに保存 / キューに追加" : "Save to local playlists / queue";
            if (key == "native_header_sub") return ja ? "{n} 曲 · 押すと操作を表示" : "{n} tracks · tap for actions";
            if (key == "save_new") return ja ? "新しく保存" : "Save new";
            if (key == "add_existing") return ja ? "既存に追加" : "Add to list";
            if (key == "save_as_persistent") return ja ? "ローカルプレイリストとして保存" : "Save as local playlist";
            if (key == "pick_target") return ja ? "{n} 曲の追加先を選んでください" : "Choose where to add {n} tracks";
            if (key == "stop_picking") return ja ? "やめる" : "Cancel";
            // Dialogs
            if (key == "cancel") return ja ? "キャンセル" : "Cancel";
            if (key == "create") return ja ? "作成" : "Create";
            if (key == "save") return ja ? "保存" : "Save";
            if (key == "new_persistent_title") return ja ? "新しいローカルプレイリスト" : "New local playlist";
            if (key == "enter_name") return ja ? "名前を入力してください（1〜48文字）" : "Enter a name (1-48 characters)";
            if (key == "rename_playlist") return ja ? "プレイリスト名の変更" : "Rename playlist";
            if (key == "enter_new_name") return ja ? "新しい名前を入力してください" : "Enter the new name";
            if (key == "save_message") return ja ? "{n} 曲を新しいローカルプレイリストに保存します。名前を確認してください。" : "Save {n} tracks as a new local playlist. Check the name.";
            if (key == "save_partial_note") return ja ? "※YouTubeのページから読み取れた分だけが対象です（続きのページは読み込まれません）。" : "Only the tracks YouTube's page returned are included (further pages are not loaded).";
            if (key == "partial_note_short") return ja ? "※YouTubeから読み込めた分のみ（続きのページは対象外）" : "Only the tracks YouTube's page returned";
            if (key == "youtube_playlist") return ja ? "YouTubeプレイリスト" : "YouTube playlist";
            // Feedback
            if (key == "added_queue") return ja ? "キューに追加しました" : "Added to the queue";
            if (key == "added_queue_n") return ja ? "{n} 曲をキューに追加しました" : "Added {n} tracks to the queue";
            if (key == "play_next_done") return ja ? "次に再生します" : "Plays next";
            if (key == "play_requested") return ja ? "再生を開始します" : "Starting playback";
            if (key == "saved_to") return ja ? "「{name}」に {n} 曲を保存しました" : "Saved {n} tracks to \"{name}\"";
            if (key == "skipped_n") return ja ? "{n} 曲は登録済みのため省きました" : "Skipped {n} already saved";
            if (key == "playlist_loading_wait") return ja ? "プレイリストを読み込み中です。完了してからもう一度押してください" : "The playlist is still loading. Try again when it finishes.";
            if (key == "playlist_empty") return ja ? "このプレイリストに動画がありません" : "This playlist has no videos";
            if (key == "playlist_limit") return ja ? "ローカルプレイリストは16個までです" : "Up to 16 local playlists";
            if (key == "name_required") return ja ? "名前を入力してください" : "Enter a name";
            if (key == "invalid_url") return ja ? "URLが正しくありません" : "Invalid URL";
            if (key == "enter_url") return ja ? "URLを入力してください" : "Enter a URL";
            if (key == "import_loading") return ja ? "YouTubeプレイリストを読み込み中…（このローカルプレイリストにだけ追加します）" : "Loading the YouTube playlist… (it is added to this local playlist only)";
            if (key == "import_waiting") return ja ? "YouTubeプレイリストの読み込みが順番待ちです（VRChatはワールド全体で5秒に1件ずつ読み込みます）。このまま待てます。やめるときは「読み込み待ち」の行を押してください" : "The YouTube playlist is still waiting in line (VRChat loads one item every 5 seconds for the whole world). You can keep waiting; tap the \"Waiting\" row to stop.";
            if (key == "import_row_waiting") return ja ? "読み込み待ち {s}秒（押すと中止できます）" : "Waiting to load: {s} s (tap to stop)";
            if (key == "import_cancel_title") return ja ? "読み込みを中止" : "Stop loading";
            if (key == "import_cancel_message") return ja ? "YouTubeプレイリストの読み込みを中止しますか？（{s}秒経過。何も保存されません）" : "Stop loading the YouTube playlist? ({s} s so far; nothing will be saved)";
            if (key == "import_cancel_execute") return ja ? "中止する" : "Stop";
            if (key == "import_cancelled") return ja ? "YouTubeプレイリストの読み込みを中止しました（何も保存していません）" : "Stopped loading the YouTube playlist (nothing was saved)";
            if (key == "import_error") return ja ? "YouTubeプレイリストを取得できませんでした（通信エラー {code}）。時間をおいてもう一度お試しください" : "Could not download the YouTube playlist (error {code}). Please try again later.";
            if (key == "import_queue_full") return ja ? "中止した読み込みがまだVRChatの順番待ちに残っています。しばらく待ってからもう一度お試しください" : "Stopped imports are still in VRChat's download queue. Please try again in a while.";
            if (key == "import_busy") return ja ? "別のYouTubeプレイリストを読み込み中です" : "Another YouTube playlist is still loading";
            if (key == "import_failed") return ja ? "YouTubeプレイリストを読み込めませんでした。プレイリスト内の動画を開いたページのURL（…watch?v=…&list=…）でお試しください" : "Could not load the YouTube playlist. Try the URL of a video opened inside the playlist (…watch?v=…&list=…).";
            if (key == "import_form_a") return ja ? "www なしのプレイリストのリンク（youtube.com/playlist?list=…）は読み込めません。先頭を https://www.youtube.com/playlist?list=… に直して、もう一度入力してください（通信は行っていません）" : "Playlist links without www (youtube.com/playlist?list=…) cannot be loaded. Change the start to https://www.youtube.com/playlist?list=… and enter it again (nothing was downloaded).";
            if (key == "import_mix") return ja ? "この形の YouTube Mix（自動生成プレイリスト）のリンクは読み込めません。Mix の動画を開いたページのURL（https://www.youtube.com/watch?v=…&list=RD…）か、通常のYouTubeプレイリストのURLをご利用ください（通信は行っていません）" : "This form of YouTube Mix (auto-generated playlist) link cannot be loaded. Use the URL of a video page opened in the Mix (https://www.youtube.com/watch?v=…&list=RD…) or a regular YouTube playlist URL (nothing was downloaded).";
            if (key == "import_mix_unavailable") return ja ? "このYouTube Mixのページには曲の一覧がありませんでした（何も保存していません）。時間をおくか、別のMixや通常のプレイリストでお試しください" : "This YouTube Mix page had no track list (nothing was saved). Try again later, or use another Mix or a regular playlist.";
            if (key == "import_mix_too_many") return ja ? "YouTube Mixの曲数が上限（100件）を超えていたため、保存しませんでした" : "The YouTube Mix had more than 100 items, so nothing was saved.";
            if (key == "import_mix_rejected") return ja ? "YouTube Mixの一覧を確認できなかったため、保存しませんでした" : "The YouTube Mix list could not be confirmed, so nothing was saved.";
            if (key == "import_mix_saved_first") return ja ? "YouTube Mixの最初の {n} 曲を取り込みました（続きは取り込んでいません）" : "Imported the first {n} tracks of the YouTube Mix (the rest is not imported).";
            if (key == "import_fallback_duplicates") return ja ? "同じ動画 {d} 件を 1 件にまとめました" : "{d} repeated video(s) were kept once.";
            if (key == "import_fallback_rejected") return ja ? "{n} 件中 {r} 件を確認できなかったため、保存しませんでした（{reasons}）" : "{r} of {n} items could not be confirmed, so nothing was saved ({reasons}).";
            if (key == "import_fallback_unknown") return ja ? "読み取れない形の項目が {u} 件あったため、保存しませんでした" : "{u} item(s) had a form that could not be read, so nothing was saved.";
            if (key == "import_fallback_incomplete") return ja ? "プレイリストの一部（{n} 件）しか読み取れなかったため、保存しませんでした" : "Only part of the playlist ({n} items) could be read, so nothing was saved.";
            if (key == "fallback_reason_kind") return ja ? "種類" : "type";
            if (key == "fallback_reason_id") return ja ? "動画ID" : "video ID";
            if (key == "fallback_reason_title") return ja ? "タイトル" : "title";
            if (key == "fallback_reason_endpoint") return ja ? "再生先" : "play target";
            if (key == "fallback_reason_shape") return ja ? "形" : "form";
            if (key == "not_ready") return ja ? "保存データの準備ができていません" : "Saved data is not ready";
            if (key == "restoring") return ja ? "保存データを復元中..." : "Restoring saved data...";
            if (key == "playback_unavailable") return ja ? "ローカルプレイリストの再生を開始できませんでした" : "Could not start local playlist playback";
            if (key == "yama_missing") return ja ? "YamaPlayerが見つかりません" : "YamaPlayer not found";
            if (key == "yama_locked") return ja ? "YamaPlayerがロックされています" : "YamaPlayer is locked";
            if (key == "webunit_required") return ja ? "この動画の再生にはWebUnitが必要です" : "WebUnit is required to play this video";
            if (key == "webunit_pc_only") return ja ? "この動画はPC版でのみ再生できます" : "This video plays on PC only";
            if (key == "webunit_failed") return ja ? "再生URLを準備できませんでした" : "Could not prepare the playback URL";
            if (key == "webunit_busy") return ja ? "別の動画を準備中です。少し待ってからお試しください" : "Another video is being prepared. Try again shortly.";
            // F1b "play again" panel (next to YamaPlayer's own error message, which is not changed)
            if (key == "f1b_play_again") return ja ? "もう一度再生" : "Play again";
            if (key == "f1b_play_again_n") return ja ? "もう一度再生（あと{n}回）" : "Play again ({n} left)";
            if (key == "f1b_wait") return ja ? "数秒後に押せます" : "Available in a few seconds";
            if (key == "f1b_hint") return ja ? "押すと、この曲をもう一度読み込みます" : "Loads this video once more";
            if (key == "f1b_preparing") return ja ? "準備しています…曲を変えずにお待ちください" : "Preparing... please do not change the video";
            if (key == "f1b_no_response") return ja ? "応答がありません" : "No response";
            if (key == "f1b_exhausted") return ja ? "再生できませんでした。時間をおいて、曲を選び直してください" : "Could not play. Wait a while, then select the video again.";
            if (key == "f1b_not_ready") return ja ? "プレイヤーの状態が整っていません。曲を選び直してください" : "The player is not ready. Select the video again.";
            if (key == "f1b_not_target") return ja ? "この動画はもう一度再生できません" : "This video cannot be played again here.";
            if (key == "f1b_previous_open") return ja ? "前のもう一度再生の準備が終わっていません。終わるまで使えません（終わらない場合はワールドに入り直してください）" : "The previous play again request has not finished. Unavailable until it finishes (rejoin the world if it does not).";
            if (key == "f1b_already_loading") return ja ? "読み込み中です" : "Already loading.";
            if (key == "f1b_track_changed") return ja ? "前の曲を準備中に曲が変わりました。違う曲が流れたら、曲を選び直してください" : "The video changed while the previous one was being prepared. If a different video plays, select the video again.";
            // Store status (see LegacyStatus)
            if (key == "restored_empty") return ja ? "復元しました（空）" : "Restored. MyList is empty.";
            if (key == "restored") return ja ? "復元しました" : "MyList restored.";
            if (key == "data_invalid") return ja ? "保存データが読めません。編集はロックされ、データは保持されています。" : "Saved data is invalid / unsupported. Editing is locked; data preserved.";
            if (key == "invalid_name_limit") return ja ? "名前が無効か、プレイリスト数の上限です" : "Invalid name or playlist limit reached.";
            if (key == "select_destination") return ja ? "保存先のプレイリストを選んでください" : "Select a destination playlist.";
            if (key == "invalid_original") return ja ? "元のURLが正しくありません" : "Invalid original URL.";
            if (key == "duplicate") return ja ? "このプレイリストに登録済みです" : "Already in this playlist.";
            if (key == "entry_limit") return ja ? "保存できる動画は合計" + MyListCodec.MaxEntries.ToString() + "件までです" : MyListCodec.MaxEntries.ToString() + " entry limit reached.";
            if (key == "entry_limit_unchanged") return ja ? "合計" + MyListCodec.MaxEntries.ToString() + "件を超えるため保存しませんでした" : MyListCodec.MaxEntries.ToString() + " entry limit reached. Nothing was saved.";
            if (key == "invalid_playlist_data") return ja ? "プレイリストのデータが正しくありません" : "Invalid playlist data.";
            if (key == "invalid_playlist_track") return ja ? "無効な動画が含まれるため保存しませんでした" : "Invalid track. Nothing was saved.";
            if (key == "no_new_tracks") return ja ? "新しく追加できる動画がありません" : "No new tracks to add.";
            if (key == "create_limit") return ja ? "名前が無効か、16個の上限に達しています" : "Invalid name or 16 playlist limit reached.";
            if (key == "name_length") return ja ? "名前は1〜48文字で入力してください" : "Enter a name (1-48 characters).";
            if (key == "storage_budget") return ja ? "保存容量の上限のため変更しませんでした（題名やURLが長いと、件数の上限より前に達します）" : "Storage limit reached. Nothing changed (long titles or URLs reach it before the entry limit).";
            if (key == "saving_pending") return ja ? "変更しました。保存中..." : "Changed. Saving...";
            if (key == "saved_sent") return ja ? "保存しました" : "Saved.";
            if (key == "save_failed") return ja ? "保存の送信に失敗しました。ワールドから出ずにお待ちください（1回だけ自動で再試行します）" : "Save failed to send. Stay in the world; it retries once automatically.";
            return key;
        }

        // The Store keeps English status strings (its behaviour and tests stay unchanged);
        // they are translated only at the presentation boundary.
        public static string LegacyStatus(string message, bool ja)
        {
            if (string.IsNullOrEmpty(message)) return message;
            if (message == "Waiting for restoration...") return Text("restoring", ja);
            if (message == "Restored. MyList is empty.") return Text("restored_empty", ja);
            if (message == "MyList restored.") return Text("restored", ja);
            if (message == "Saved data is invalid / unsupported. Editing is locked; data preserved.") return Text("data_invalid", ja);
            if (message == "Invalid name or playlist limit reached.") return Text("invalid_name_limit", ja);
            if (message == "Select a destination playlist.") return Text("select_destination", ja);
            if (message == "Invalid original URL.") return Text("invalid_original", ja);
            if (message == "Invalid URL.") return Text("invalid_url", ja);
            if (message == "Already in MyList.") return Text("duplicate", ja);
            if (message == "Entry limit reached.") return Text("entry_limit", ja);
            if (message == "Entry limit reached. List unchanged.") return Text("entry_limit_unchanged", ja);
            if (message == "Invalid playlist data.") return Text("invalid_playlist_data", ja);
            if (message == "Invalid playlist track. List unchanged.") return Text("invalid_playlist_track", ja);
            if (message == "No new tracks to add.") return Text("no_new_tracks", ja);
            if (message == "Invalid name or 16 playlist limit reached.") return Text("create_limit", ja);
            if (message == "Enter a name (1-48 characters).") return Text("name_length", ja);
            if (message == "Title required. Nothing was saved.") return Text("title_required", ja);
            if (message == "Storage budget reached. List unchanged.") return Text("storage_budget", ja);
            if (message == "Changed. Save pending...") return Text("saving_pending", ja);
            if (message == "Saved / sent. Cloud restore requires rejoin verification.") return Text("saved_sent", ja);
            if (message == "Save send failed. Keep this session open; press Retry save.") return Text("save_failed", ja);
            return message;
        }
    }
}
