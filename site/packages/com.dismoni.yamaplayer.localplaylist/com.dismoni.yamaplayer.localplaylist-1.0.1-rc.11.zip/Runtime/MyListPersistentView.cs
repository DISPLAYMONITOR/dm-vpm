namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;
    using UnityEngine.UI;
    using VRC.SDK3.Components;
    using VRC.SDK3.Components.Video;
    using VRC.SDKBase;
    using Yamadev.YamaStream;
    using Yamadev.YamaStream.UI;
    using Yamadev.YamaStream.Libraries.GenericDataContainer;
    using VRC.SDK3.Data;
    using VRC.SDK3.StringLoading;
    using VRC.Udon.Common.Interfaces;

    // Production UI of DM Persistent MyList. Every YamaPlayer reference below is filled in by the
    // editor Zero Config step (read-only lookups; nothing is written into YamaPlayer's saved data).
    // At runtime the DM-owned UI kit is moved into YamaPlayer's canvas, so persistent playlists
    // appear inside the standard Playlist tab. No Update/LateUpdate/FixedUpdate, no network events.
    //
    // UI model: every DM part is a copy of a YamaPlayer template, used the way YamaPlayer uses it.
    //   persistent playlist header row (Track row copy, tap -> actions): back / play from start / queue all / list up / list down / rename / delete
    //   persistent track row (Track row copy, tap -> actions)           : back / play / queue / play next / up / down / remove
    //   end of the persistent list (Playlist row copies)                : "追加する >" -> add a video URL / add a YouTube playlist
    //   a video waiting for its title (same Track row, not saved yet)    : back / retry / enter the URL again / cancel
    //   YamaPlayer playlist header row (Track row copy, tap -> actions)  : back / save as persistent / add to existing / queue all
    //   destination picker (Playlists list + Playlist row copies)
    //   (YamaPlayer's own track rows keep their own back / add to queue / play buttons.)
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListPersistentView : Listener
    {
        [Header("Target YamaPlayer (optional: pick one when the scene has several)")]
        public GameObject targetYamaPlayer;

        // One YamaPlayer can have several screens with their own controls (its SubScreen prefab, a tablet controller):
        // each of them has a UIController that points at the same Controller. The DM Persistent MyList prefab
        // serves the YamaPlayer's own screen; a "DM Local Playlist UI" prefab (this view + the UI kit only: no
        // Store, no playback slot) serves one more screen and shares the Store and the playback of its primary.
        [Header("Additional screen (DM Local Playlist UI prefab)")]
        public GameObject targetScreen;            // the screen this UI belongs to (an object with a YamaPlayer UIController below it)
        public MyListPersistentView primary;       // auto: the DM Persistent MyList this UI shares data and playback with
        public MyListPersistentView[] extraViews;  // auto, on the primary: its additional UIs

        [Header("YamaPlayer references (auto)")]
        public Controller controller;
        public UIController yamaUI;
        public Modal modal;
        public VideoInfo videoInfo;
        public LoopScroll nativePlaylists;
        public GameObject nativeTracks;
        public Text nativeName;
        public Transform nativeInfo;
        public Animator controlAnimator;
        public Toggle queueTab;
        public Toggle historyTab;
        public Toggle playlistTab;
        public Transform nativeAddPlaylistRow;
        public Transform modalContent;
        public Transform nativeTransport;      // YamaPlayer's Back / Play / Stop / Next group in the bottom bar

        [Header("DM parts")]
        public MyListNativePlaylistAdapter adapter;
        public MyListWebUnitPlayback playbackGuard;
        public MyListNativePlaylistRow[] playlistRows;
        public MyListNativePlaylistRow createRow;            // "新しいプレイリストを作成 >" (index -1: opens the two choices)
        public GameObject createImportRow;                   // choice 1: standard YamaPlayer playlist from a YouTube URL
        public VRCUrlInputField createImportInput;
        public MyListNativePlaylistRow createPersistentRow;  // choice 2: persistent playlist (index -2)
        public Transform createChevron;
        public Sprite iconPersistent;   // folder + star (DM)
        public Sprite iconFolder;       // YamaPlayer folder
        public Sprite iconPlaying;      // YamaPlayer music note
        public LoopScroll trackScroll;
        public GameObject persistentActions;   // header row of an open persistent playlist
        public GameObject nativeActions;       // DM header row on an open YamaPlayer playlist (e.g. an imported one)
        public InputField nameInput;
        public InputField createRowNameInput; // Receives the user's real click. No synthetic pointer events.
        public InputField renameRowNameInput;
        public GameObject nameInputRoot;
        public Text nameDisplay;               // what the user sees in the name / title field (copy of the Modal's own message Text)
        public MyListNativePlaylistRow addRow;     // "追加する >" at the end of the persistent list (index -3: opens the two choices)
        public Transform addChevron;
        public VRCUrlInputField videoUrlInput;     // choice 1: add a video URL
        public VRCUrlInputField playlistUrlInput;  // choice 2: add a YouTube playlist (into the open persistent playlist only)
        public MyListPlaylistImport importTemplate; // inactive DM object; one copy per import into a persistent playlist
        public Button movePlaylistUpButton;        // persistent header row: playlist order
        public Button movePlaylistDownButton;
        public GameObject pickerRoot;          // target chooser for "add to an existing persistent playlist"
        public GameObject pickerHeader;
        public MyListNativePlaylistRow[] pickerRows;
        public MyListUiSentinel listSentinel;
        public MyListUiSentinel tracksSentinel;
        public GameObject seekRoot;            // "-60 -30 -10 +10 +30 +60" buttons, shown to the right of YamaPlayer's Next button
        public GameObject toastRoot;
        public Text toastText;
        public Text[] localizedTexts;
        public string[] localizedKeys;

        [Header("F1b play again (Docs/F1B_PLAY_AGAIN_SPEC.md)")]
        public Transform retryHost;            // auto: the parent (Toggle) of YamaPlayer's _loading on this screen; empty = no F1b here
        public GameObject retryPanel;          // "DM Play Again": moved into retryHost at runtime
        public Button retryButton;
        public Text retryButtonText;
        public Text retryText;                 // the note next to the button

        [System.NonSerialized] public MyListStore store;
        [System.NonSerialized] public bool mounted;
        [System.NonSerialized] public int selected = -1;
        [System.NonSerialized] public string lastFeedback = "";

        private int[] visible = new int[MyListCodec.MaxEntries];
        private bool japanese;
        // Shared by every UI of one YamaPlayer: kept on the primary view (Hub()).
        [System.NonSerialized] public bool startedHere;
        private Playlist pendingNative;
        private int pendingDialog; // 1 create, 2 rename, 3 delete, 5 save a YamaPlayer playlist as new, 6 title typed by the user
        private string titleStatusKey = "title_confirm_message";
        private string manualKey = "";   // the waiting video the title dialog was opened for (identity + playlist ID)
        private int manualList = -1;
        private int deleteId = -1; // playlist ID a rename / delete dialog was opened for
        // The running import into a persistent playlist (IMPORT_CONTEXT = PERSISTENT). One at a time for all UIs of
        // a YamaPlayer: these live on the primary view (Hub()). VRChat downloads one string every five seconds for the
        // whole world and keeps the other requests in a queue, so an import can wait for a long time; it is never
        // given up by a timer. It ends with its answer, or when the user stops it (importOrphans: stopped imports
        // whose request is still in VRChat's queue; their answer is thrown away).
        [System.NonSerialized] public MyListPlaylistImport importJob;
        [System.NonSerialized] public int importTargetId = -1;
        [System.NonSerialized] public float importStarted;
        [System.NonSerialized] public bool importWaitShown;
        [System.NonSerialized] public MyListPersistentView importOwner; // the UI the import was started from (its messages go there)
        [System.NonSerialized] public int importOrphans;
        [System.NonSerialized] public float importOrphanAt; // when the last import was stopped
        // Stopped imports are counted per generation. Forgetting the unanswered ones starts a new generation, so an
        // answer of a forgotten import can never lower the count of imports that were stopped afterwards.
        [System.NonSerialized] public int importOrphanEpoch;
        private const float ImportOrphanForgetSeconds = 600f;
        private bool importTickScheduled;
        private const float ImportWaitNoticeSeconds = 90f;
        private const int MaxImportOrphans = 3;
        private Text addRowText;
        private int selectedId = -1; // playlist ID of the open persistent playlist (`selected` is its current index)
        private int renameInputPlaylistId = -1;
        private string renameInputOriginalName = "";
        private Vector2 nativeTracksTop;
        private string lastStoreStatus = "";
        // Videos waiting for their title (YamaPlayer VideoInfo). A video is written to the Store only when
        // its title is known, so these exist in memory only; identity = playlist ID + canonical video key.
        // pendStates: 0 loading, 1 failed (retry possible), 2 YouTube URL form that cannot be read, 3 other site.
        // pendBackfill: an already saved track of an older version without a title (never shown as a row).
        private const int MaxPending = 16;
        private VRCUrl[] pendUrls = new VRCUrl[MaxPending];      // the URL the user entered (what gets saved)
        private VRCUrl[] pendAskUrls = new VRCUrl[MaxPending];   // the URL VideoInfo was asked with (result is matched by it)
        private string[] pendKeys = new string[MaxPending];
        private string[] pendOriginals = new string[MaxPending];
        private int[] pendPlayers = new int[MaxPending];
        private int[] pendLists = new int[MaxPending];
        private float[] pendDeadlines = new float[MaxPending];
        private int[] pendStates = new int[MaxPending];
        private bool[] pendBackfill = new bool[MaxPending];
        private int pendCount;
        private int[] pendVisible = new int[MaxPending];
        private bool lookupTickScheduled;
        // Runtime only (never saved). verifiedTitles: canonical video identity -> title read from a response whose
        // own videoDetails.videoId is that video. inFlight: asked URL -> generation of the download that is
        // running for it (one per URL); inFlightSince: when it was sent. pendRequest: the generation a waiting
        // video is attached to (-1 = it still has to send its own request).
        private DataDictionary verifiedTitles = new DataDictionary();
        private DataDictionary inFlight = new DataDictionary();
        private DataDictionary inFlightSince = new DataDictionary();
        private int[] pendRequest = new int[MaxPending];
        private int lookupGeneration;
        private bool titleFieldUserEdited, titleFieldPrefilling;
        private string titleFieldInitial = "";
        private const float RequestStaleSeconds = 300f; // no answer for this long: the request is treated as lost
        // Old records without a title (one pass per session): identities still to look up, with a readable URL each.
        private string[] backfillKeys = new string[MyListCodec.MaxEntries];
        private VRCUrl[] backfillUrls = new VRCUrl[MyListCodec.MaxEntries];
        private string[] backfillFound = new string[MyListCodec.MaxEntries];
        private int backfillCount, backfillNext, backfillStarted;
        private DataDictionary backfillWanted = new DataDictionary();
        private bool indexing, backfillContinuing;
        [System.NonSerialized] public string lookupResultUrl = "";
        [System.NonSerialized] public string lookupResultBody = "";
        private string parsedId = "";
        private string parsedTitle = "";
        private bool backfillDone;
        private bool addMenuOpen;
        private float toastUntil;
        private int lastRenderedVersion = -1;
        private int lastRenderedSelected = -2;
        private int lastRenderedRows = -1;
        private bool createMenuOpen;
        private float createTitleY;      // where the prefab puts the title of the create row (one line)
        private bool createTitleKnown;
        private float createRevealY;     // where the playlist list was right after the create menu was opened
        private bool nativeImportAvailable;
        private readonly Color rowTextColor = new Color(1f, 1f, 1f, 0.749f);
        // F1b state: one per YamaPlayer, kept and changed on the primary view (Hub()) only. Other views only show it.
        private int f1bState;                  // MyListPlayAgainRules.Idle .. Exhausted
        private int f1bGen;                    // observed external requests (OnUrlChanged outside DM's own call)
        private int f1bPresses;                // presses for the current observed request (0 .. MaxPresses)
        private int f1bAttempt;                // every state change; a timer acts only for the attempt it was made for
        private int f1bArmGen, f1bArmAttempt, f1bTimeoutGen, f1bTimeoutAttempt;
        private float f1bArmDue, f1bTimeoutDue;
        private bool f1bOwnCall;               // true only while DM's own PlayTrack call runs
        private bool f1bInFlight;              // a DM request may still be sent by WebUnit (ends only when the Client is seen idle)
        private float f1bInFlightSince;
        private UdonSharpBehaviour f1bClient;  // the WebUnit Client that took DM's last request (its state ends the tracking)
        private bool f1bLongNoted;             // the request was still not finished after 120 s (recorded once)
        private bool f1bWatchScheduled;
        private bool f1bArmPending, f1bTimeoutPending, f1bWarnPending;   // at most one queued event per timer
        private float f1bWarnUntil;            // "the video changed while ..." warning
        private string f1bNotice = "";         // why the last press was refused (shown until the state changes)
        private string f1bTitle = "";          // the title of the current track when the failure was shown
        private bool f1bMounted;               // this view's panel is in its screen (retryHost)

        private string L(string key) { return MyListLocalization.Text(key, japanese); }

        // ---------- lifecycle ----------

        private void Start()
        {
            japanese = MyListLocalization.IsJapanese(VRCPlayerApi.GetCurrentLanguage());
            if (controller == null || yamaUI == null || nativePlaylists == null || nativeTracks == null)
            {
                Debug.LogWarning("[DM MyList] No YamaPlayer is bound. Place the DM Persistent MyList prefab in a scene that contains YamaPlayer.");
                return;
            }
            if (primary != null)
            {
                // an additional UI: data and playback are those of the primary
                adapter = primary.adapter; playbackGuard = primary.playbackGuard; importTemplate = primary.importTemplate;
                if (primary.store != null) store = primary.store;
            }
            if (addRow != null && localizedTexts != null && localizedKeys != null)
                for (int i = 0; i < localizedTexts.Length && i < localizedKeys.Length; i++)
                    if (localizedKeys[i] == "add_menu" && localizedTexts[i] != null && localizedTexts[i].transform.IsChildOf(addRow.transform)) addRowText = localizedTexts[i];
            controller.AddListener(this);
            Mount();
            ApplyLanguage();
            Refresh();
            Hub()._F1bRenderAll();
            SendCustomEventDelayedFrames(nameof(ApplyPlaylistMask), 10);
        }

        // Moves the DM UI kit into YamaPlayer's UI. Runtime only; the scene file is unchanged.
        private void Mount()
        {
            Transform content = nativePlaylists.GetComponent<ScrollRect>().content;
            bool anchor = nativeAddPlaylistRow != null && nativeAddPlaylistRow.parent == content;
            for (int i = 0; i < playlistRows.Length; i++) MountRow(playlistRows[i].transform, content, anchor);
            if (createRow != null) MountRow(createRow.transform, content, anchor);
            if (createImportRow != null) MountRow(createImportRow.transform, content, anchor);
            if (createPersistentRow != null) MountRow(createPersistentRow.transform, content, anchor);
            // YamaPlayer shows "Add Youtube Playlist" only when WebUnit is present; the same action is
            // offered as the first choice under "新しいプレイリストを作成", so the original row is hidden (runtime only).
            if (anchor)
            {
                nativeImportAvailable = nativeAddPlaylistRow.gameObject.activeSelf;
                nativeAddPlaylistRow.gameObject.SetActive(false);
            }
            Transform list = nativeTracks.transform.parent;
            trackScroll.transform.SetParent(list, false);
            trackScroll.Initialize(); // size the recycled rows for the full list height
            trackScroll.gameObject.SetActive(false);
            // Header rows sit at the top of YamaPlayer's list area, above the track rows.
            persistentActions.transform.SetParent(list, false);
            nativeActions.transform.SetParent(list, false);
            persistentActions.SetActive(false);
            nativeActions.SetActive(false);
            nativeTracksTop = ((RectTransform)nativeTracks.transform).offsetMax;
            if (modalContent != null) nameInputRoot.transform.SetParent(modalContent, false);
            nameInputRoot.SetActive(false);
            pickerRoot.transform.SetParent(list, false);
            pickerRoot.SetActive(false);
            if (toastRoot != null) { toastRoot.transform.SetParent(list, false); toastRoot.transform.SetAsLastSibling(); toastRoot.SetActive(false); }
            listSentinel.transform.SetParent(nativePlaylists.transform, false);
            tracksSentinel.transform.SetParent(nativeTracks.transform, false);
            // Seek buttons: into YamaPlayer's bottom bar, next to its own transport buttons (after them, so on top).
            if (seekRoot != null)
            {
                if (nativeTransport != null && nativeTransport.parent != null) seekRoot.transform.SetParent(nativeTransport.parent, false);
                seekRoot.SetActive(nativeTransport != null && nativeTransport.parent != null);
            }
            // F1b panel: next to YamaPlayer's _loading (the last child of its parent, in front of its Overlay).
            // A screen without retryHost gets no panel; nothing else is moved for it.
            if (retryPanel != null)
            {
                f1bMounted = retryHost != null;
                if (f1bMounted) { retryPanel.transform.SetParent(retryHost, false); retryPanel.transform.SetAsLastSibling(); }
                retryPanel.SetActive(false);
            }
            mounted = true;
        }

        private void MountRow(Transform row, Transform content, bool anchor)
        {
            row.SetParent(content, false);
            if (anchor) row.SetSiblingIndex(nativeAddPlaylistRow.GetSiblingIndex());
            row.gameObject.SetActive(false);
        }

        // ---------- relative seek ("-60" .. "+60") ----------

        public void SeekBack60() { SeekBy(-60f); }
        public void SeekBack30() { SeekBy(-30f); }
        public void SeekBack10() { SeekBy(-10f); }
        public void SeekForward10() { SeekBy(10f); }
        public void SeekForward30() { SeekBy(30f); }
        public void SeekForward60() { SeekBy(60f); }

        private float seekAt = -100f, seekTarget, seekDuration;

        // The same route as YamaPlayer's seek bar (UIController.SetTime): its permission check, ownership, then
        // Controller.SetTime (which sets the video time, syncs it and tells the UI). The video player is never
        // touched from here. Nothing happens when there is nothing to seek in (stopped, loading, live, no duration).
        private void SeekBy(float delta)
        {
            if (controller == null || yamaUI == null) return;
            if (controller.Stopped || controller.IsLoading || controller.SlideMode) return;
            float duration = controller.Duration;
            float current = controller.VideoTime;
            // Presses in quick succession add up: the player may still report the time from before the last seek.
            if (Time.realtimeSinceStartup - seekAt < 1f && duration == seekDuration) current = seekTarget;
            float target = MyListCodec.SeekTarget(current, duration, delta);
            if (target < 0f) return;
            if (!yamaUI.CheckPermission()) return; // YamaPlayer's own rule and its own "no permission" dialog
            controller.TakeOwnership();
            controller.SetTime(target);
            seekAt = Time.realtimeSinceStartup; seekTarget = target; seekDuration = duration;
        }

        public void ApplyLanguage()
        {
            if (localizedTexts != null && localizedKeys != null)
                for (int i = 0; i < localizedTexts.Length && i < localizedKeys.Length; i++)
                    if (localizedTexts[i] != null) localizedTexts[i].text = L(localizedKeys[i]);
        }

        public void Bind(MyListStore value)
        {
            store = value;
            if (adapter != null) adapter.store = value;
            Refresh();
            if (extraViews != null)
                for (int i = 0; i < extraViews.Length; i++)
                    if (Utilities.IsValid(extraViews[i])) extraViews[i].BindShared(value);
            BackfillTitles();
        }

        // An additional UI gets the Store of its primary (the Store itself knows the primary only).
        public void BindShared(MyListStore value)
        {
            store = value;
            Refresh();
        }

        // The view that holds what all UIs of one YamaPlayer share (the running import, "playback was started here").
        public MyListPersistentView Hub() { return primary != null ? primary : this; }

        public void RefreshAll()
        {
            MyListPersistentView hub = Hub();
            hub.Refresh();
            if (hub.extraViews != null)
                for (int i = 0; i < hub.extraViews.Length; i++)
                    if (Utilities.IsValid(hub.extraViews[i])) hub.extraViews[i].Refresh();
        }

        public void StoreChanged()
        {
            // Only problems the user has to act on are shown (as a toast); routine save states are not.
            if (store != null && store.status != lastStoreStatus)
            {
                lastStoreStatus = store.status;
                if (store.corrupt || store.status == "Save send failed. Keep this session open; press Retry save.")
                    FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese));
            }
            Refresh();
            if (extraViews != null)
                for (int i = 0; i < extraViews.Length; i++)
                    if (Utilities.IsValid(extraViews[i])) extraViews[i].StoreChanged();
        }

        // ---------- hiding the internal playback slot in YamaPlayer's playlist list ----------

        public void OnSlotRegistered()
        {
            ApplyPlaylistMask();
            if (extraViews != null)
                for (int i = 0; i < extraViews.Length; i++)
                    if (Utilities.IsValid(extraViews[i])) extraViews[i].ApplyPlaylistMask();
        }

        public override void OnPlaylistsUpdated()
        {
            // YamaPlayer's UI rebuilds the list in the same event; re-apply after every listener ran.
            SendCustomEventDelayedFrames(nameof(ApplyPlaylistMask), 1);
        }

        public void ApplyPlaylistMask()
        {
            if (!mounted || adapter == null || adapter.slotIndex < 0) return;
            int total = controller.Playlists.Length;
            if (total <= adapter.slotIndex) return;
            nativePlaylists.CallbackEvent = UdonEvent.New(this, nameof(RenderNativePlaylists));
            nativePlaylists.Length = total - 1;
        }

        // Rows at or after the slot position show the next playlist, so the slot is never listed.
        // Only YamaPlayer's content pass sees the shifted indexes; LoopScroll keeps its row-position
        // indexes, so scrolling a long list still places every row correctly.
        public void RenderNativePlaylists()
        {
            if (adapter == null || adapter.slotIndex < 0) { yamaUI.UpdatePlaylistsContent(); return; }
            int[] current = nativePlaylists.Indexes;
            int[] last = nativePlaylists.LastIndexes;
            int[] rawCurrent = ShiftForSlot(current);
            int[] rawLast = last == current ? rawCurrent : ShiftForSlot(last);
            yamaUI.UpdatePlaylistsContent();
            DecorateNativeRows(current);
            for (int i = 0; i < current.Length; i++) current[i] = rawCurrent[i];
            if (last != current) for (int i = 0; i < last.Length; i++) last[i] = rawLast[i];
        }

        // Same row format for every playlist: icon / name / "N 曲 · 種別", and the playing source marked.
        // Presentation only (text, colour, icon of YamaPlayer's recycled rows at runtime).
        private void DecorateNativeRows(int[] shifted)
        {
            Transform content = nativePlaylists.GetComponent<ScrollRect>().content;
            Playlist[] lists = controller.Playlists;
            int staticCount = adapter != null && adapter.slotIndex >= 0 ? adapter.slotIndex + 1 : lists.Length;
            for (int i = 0; i < shifted.Length && i < content.childCount; i++)
            {
                int index = shifted[i];
                if (index < 0 || index >= lists.Length) continue;
                Playlist playlist = lists[index];
                if (playlist == null || playlist.IsLoading) continue;
                Transform cell = content.GetChild(i);
                string kind = index >= staticCount ? L("kind_import") : "";
                SetChildText(cell, "TrackCount", L(kind == "" ? "tracks_n" : "tracks_kind").Replace("{n}", playlist.Length.ToString()).Replace("{kind}", kind));
                StyleRow(cell, iconFolder);
            }
        }

        public void DecorateVisibleNativeRows()
        {
            if (!mounted || adapter == null || adapter.slotIndex < 0) return;
            int[] indexes = nativePlaylists.Indexes;
            int[] shifted = new int[indexes.Length];
            for (int i = 0; i < indexes.Length; i++) shifted[i] = indexes[i] >= adapter.slotIndex ? indexes[i] + 1 : indexes[i];
            DecorateNativeRows(shifted);
        }

        // A playlist row (parent) never shows a playing state: always its folder icon and the normal row colour.
        // "Playing" is shown on the track row only (playlist ID + track identity, while the video is playing).
        private void StyleRow(Transform row, Sprite normalIcon)
        {
            Transform mark = row.Find("FolderMark");
            if (mark != null)
            {
                Image image = mark.GetComponent<Image>();
                if (image != null)
                {
                    if (normalIcon != null) image.sprite = normalIcon;
                    image.color = rowTextColor;
                }
            }
            Transform name = row.Find("Text");
            if (name != null) { Text text = name.GetComponent<Text>(); if (text != null) text.color = rowTextColor; }
        }

        // Shifts in place and returns a copy of the original values.
        private int[] ShiftForSlot(int[] indexes)
        {
            int[] raw = new int[indexes.Length];
            for (int i = 0; i < indexes.Length; i++)
            {
                raw[i] = indexes[i];
                if (indexes[i] >= adapter.slotIndex) indexes[i] = indexes[i] + 1;
            }
            return raw;
        }

        // ---------- navigation (driven by YamaPlayer's own buttons through sentinels) ----------

        public void SentinelChanged(int kind, bool shown)
        {
            if (!mounted) return;
            if (kind == 0)
            {
                if (shown)
                {
                    if (selected >= 0) CloseView(false);
                    ApplyPlaylistMask();
                }
                return;
            }
            if (shown)
            {
                if (selected >= 0) CloseView(false);
                UpdateNativeActions();
                SendCustomEventDelayedFrames(nameof(UpdateNativeActions), 1);
            }
            else SetNativeActions(false);
        }

        private Playlist OpenNativePlaylist()
        {
            if (!nativeTracks.activeInHierarchy || playlistTab == null || !playlistTab.isOn) return null;
            object value = yamaUI.GetProgramVariable("_playlistIndex");
            int index = value == null ? -1 : (int)value;
            Playlist[] lists = controller.Playlists;
            if (index < 0 || index >= lists.Length) return null;
            if (adapter != null && lists[index] == adapter.slot) return null;
            return lists[index];
        }

        public void UpdateNativeActions()
        {
            SetNativeActions(selected < 0 && OpenNativePlaylist() != null);
        }

        private float Height(GameObject go) { return go == null ? 0f : ((RectTransform)go.transform).sizeDelta.y; }

        // The DM toolbar takes the top of the list area; YamaPlayer's track list is shifted below
        // it while shown (runtime layout only) and restored for Queue / History / other views.
        private void SetNativeActions(bool show)
        {
            if (!show) HidePicker();
            else if (pickerRoot.activeSelf) return; // the picker currently replaces the track list
            bool changed = nativeActions.activeSelf != show;
            if (changed) nativeActions.SetActive(show);
            RectTransform rect = (RectTransform)nativeTracks.transform;
            rect.offsetMax = show ? new Vector2(nativeTracksTop.x, nativeTracksTop.y - Height(nativeActions)) : nativeTracksTop;
            if (show)
            {
                Playlist playlist = OpenNativePlaylist();
                Transform info = nativeActions.transform.Find("Info");
                SetChildText(info, "Title", L("native_header"));
                SetChildText(info, "Url", L("native_header_sub").Replace("{n}", playlist == null ? "0" : playlist.Length.ToString()));
                if (changed) ResetRow(nativeActions);
            }
        }

        private void ResetRow(GameObject row)
        {
            Animator animator = row.GetComponent<Animator>();
            if (animator != null) animator.SetTrigger("Reset");
        }

        private void LayoutPersistent()
        {
            RectTransform rect = (RectTransform)trackScroll.transform;
            rect.offsetMax = new Vector2(rect.offsetMax.x, -Height(persistentActions));
        }

        public void OpenPlaylist(int index)
        {
            if (index == -1) { ToggleCreateMenu(); return; }
            if (index == -2) { createMenuOpen = false; OpenCreate(); Refresh(); return; }
            if (index == -3)
            {
                // While an import is running (or waiting in VRChat's queue) the row shows it; a tap offers to stop it.
                if (Hub().importJob != null) OpenImportCancel(); else ToggleAddMenu();
                return;
            }
            if (store == null || !store.Editable() || index < 0 || index >= store.playlistIds.Length) return;
            selected = index;
            selectedId = store.playlistIds[index];
            addMenuOpen = false;
            yamaUI.SetProgramVariable("_playlistIndex", -1);
            nativePlaylists.gameObject.SetActive(false);
            nativeTracks.SetActive(false);
            SetNativeActions(false);
            trackScroll.gameObject.SetActive(true);
            persistentActions.SetActive(true);
            ResetRow(persistentActions);
            LayoutPersistent();
            if (controlAnimator != null) controlAnimator.SetTrigger("ShowPlaylistTitle");
            lastRenderedSelected = -2;
            Refresh();
            trackScroll.ScrollToTop();
        }

        public void ToggleCreateMenu()
        {
            createMenuOpen = !createMenuOpen;
            ResolveCreateRowInput();
            if (createMenuOpen && createRowNameInput != null) createRowNameInput.text = "";
            if (createMenuOpen && store != null && store.Editable() && store.playlistIds.Length >= MyListCodec.MaxPlaylists && !nativeImportAvailable)
                Feedback("playlist_limit");
            Refresh();
            // The choices open below the row, at the very end of the list: with many playlists that is below the visible
            // part, so the list is moved just far enough (now and once more after the layout pass).
            if (createMenuOpen)
            {
                RevealCreateMenu();
                createRevealY = CreateListY();
                SendCustomEventDelayedFrames(nameof(RevealCreateMenuLater), 1);
            }
        }

        private float CreateListY()
        {
            ScrollRect scroll = nativePlaylists == null ? null : nativePlaylists.GetComponent<ScrollRect>();
            return scroll == null || scroll.content == null ? 0f : scroll.content.anchoredPosition.y;
        }

        // The second pass, after the layout pass of the frame the menu was opened in. Only when the list is still
        // where the first pass left it: once the user has scrolled, the list is theirs.
        public void RevealCreateMenuLater()
        {
            if (Mathf.Abs(CreateListY() - createRevealY) > 0.5f) return;
            RevealCreateMenu();
        }

        // Scrolls YamaPlayer's playlist list down just as far as the lowest open choice of "新しいプレイリストを作成"
        // needs (nothing when it is visible already). Standard ScrollRect position; the rows are then placed by the
        // list's own scroll handling (LoopScroll.OnScroll).
        public void RevealCreateMenu()
        {
            if (!mounted || !createMenuOpen || createRow == null || nativePlaylists == null) return;
            // only while the playlist list is what the user is looking at (not after leaving it, not with a playlist open)
            if (selected >= 0 || !nativePlaylists.gameObject.activeInHierarchy || !createRow.gameObject.activeInHierarchy) return;
            ScrollRect scroll = nativePlaylists.GetComponent<ScrollRect>();
            if (scroll == null || scroll.content == null) return;
            // the visible height: the viewport, or the list's own rectangle (what YamaPlayer's LoopScroll measures) when the viewport has no size yet
            RectTransform window = scroll.viewport != null && scroll.viewport.rect.height > 1f ? scroll.viewport : (RectTransform)scroll.transform;
            RectTransform lowest = (RectTransform)createRow.transform;
            if (createImportRow != null && createImportRow.activeSelf) lowest = Lower(lowest, (RectTransform)createImportRow.transform);
            if (createPersistentRow != null && createPersistentRow.gameObject.activeSelf) lowest = Lower(lowest, (RectTransform)createPersistentRow.transform);
            // rows are anchored to the top of the content: -y is the distance from the top
            float bottom = -lowest.anchoredPosition.y + lowest.rect.height;
            float shown = scroll.content.anchoredPosition.y + window.rect.height;
            if (bottom <= shown + 0.5f) return;
            float limit = Mathf.Max(0f, scroll.content.rect.height - window.rect.height);
            scroll.content.anchoredPosition = new Vector2(scroll.content.anchoredPosition.x, Mathf.Min(limit, bottom - window.rect.height));
            nativePlaylists.OnScroll();
        }

        private RectTransform Lower(RectTransform a, RectTransform b) { return b.anchoredPosition.y < a.anchoredPosition.y ? b : a; }

        // Scrolls the open list to its end so that the opened "追加する" choices are visible (standard ScrollRect
        // position; the rows are then placed by the list's own scroll handling). Closing needs nothing: the
        // ScrollRect keeps the shorter content inside the view by itself.
        public void RevealAddMenu()
        {
            if (!addMenuOpen || selected < 0 || trackScroll == null) return;
            ScrollRect scroll = trackScroll.GetComponent<ScrollRect>();
            if (scroll == null || scroll.content == null || scroll.viewport == null) return;
            if (scroll.content.rect.height <= scroll.viewport.rect.height) return; // everything is visible already
            scroll.verticalNormalizedPosition = 0f;
            trackScroll.OnScroll();
        }

        // "追加する >" at the end of an open persistent playlist: shows / hides the two URL choices.
        public void ToggleAddMenu()
        {
            addMenuOpen = !addMenuOpen;
            Refresh();
        }

        // IMPORT_CONTEXT = TEMPORARY_NATIVE: exactly what YamaPlayer's own "Add Youtube Playlist" row does
        // (UIController.AddDynamicPlaylist): same URL rule (VRCUrl.IsValid), same two calls, the URL passed on
        // unchanged. Used only by the create menu outside a persistent playlist; it never writes to the Store.
        // An import into a persistent playlist (StartPlaylistImport) never comes here.
        private Playlist NativeImport(VRCUrl url)
        {
#if UNITY_ANDROID
            Feedback("android_import_unavailable"); return null;
#endif
            if (controller == null || url == null || !url.IsValid()) return null;
            controller.TakeOwnership();
            int listsBefore = controller.Playlists.Length;
            controller.AddDynamicPlaylist(url);
            Playlist[] lists = controller.Playlists;
            Debug.Log("[DM MyList] import TEMPORARY_NATIVE: Controller.AddDynamicPlaylist called, YamaPlayer playlists " + listsBefore + " -> " + lists.Length + ", saved tracks " + (store != null ? store.savedUrls.Length : -1));
            return lists.Length == 0 ? null : lists[lists.Length - 1];
        }

        // Choice 1 of "新しいプレイリストを作成": a standard (temporary, shared) YamaPlayer playlist.
        public void CreateImportEntered()
        {
#if UNITY_ANDROID
            Feedback("android_import_unavailable"); return;
#endif
            VRCUrl url = createImportInput.GetUrl();
            createImportInput.SetUrl(VRCUrl.Empty);
            if (NativeImport(url) == null) return;
            createMenuOpen = false;
            Refresh();
        }

        // Header row "リストを上へ / 下へ": the order of the persistent playlists themselves (not of the videos).
        public void MovePlaylistUp() { MoveOpenPlaylist(-1); }
        public void MovePlaylistDown() { MoveOpenPlaylist(1); }

        private void MoveOpenPlaylist(int delta)
        {
            if (selected < 0 || store == null || !store.Editable()) return;
            int id = store.playlistIds[selected];
            int before = selected;
            store.MovePlaylist(id, delta);
            selected = store.PlaylistIndex(id);
            Refresh();
            if (selected != before)
                DoneText(L("playlist_moved").Replace("{name}", store.playlistNames[selected]).Replace("{n}", (selected + 1).ToString()).Replace("{total}", store.playlistIds.Length.ToString()));
        }

        // Called by the DM view itself (after delete) or when a YamaPlayer view becomes visible.
        private void CloseView(bool restoreList)
        {
            selected = -1;
            selectedId = -1;
            addMenuOpen = false;
            trackScroll.gameObject.SetActive(false);
            persistentActions.SetActive(false);
            if (restoreList)
            {
                nativeTracks.SetActive(false);
                nativePlaylists.gameObject.SetActive(true);
                if (controlAnimator != null) controlAnimator.SetTrigger("HidePlaylistTitle");
            }
            Refresh();
        }

        // ---------- rendering ----------

        public void Refresh()
        {
            if (!mounted) return;
            bool ready = store != null && store.Editable();
            int count = ready ? store.playlistIds.Length : 0;
            for (int i = 0; i < playlistRows.Length; i++)
            {
                MyListNativePlaylistRow row = playlistRows[i];
                if (row == null) continue;
                bool show = i < count;
                if (row.gameObject.activeSelf != show) row.gameObject.SetActive(show);
                if (!show) continue;
                row.index = i;
                SetChildText(row.transform, "Text", store.playlistNames[i]);
                SetChildText(row.transform, "TrackCount", L("tracks_kind").Replace("{n}", CountTracks(store.playlistIds[i]).ToString()).Replace("{kind}", L("kind_persistent")));
                StyleRow(row.transform, iconPersistent);
            }
            if (createRow != null)
            {
                if (!createRow.gameObject.activeSelf) createRow.gameObject.SetActive(true);
                if (createChevron != null) createChevron.localEulerAngles = new Vector3(0, 0, createMenuOpen ? -90f : 0f);
                bool showImport = createMenuOpen && nativeImportAvailable;
#if UNITY_ANDROID
                showImport = false;
#endif
                if (createImportRow != null && createImportRow.activeSelf != showImport) createImportRow.SetActive(showImport);
                // No local playlist yet: the row says so (its own second line, hidden otherwise). Not while the saved
                // data is still being restored or is locked - "none" would be wrong then.
                Transform hint = createRow.transform.Find("TrackCount");
                if (hint != null)
                {
                    bool showHint = ready && count == 0;
                    if (hint.gameObject.activeSelf != showHint) hint.gameObject.SetActive(showHint);
                    if (showHint) SetChildText(createRow.transform, "TrackCount", L("no_local_playlists"));
                    // With the second line shown, the title sits where the title of a two-line row sits (the playlist
                    // rows); alone it stays where the prefab has it (centred). Otherwise the two lines overlap.
                    Transform title = createRow.transform.Find("Text");
                    Transform twoLine = playlistRows.Length > 0 && playlistRows[0] != null ? playlistRows[0].transform.Find("Text") : null;
                    if (title != null && twoLine != null)
                    {
                        RectTransform titleRect = (RectTransform)title;
                        if (!createTitleKnown) { createTitleY = titleRect.anchoredPosition.y; createTitleKnown = true; }
                        float y = showHint ? ((RectTransform)twoLine).anchoredPosition.y : createTitleY;
                        if (titleRect.anchoredPosition.y != y) titleRect.anchoredPosition = new Vector2(titleRect.anchoredPosition.x, y);
                    }
                }
                bool showPersistent = createMenuOpen && ready && count < MyListCodec.MaxPlaylists;
                if (createPersistentRow != null && createPersistentRow.gameObject.activeSelf != showPersistent) createPersistentRow.gameObject.SetActive(showPersistent);
            }
            DecorateVisibleNativeRows();
            nativePlaylists.Render();
            // The Store can be changed from another UI (order, delete): the open playlist is followed by its ID.
            if (selected >= 0 && ready && selectedId >= 0 && (selected >= count || store.playlistIds[selected] != selectedId))
            {
                int now = store.PlaylistIndex(selectedId);
                if (now < 0) { CloseView(trackScroll.gameObject.activeSelf); return; }
                selected = now;
                lastRenderedSelected = -2;
            }
            if (selected >= count) selected = -1;
            if (selected >= 0 && ready)
            {
                PrepareRenameRowInput();
                if (nativeName != null) nativeName.text = store.playlistNames[selected];
                int n = PopulateVisible();
                int rows = n + PopulatePending();
                Transform header = persistentActions.transform.Find("Info");
                SetChildText(header, "Title", L("playlist_header"));
                SetChildText(header, "Url", L("playlist_header_sub").Replace("{n}", n.ToString()));
                // First / last playlist: the order buttons are disabled (YamaPlayer's own disabled button look).
                if (movePlaylistUpButton != null) movePlaylistUpButton.interactable = selected > 0;
                if (movePlaylistDownButton != null) movePlaylistDownButton.interactable = selected < count - 1;
                bool footerChanged = false;
                if (addChevron != null) addChevron.localEulerAngles = new Vector3(0, 0, addMenuOpen ? -90f : 0f);
                UpdateAddRow();
                if (videoUrlInput.gameObject.activeSelf != addMenuOpen) { videoUrlInput.gameObject.SetActive(addMenuOpen); footerChanged = true; }
                #if UNITY_ANDROID
                if (playlistUrlInput.gameObject.activeSelf) { playlistUrlInput.gameObject.SetActive(false); footerChanged = true; }
#else
                if (playlistUrlInput.gameObject.activeSelf != addMenuOpen) { playlistUrlInput.gameObject.SetActive(addMenuOpen); footerChanged = true; }
#endif
                if (selected != lastRenderedSelected || store.dataVersion != lastRenderedVersion || rows != lastRenderedRows)
                {
                    lastRenderedSelected = selected; lastRenderedVersion = store.dataVersion; lastRenderedRows = rows;
                    trackScroll.CallbackEvent = UdonEvent.New(this, nameof(RenderTracks));
                    trackScroll.Length = rows;
                }
                else if (footerChanged) trackScroll.Render(); // re-places the rows after the list (YamaPlayer LoopScroll)
                else RenderTracks();
                // The choices are part of the list's height. In a long list they open below the visible part, so the
                // list is moved to its end (now and once more after the layout pass).
                if (footerChanged && addMenuOpen) { RevealAddMenu(); SendCustomEventDelayedFrames(nameof(RevealAddMenu), 1); }
            }
        }

        // Videos of the open playlist that are waiting for their title: listed after the saved videos.
        private int PopulatePending()
        {
            if (store == null || selected < 0 || selected >= store.playlistIds.Length) return 0;
            int id = store.playlistIds[selected], m = 0;
            for (int i = 0; i < pendCount; i++)
                if (!pendBackfill[i] && pendLists[i] == id) pendVisible[m++] = i;
            return m;
        }

        private void SetChildText(Transform parent, string name, string value)
        {
            if (parent == null) return;
            Transform child = parent.Find(name);
            if (child == null) return;
            Text text = child.GetComponent<Text>();
            if (text != null) text.text = value;
        }

        private int CountTracks(int playlistId)
        {
            int n = 0;
            for (int i = 0; i < store.savedUrls.Length; i++) if (store.trackPlaylists[i] == playlistId) n++;
            return n;
        }

        private int PopulateVisible()
        {
            if (store == null || selected < 0 || selected >= store.playlistIds.Length) return 0;
            int id = store.playlistIds[selected], n = 0;
            for (int i = 0; i < store.savedUrls.Length; i++)
                if (store.trackPlaylists[i] == id) visible[n++] = i;
            return n;
        }

        public void RenderTracks()
        {
            if (store == null || selected < 0) return;
            int n = PopulateVisible();
            int rows = n + PopulatePending();
            int playing = PlayingPosition(n);
            RectTransform content = trackScroll.GetComponent<ScrollRect>().content;
            int[] indexes = trackScroll.Indexes;
            for (int i = 0; i < trackScroll.LineCount; i++)
            {
                int position = indexes[i];
                if (position < 0 || position >= rows) continue;
                Transform cell = content.GetChild(i);
                MyListNativeTrackRow row = cell.GetComponent<MyListNativeTrackRow>();
                if (row == null) continue;
                row.owner = this;
                row.index = position;
                // A row after the saved videos = a video waiting for its title (not saved yet).
                int pending = position >= n ? pendVisible[position - n] : -1;
                int state = pending < 0 ? -1 : pendStates[pending];
                Transform info = cell.Find("Info");
                if (info != null)
                {
                    string title;
                    if (pending >= 0) title = L(state == 0 ? "title_lookup_pending" : "title_failed_row");
                    else
                    {
                        int data = visible[position];
                        title = IsTitlePending(data) ? L("title_lookup_pending") :
                            string.IsNullOrEmpty(store.titles[data]) ? L("untitled") : store.titles[data];
                    }
                    bool isPlaying = position == playing;
                    SetChildText(info, "Title", title);
                    Transform titleText = info.Find("Title");
                    if (titleText != null) titleText.GetComponent<Text>().color = isPlaying ? yamaUI.PrimaryColor : pending >= 0 ? rowTextColor : Color.white;
                    SetChildText(info, "No", pending >= 0 ? "" : (position + 1).ToString());
                    Transform no = info.Find("No");
                    if (no != null) no.gameObject.SetActive(!isPlaying);
                    // Second line: only for a waiting video (which URL it is / why it cannot be registered).
                    Transform url = info.Find("Url");
                    if (url != null) url.gameObject.SetActive(pending >= 0);
                    if (pending >= 0)
                        SetChildText(info, "Url", state == 2 ? L("title_form_hint") : state == 3 ? L("title_site_hint") : state == 1 ? L("title_failed_hint") : pendUrls[pending].Get());
                    Transform mark = info.Find("PlayingMark");
                    if (mark != null) mark.gameObject.SetActive(isPlaying);
                }
                Transform actions = cell.Find("Actions");
                if (actions != null)
                {
                    // Labels are set per recycled cell (the cells are cloned from the template at runtime).
                    // A video whose title could not be read offers: retry / enter a title and save / enter the URL again / cancel.
                    Transform play = actions.Find("Play"), add = actions.Find("Add"), next = actions.Find("Next");
                    Transform up = actions.Find("Up"), down = actions.Find("Down");
                    SetChildText(actions.Find("Return"), "Text", L("back"));
                    SetChildText(play, "Text", L(pending >= 0 ? "retry" : "play"));
                    SetChildText(add, "Text", L(pending >= 0 ? "manual_title_action" : "queue"));
                    SetChildText(next, "Text", L(pending >= 0 ? "reenter_url" : "play_next"));
                    SetChildText(up, "Text", L("up"));
                    SetChildText(down, "Text", L("down"));
                    SetChildText(actions.Find("Remove"), "Text", L(pending >= 0 ? "cancel" : "remove"));
                    if (play != null) play.gameObject.SetActive(pending < 0 || state != 0);
                    if (add != null) add.gameObject.SetActive(pending < 0 || state != 0);
                    if (next != null) next.gameObject.SetActive(pending < 0 || state != 0);
                    if (up != null) { up.gameObject.SetActive(pending < 0); up.GetComponent<Button>().interactable = position > 0; }
                    if (down != null) { down.gameObject.SetActive(pending < 0); down.GetComponent<Button>().interactable = position < n - 1; }
                }
                Animator animator = cell.GetComponent<Animator>();
                if (animator != null) animator.SetTrigger("Reset");
            }
        }

        // ---------- playing mark (local only: source playlist ID + track position) ----------

        private bool SlotActive()
        {
            if (!Hub().startedHere || adapter == null || adapter.slotIndex < 0 || controller == null) return false;
            return controller.ActivePlaylist == adapter.slot;
        }

        private int PlayingPlaylistId() { return SlotActive() ? adapter.snapshotPlaylistId : -1; }

        private int PlayingPosition(int visibleCount)
        {
            if (!SlotActive() || !controller.IsPlaying || store == null || selected < 0 || store.playlistIds[selected] != adapter.snapshotPlaylistId) return -1;
            int p = controller.PlayingTrackIndex;
            if (p < 0 || p >= visibleCount || p >= adapter.snapshotKeys.Length) return -1;
            int data = visible[p];
            // Position identity, confirmed against the snapshot in case the Store was edited since.
            return MyListCodec.TrackKey(store.savedUrls[data], store.originals[data]) == adapter.snapshotKeys[p] ? p : -1;
        }

        public override void OnUrlChanged()
        {
            MyListPersistentView hub = Hub();
            if (hub.startedHere && (adapter == null || controller.ActivePlaylist != adapter.slot)) hub.startedHere = false;
            Refresh(); // also re-marks YamaPlayer's own playlist rows
            if (hub == this) F1bUrlChanged();
        }

        public override void OnVideoStart() { Refresh(); if (Hub() == this) F1bVideoStart(); }
        public override void OnVideoPlay() { Refresh(); }
        public override void OnVideoPause() { Refresh(); }
        public override void OnVideoEnd() { Refresh(); }
        public override void OnVideoStop() { Refresh(); if (Hub() == this) F1bVideoStop(); }
        public override void OnVideoError(VideoError videoError) { if (Hub() == this) F1bVideoError(videoError); }

        // ---------- F1b "play again" (Docs/F1B_PLAY_AGAIN_SPEC.md, Docs/F1B_IMPLEMENTATION_PLAN.md) ----------
        // A manual rescue after a failed WebUnit playback. DM never starts anything by itself: only a press calls
        // YamaPlayer's own Controller.PlayTrack(current track, false), once. Queue, playlists, saved data and the
        // playback slot are never touched. Listener events reach every view; the state changes on Hub() only.
        // Event names start with "_" so that they cannot be called as network events.

        private void F1bSetState(int state)
        {
            f1bState = state;
            f1bAttempt++;
            f1bNotice = "";
#if DM_F1B_DIAG
            Debug.Log("[DM DIAG] F1b state=" + state + " gen=" + f1bGen + " presses=" + f1bPresses + " attempt=" + f1bAttempt + " t=" + Time.realtimeSinceStartup.ToString("F3"));
#endif
        }

        // External request: a new observed request (count back to 0, timers no longer valid, panel hidden).
        private void F1bUrlChanged()
        {
            if (f1bOwnCall) return;
            f1bGen++;
            f1bPresses = 0;
            f1bTitle = "";
            if (f1bState != MyListPlayAgainRules.Idle) F1bSetState(MyListPlayAgainRules.Idle);
            f1bWarnUntil = 0f;
            if (f1bInFlight)
            {
                // Plan 3.1: DM's request may still finish and YamaPlayer would play it without checking the track.
                f1bWarnUntil = Time.realtimeSinceStartup + MyListPlayAgainRules.WarningSeconds;
                if (MyListPlayAgainRules.NeedsSchedule(f1bWarnPending))
                {
                    f1bWarnPending = true;
                    SendCustomEventDelayedSeconds(nameof(_F1bWarnTimer), MyListPlayAgainRules.WarningSeconds);
                }
#if DM_F1B_DIAG
                Debug.Log("[DM DIAG] F1b track changed while in flight t=" + Time.realtimeSinceStartup.ToString("F3"));
#endif
            }
            _F1bRenderAll();
        }

        private void F1bVideoStart()
        {
#if DM_F1B_DIAG
            Debug.Log("[DM DIAG] F1b video start duration=" + controller.Duration.ToString("F1") + " inFlight=" + f1bInFlight + " t=" + Time.realtimeSinceStartup.ToString("F3"));
#endif
            if (f1bState == MyListPlayAgainRules.Idle) return;
            F1bSetState(MyListPlayAgainRules.Idle);
            _F1bRenderAll();
        }

        // Only a stop outside DM's own call counts (PlayTrack stops the previous video itself).
        private void F1bVideoStop()
        {
            if (f1bOwnCall || f1bState == MyListPlayAgainRules.Idle) return;
            F1bSetState(MyListPlayAgainRules.Idle);
            _F1bRenderAll();
        }

        private void F1bVideoError(VideoError videoError)
        {
            if (videoError != VideoError.PlayerError || controller == null || playbackGuard == null) return;
            Track track = controller.Track;
            if (!playbackGuard.IsF1bTarget(track)) return; // not a target: the state and the panel stay as they are
            int next = MyListPlayAgainRules.OnTargetError(f1bState, f1bPresses);
            if (next == f1bState) return;                   // a duplicate notice of the same failure
            F1bSetState(next);
            f1bTitle = track.GetTitle();
            f1bWarnUntil = 0f;                              // a failure wins over the warning
            if (next == MyListPlayAgainRules.ArmWait)
            {
                f1bArmGen = f1bGen; f1bArmAttempt = f1bAttempt;
                f1bArmDue = Time.realtimeSinceStartup + MyListPlayAgainRules.ArmDelaySeconds;
                if (MyListPlayAgainRules.NeedsSchedule(f1bArmPending))
                {
                    f1bArmPending = true;
                    SendCustomEventDelayedSeconds(nameof(_F1bArmTimer), MyListPlayAgainRules.ArmDelaySeconds);
                }
            }
            _F1bRenderAll();
        }

        // The single queued event of a timer: it reads the newest timer data. Before the due time it queues itself
        // again for the rest (it never acts early; spec 4). The caller keeps the timer's pending flag.
        private int F1bTimerCheck(int timerGen, int timerAttempt, float due, string eventName)
        {
            float now = Time.realtimeSinceStartup;
            int check = MyListPlayAgainRules.TimerCheck(f1bGen, f1bAttempt, timerGen, timerAttempt, now, due);
            if (check == MyListPlayAgainRules.TimerEarly) SendCustomEventDelayedSeconds(eventName, Mathf.Max(due - now, 0.01f));
            return check;
        }

        public void _F1bArmTimer()
        {
            if (Hub() != this) return;
            int check = F1bTimerCheck(f1bArmGen, f1bArmAttempt, f1bArmDue, nameof(_F1bArmTimer));
            f1bArmPending = check == MyListPlayAgainRules.TimerEarly;
            if (check != MyListPlayAgainRules.TimerDue) return;
            int next = MyListPlayAgainRules.OnArmTimer(f1bState);
            if (next == f1bState) return;
            F1bSetState(next);
            _F1bRenderAll();
        }

        public void _F1bTimeoutTimer()
        {
            if (Hub() != this) return;
            int check = F1bTimerCheck(f1bTimeoutGen, f1bTimeoutAttempt, f1bTimeoutDue, nameof(_F1bTimeoutTimer));
            f1bTimeoutPending = check == MyListPlayAgainRules.TimerEarly;
            if (check != MyListPlayAgainRules.TimerDue) return;
            int next = MyListPlayAgainRules.OnNoResponseTimer(f1bState, f1bPresses);
            if (next == f1bState) return;
            F1bSetState(next);
            if (next == MyListPlayAgainRules.Armed) f1bNotice = "f1b_no_response";
            _F1bRenderAll();
        }

        public void _F1bWarnTimer()
        {
            if (Hub() != this) return;
            f1bWarnPending = false;
            if (f1bWarnUntil <= 0f) return;
            float now = Time.realtimeSinceStartup;
            if (now < f1bWarnUntil)
            {
                f1bWarnPending = true;
                SendCustomEventDelayedSeconds(nameof(_F1bWarnTimer), Mathf.Max(f1bWarnUntil - now, 0.01f));
                return;
            }
            f1bWarnUntil = 0f;
            _F1bRenderAll();
        }

        // In-flight tracking of DM's own request (plan 3.1, spec 5 check 10): it ends only when the Client that took the
        // request is seen idle or no longer exists. A busy Client (also a disabled one) keeps it running. Every second
        // for the first 120 s, every 5 s after that. A timeout, the Idle state, video events or time never end it.
        public void _F1bInFlightWatch()
        {
            f1bWatchScheduled = false;
            if (Hub() != this || !f1bInFlight) return;
            int client = playbackGuard != null ? playbackGuard.F1bClientState(f1bClient) : MyListPlayAgainRules.ClientUnknown;
            float elapsed = Time.realtimeSinceStartup - f1bInFlightSince;
            if (MyListPlayAgainRules.InFlightEnds(client))
            {
                f1bInFlight = false;
#if DM_F1B_DIAG
                Debug.Log("[DM DIAG] F1b in flight end after " + elapsed.ToString("F1") + " s");
#endif
                // a refusal that named the open request is no longer true
                if (f1bNotice == "f1b_previous_open" || f1bNotice == "webunit_busy") { f1bNotice = ""; _F1bRenderAll(); }
                return;
            }
            if (!f1bLongNoted && elapsed >= MyListPlayAgainRules.WatchFastWindowSeconds)
            {
                f1bLongNoted = true;   // "not finished or unknown": tracking (and the warning on a track change) goes on
                Debug.LogWarning("[DM MyList] F1b: the play again request is not finished after 120 s (" + (client == MyListPlayAgainRules.ClientBusy ? "WebUnit busy" : "WebUnit state unknown") + "). Play again stays unavailable until it finishes.");
            }
            f1bWatchScheduled = true;
            SendCustomEventDelayedSeconds(nameof(_F1bInFlightWatch), elapsed < MyListPlayAgainRules.WatchFastWindowSeconds
                ? MyListPlayAgainRules.WatchFastSeconds : MyListPlayAgainRules.WatchSlowSeconds);
        }

        // The button of any view: the press is handled by the primary view.
        public void _F1bPlayAgain() { Hub()._F1bPress(); }

        public void _F1bPress()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            return;
#endif
            if (Hub() != this || controller == null || f1bOwnCall) return;
            Track track = controller.Track;
            bool target = playbackGuard != null && playbackGuard.IsF1bTarget(track);
            // Busy: the current Client, or DM's previous request not known to be finished (its Client may differ).
            int previous = playbackGuard != null ? playbackGuard.F1bClientState(f1bClient) : MyListPlayAgainRules.ClientUnknown;
            if (f1bInFlight && MyListPlayAgainRules.InFlightEnds(previous)) f1bInFlight = false;
            bool busy = (playbackGuard != null && playbackGuard.WebUnitBusy()) || MyListPlayAgainRules.PreviousRequestOpen(f1bInFlight, previous);
            int result = MyListPlayAgainRules.CheckPress(f1bState, f1bPresses, target,
                controller.IsLoading, controller.IsPlaying, busy,
                controller.VideoPlayerType == track.GetPlayerType(), controller.IsReload,
                Networking.IsOwner(controller.gameObject), (int)controller.PlayerPermission >= (int)PlayerPermission.Editor);
            if (result != MyListPlayAgainRules.PressOk)
            {
#if DM_F1B_DIAG
                Debug.Log("[DM DIAG] F1b press refused result=" + result);
#endif
                string key = MyListPlayAgainRules.PressRefusalKey(result);
                if (result == MyListPlayAgainRules.PressBusy)
                    key = MyListPlayAgainRules.BusyKey(MyListPlayAgainRules.PreviousRequestOpen(f1bInFlight, previous), Time.realtimeSinceStartup - f1bInFlightSince);
                if (key != "" && f1bState == MyListPlayAgainRules.Armed) { f1bNotice = key; _F1bRenderAll(); }
                return;
            }
            f1bPresses++;
            F1bSetState(MyListPlayAgainRules.Preparing);
            f1bTimeoutGen = f1bGen; f1bTimeoutAttempt = f1bAttempt;
            f1bTimeoutDue = Time.realtimeSinceStartup + MyListPlayAgainRules.NoResponseSeconds;
            if (MyListPlayAgainRules.NeedsSchedule(f1bTimeoutPending))
            {
                f1bTimeoutPending = true;
                SendCustomEventDelayedSeconds(nameof(_F1bTimeoutTimer), MyListPlayAgainRules.NoResponseSeconds);
            }
            f1bInFlight = true;
            f1bInFlightSince = Time.realtimeSinceStartup;
            f1bLongNoted = false;
            f1bClient = playbackGuard.F1bRequestClient();
            if (!f1bWatchScheduled)
            {
                f1bWatchScheduled = true;
                SendCustomEventDelayedSeconds(nameof(_F1bInFlightWatch), MyListPlayAgainRules.WatchFastSeconds);
            }
            _F1bRenderAll();
#if DM_F1B_DIAG
            Debug.Log("[DM DIAG] F1b PlayTrack call presses=" + f1bPresses + " t=" + Time.realtimeSinceStartup.ToString("F3"));
#endif
            f1bOwnCall = true;
            controller.PlayTrack(track, false);
            f1bOwnCall = false;
        }

        // Shows the state of this hub on every view (each in its own language).
        public void _F1bRenderAll()
        {
            int show = MyListPlayAgainRules.Display(f1bState, f1bWarnUntil > Time.realtimeSinceStartup);
            int left = MyListPlayAgainRules.MaxPresses - f1bPresses;
            _F1bRender(show, f1bTitle, left, f1bNotice);
            if (extraViews != null)
                for (int i = 0; i < extraViews.Length; i++)
                    if (Utilities.IsValid(extraViews[i])) extraViews[i]._F1bRender(show, f1bTitle, left, f1bNotice);
        }

        public void _F1bRender(int show, string title, int left, string notice)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            if (retryPanel != null) retryPanel.SetActive(false); return;
#endif
            if (retryPanel == null) return;
            if (!f1bMounted || show == MyListPlayAgainRules.ShowNothing) { retryPanel.SetActive(false); return; }
            bool button = show == MyListPlayAgainRules.ShowArmWait || show == MyListPlayAgainRules.ShowArmed || show == MyListPlayAgainRules.ShowPreparing;
            string line = string.IsNullOrEmpty(title) ? "" : "\n" + title;
            string text;
            if (show == MyListPlayAgainRules.ShowArmWait) text = L("f1b_wait") + line;
            else if (show == MyListPlayAgainRules.ShowArmed) text = (notice != "" ? L(notice) : L("f1b_hint")) + line;
            else if (show == MyListPlayAgainRules.ShowPreparing) text = L("f1b_preparing");
            else if (show == MyListPlayAgainRules.ShowExhausted) text = L("f1b_exhausted");
            else text = L("f1b_track_changed");
            if (retryText != null) retryText.text = text;
            if (retryButton != null)
            {
                retryButton.gameObject.SetActive(button);
                retryButton.interactable = show == MyListPlayAgainRules.ShowArmed;
            }
            if (retryButtonText != null)
                retryButtonText.text = show == MyListPlayAgainRules.ShowArmed ? L("f1b_play_again_n").Replace("{n}", left.ToString()) : L("f1b_play_again");
            retryPanel.transform.SetAsLastSibling();
            retryPanel.SetActive(true);
        }

        // ---------- track actions ----------

        private int DataIndex(int position)
        {
            int n = PopulateVisible();
            return position >= 0 && position < n ? visible[position] : -1;
        }

        private Track SavedTrack(int data)
        {
            return Track.New((VideoPlayerType)store.players[data], store.titles[data], store.savedUrls[data], store.originals[data]);
        }

        // The waiting video shown at row `position` (-1 for a saved video).
        private int PendingAt(int position)
        {
            int n = PopulateVisible();
            int m = PopulatePending();
            return position >= n && position < n + m ? pendVisible[position - n] : -1;
        }

        public void PlayPosition(int position)
        {
            int pending = PendingAt(position);
            if (pending >= 0) { RetryPending(pending); return; }
            int data = DataIndex(position);
            if (data < 0 || adapter == null) return;
            adapter.store = store;
            lastFeedback = "";
            if (playbackGuard != null) playbackGuard.view = this; // a refusal is explained on the UI that asked
            if (!adapter.PlaySavedTrack(data))
            {
                if (lastFeedback == "") Feedback("playback_unavailable");
                return;
            }
            Hub().startedHere = true;
            Done("play_requested");
            RefreshAll();
        }

        // Playlist-level "play from start".
        public void PlayAll()
        {
            if (selected < 0) return;
            if (PopulateVisible() == 0) { Feedback("playlist_empty"); return; }
            PlayPosition(0);
        }

        private bool QueueAllowed()
        {
            if (controller == null || controller.Queue == null) { Feedback("yama_missing"); return false; }
            if ((int)controller.PlayerPermission < (int)PlayerPermission.Editor) { Feedback("yama_locked"); return false; }
            return true;
        }

        private bool CanQueueTrack(Track track)
        {
            return playbackGuard == null ? !VRCUrl.IsNullOrEmpty(track.GetVRCUrl()) : playbackGuard.CanQueue(track);
        }

        public void QueuePosition(int position)
        {
            int pending = PendingAt(position);
            if (pending >= 0) { OpenManualTitle(pending); return; }
            int data = DataIndex(position);
            if (data < 0 || !QueueAllowed()) return;
            Track track = SavedTrack(data);
            if (!CanQueueTrack(track)) return;
            Playlist queue = controller.Queue;
            queue.TakeOwnership();
            queue.Tracks.Add(track);
            queue.SendEvent();
            Done("added_queue");
        }

        public void PlayNextPosition(int position)
        {
            int pending = PendingAt(position);
            if (pending >= 0) { ReenterPending(pending); return; }
            int data = DataIndex(position);
            if (data < 0 || !QueueAllowed()) return;
            Track track = SavedTrack(data);
            if (!CanQueueTrack(track)) return;
            Playlist queue = controller.Queue;
            queue.TakeOwnership();
            // YamaPlayer has no "play next" call: the front of its own Queue is played next.
            if (queue.Length == 0) queue.Tracks.Add(track); else queue.Tracks.Insert(0, track);
            queue.SendEvent();
            Done("play_next_done");
        }

        // Playlist-level "queue all".
        public void QueueAll()
        {
            if (selected < 0 || !QueueAllowed()) return;
            int n = PopulateVisible();
            if (n == 0) { Feedback("playlist_empty"); return; }
            Playlist queue = controller.Queue;
            queue.TakeOwnership();
            int added = 0;
            for (int i = 0; i < n; i++)
            {
                Track track = SavedTrack(visible[i]);
                if (!CanQueueTrack(track)) continue;
                queue.Tracks.Add(track);
                added++;
            }
            if (added == 0) return;
            queue.SendEvent();
            DoneText(L("added_queue_n").Replace("{n}", added.ToString()));
        }

        public void MovePosition(int position, int delta)
        {
            int data = DataIndex(position);
            if (data >= 0 && store.Editable()) store.Move(data, delta);
        }

        public void RemovePosition(int position)
        {
            int pending = PendingAt(position);
            if (pending >= 0) { RemovePending(pending); Refresh(); return; }
            int data = DataIndex(position);
            if (data >= 0 && store.Editable()) store.RemoveAt(data);
        }

        // ---------- URL rows at the end of the persistent list (YamaPlayer "Add Youtube Playlist" row copies) ----------

        // VRCUrlInputField.onEndEdit of the "add a video URL" row (VRChat URL keyboard / paste confirmed).
        public void VideoUrlEntered() { SubmitUrl(videoUrlInput, false); }

        // VRCUrlInputField.onEndEdit of the "add a YouTube playlist" row.
        public void PlaylistUrlEntered() { SubmitUrl(playlistUrlInput, true); }

        private void SubmitUrl(VRCUrlInputField field, bool playlistRow)
        {
            if (field == null) return;
            VRCUrl url = field.GetUrl();
            field.SetUrl(VRCUrl.Empty); // like YamaPlayer's own row: the field is cleared after every entry
            addMenuOpen = false;        // entered or cancelled: the choices close again
            if (VRCUrl.IsNullOrEmpty(url)) { Refresh(); return; } // keyboard closed without input
            if (selected < 0 || store == null || !store.Editable()) { Feedback("not_ready"); Refresh(); return; }
            // Playlist choice: the URL goes to YamaPlayer's import as it is (no DM-side URL rule).
            // A playlist page entered in the video choice is passed to the same import.
            if (playlistRow || MyListCodec.IsImportablePlaylistUrl(url.Get())) StartPlaylistImport(url);
            else AddVideo(url);
            Refresh();
        }

        // A single video is saved only when its title is known (a saved video always has a title).
        private void AddVideo(VRCUrl url)
        {
            string value = url.Get();
            if (!MyListCodec.ValidUrl(value)) { Feedback("invalid_url"); return; }
            int id = store.playlistIds[selected];
            // Same track rule as YamaPlayer's playlist import: YouTube -> AVPro + canonical watch URL as the
            // original URL. The entered VRCUrl is kept so the video also plays directly (no WebUnit needed).
            string key = MyListCodec.Identity(value);
            bool youtube = key.StartsWith("https://www.youtube.com/watch?v=");
            string original = youtube ? key : value;
            int player = youtube || controller == null ? (int)Yamadev.YamaStream.VideoPlayerType.AVProVideoPlayer : (int)controller.VideoPlayerType;
            for (int i = 0; i < store.savedUrls.Length; i++)
                if (store.trackPlaylists[i] == id && MyListCodec.TrackKey(store.savedUrls[i], store.originals[i]) == key) { Feedback("duplicate"); return; }
            for (int i = 0; i < pendCount; i++)
                if (!pendBackfill[i] && pendLists[i] == id && pendKeys[i] == key) { Feedback("duplicate_pending"); return; }
            for (int i = 0; i < pendCount; i++)
                if (!pendBackfill[i]) { Feedback("title_confirmation_busy"); return; }
            if (pendCount == MaxPending) { Feedback("pending_limit"); return; }
            int p = pendCount++;
            pendUrls[p] = url; pendAskUrls[p] = url; pendKeys[p] = key; pendOriginals[p] = original; pendPlayers[p] = player; pendLists[p] = id;
            pendBackfill[p] = false; pendStates[p] = 1;
            ResolvePending(p, true);
        }

        // Title resolver for one waiting video, by video identity:
        //   1) a title already known anywhere (FindKnownTitle)            -> saved at once, no request
        //   2) a URL VideoInfo can read: the entered one, or an existing VRCUrl of the same video
        //      (FindUsableVRCUrl; Udon cannot build a VRCUrl)             -> "loading", saved when the title arrives
        //   3) neither                                                    -> not saved; the row offers typing the title
        private void ResolvePending(int p, bool announce)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            pendStates[p] = 1; OpenTitleConfirmation(p, ""); return;
#endif
            string key = pendKeys[p];
            bool youtube = key.StartsWith("https://www.youtube.com/watch?v=");
            string known = FindKnownTitle(key);
            if (known != "")
            {
                pendStates[p] = 1;
                OpenTitleConfirmation(p, known);
                return;
            }
            VRCUrl ask = CanLookup(pendUrls[p].Get()) ? pendUrls[p] : FindUsableVRCUrl(key);
            // m. / music. hosts: Udon cannot build the www URL, so the entered URL itself is tried. Its answer counts
            // only when the page names this video (ApplyLookupBody).
            if (ask == null && youtube && MayAnswerDirectly(pendUrls[p].Get())) ask = pendUrls[p];
            if (ask == null)
            {
                pendStates[p] = youtube ? 2 : 3;
                if (announce) Feedback(youtube ? "title_form_unsupported" : "title_site_unsupported");
                OpenTitleConfirmation(p, "");
                return;
            }
            pendAskUrls[p] = ask;
            if (announce) Feedback("title_lookup_started");
            OpenTitleConfirmation(p, "");
            StartLookup(p);
        }

        // Writes one video with its title. False when the Store refused it (duplicate, limits, playlist gone).
        private bool CommitVideo(VRCUrl url, string title, string original, int player, int playlistId)
        {
            if (store == null || !store.Editable()) return false;
            int before = store.savedUrls.Length;
            store.Add(url, title, original, player, playlistId, "");
            if (store.savedUrls.Length == before) { FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese)); return false; }
            DoneText(L("added_title").Replace("{title}", title));
            return true;
        }

        // IMPORT_CONTEXT = PERSISTENT: a YouTube playlist URL entered in an open persistent playlist. The target
        // (playlist ID) is fixed here and does not change until the import ends, whatever is open later. The page
        // is loaded and parsed by a DM import object with YamaPlayer's parser; Controller.AddDynamicPlaylist is
        // not called, so no standard (temporary) YamaPlayer playlist is created. Same URL rule as YamaPlayer's
        // own row (VRCUrl.IsValid), the URL passed on unchanged.
        private void StartPlaylistImport(VRCUrl url)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            Feedback("android_import_unavailable"); return;
#endif
            MyListPersistentView hub = Hub();
            if (controller == null) { Feedback("yama_missing"); return; }
            // Form A (revision 8): a share link without www is redirected (301), which VRChat's string loading does not
            // follow. Nothing is requested; the user is told how to correct it (Udon cannot rewrite a VRCUrl).
            if (url != null && IsFormAPlaylistUrl(url.Get()))
            {
                Feedback("import_form_a");
                Debug.Log("[DM MyList] import PERSISTENT refused before download: playlist link without www (form A)");
                return;
            }
            // YouTube Mix: watch form v=<current>&list=RD<seed> (MixImportList). Both IDs are validated independently;
            // the full list keeps the requested seed even when the current video differs. No URL is rewritten. Its page
            // carries the list (real-client diagnosis M1/X1/X2). Every other Mix form (the playlist page, no www, other
            // RD lists, other query items) is refused before any request, as in revision 10.
            string mixList = "";
            string mixVideo = "";
            if (url != null && IsMixUrl(url.Get()))
            {
                mixList = MixImportList(url.Get());
                if (mixList.Length > 0) mixVideo = MixImportVideo(url.Get());
                if (mixList.Length == 0 || mixVideo.Length == 0)
                {
                    Feedback("import_mix");
                    Debug.Log("[DM MyList] import PERSISTENT refused before download: YouTube Mix (list RD) in a form that is not loaded");
                    return;
                }
            }
            if (hub.importJob != null) { Feedback("import_busy"); return; }
            // Stopped imports stay in VRChat's download queue until they are answered; no more are piled up.
            if (hub.importOrphans >= MaxImportOrphans)
            {
                // ... unless the last one was stopped long ago: a request that was never answered must not block imports for the whole session.
                if (Time.realtimeSinceStartup - hub.importOrphanAt < ImportOrphanForgetSeconds) { Feedback("import_queue_full"); return; }
                hub.importOrphans = 0;
                hub.importOrphanEpoch++;
            }
            if (importTemplate == null) { Feedback("import_failed"); return; }
            if (url == null || !url.IsValid()) { Feedback("invalid_url"); return; }
            GameObject copy = Instantiate(importTemplate.gameObject, importTemplate.transform.parent);
            copy.SetActive(true);
            MyListPlaylistImport job = copy.GetComponent<MyListPlaylistImport>();
            job.view = hub;
            hub.importJob = job;
            hub.importTargetId = store.playlistIds[selected];
            hub.importStarted = Time.realtimeSinceStartup;
            hub.importWaitShown = false;
            hub.importOwner = this;
            Feedback("import_loading");
            Debug.Log("[DM MyList] import PERSISTENT started: target playlist " + hub.importTargetId + ", YamaPlayer playlists " + controller.Playlists.Length + ", saved tracks " + store.savedUrls.Length + (mixList.Length > 0 ? ", YouTube Mix" : ""));
            if (mixList.Length > 0) job.LoadMix(url, mixList, mixVideo);
            else job.Load(url);
            hub.ScheduleImportTick();
            RefreshAll();
        }

        // http(s)://youtube.com/playlist?...list=<value>... (host exactly youtube.com in any case, no port or user part):
        // YouTube redirects it to www.youtube.com. Other hosts (m. / music. / www.) and other paths are not form A.
        private bool IsFormAPlaylistUrl(string u)
        {
            if (string.IsNullOrEmpty(u)) return false;
            int start = u.StartsWith("https://") ? 8 : u.StartsWith("http://") ? 7 : 0;
            if (start == 0) return false;
            int end = u.Length;
            int cut = u.IndexOfAny(new char[] { '/', '?', '#' }, start);
            if (cut >= 0) end = cut;
            if (u.Substring(start, end - start).ToLower() != "youtube.com") return false;
            if (cut < 0 || u[cut] != '/') return false;
            int query = u.IndexOf('?', cut);
            int hash = u.IndexOf('#', cut);
            int pathEnd = query >= 0 ? query : (hash >= 0 ? hash : u.Length);
            if (hash >= 0 && hash < pathEnd) pathEnd = hash;
            if (u.Substring(cut, pathEnd - cut) != "/playlist" || query < 0 || (hash >= 0 && hash < query)) return false;
            string qs = hash > query ? u.Substring(query + 1, hash - query - 1) : u.Substring(query + 1);
            string[] items = qs.Split('&');
            for (int i = 0; i < items.Length; i++)
                if (items[i].StartsWith("list=") && items[i].Length > 5) return true;
            return false;
        }

        // http(s)://www.youtube.com or youtube.com (host in any case, no port or user part), path exactly /watch or
        // /playlist, and exactly one 'list=' item whose value is RD followed by 1 to 62 characters of [A-Za-z0-9_-].
        // Anything else (m. / music. / youtu.be, other paths, two 'list' items, other values) is not a Mix here.
        private bool IsMixUrl(string u)
        {
            if (string.IsNullOrEmpty(u)) return false;
            int start = u.StartsWith("https://") ? 8 : u.StartsWith("http://") ? 7 : 0;
            if (start == 0) return false;
            int cut = u.IndexOfAny(new char[] { '/', '?', '#' }, start);
            if (cut < 0 || u[cut] != '/') return false;
            string host = u.Substring(start, cut - start).ToLower();
            if (host != "www.youtube.com" && host != "youtube.com") return false;
            int query = u.IndexOf('?', cut);
            int hash = u.IndexOf('#', cut);
            if (query < 0 || (hash >= 0 && hash < query)) return false;
            string path = u.Substring(cut, query - cut);
            if (path != "/watch" && path != "/playlist") return false;
            string qs = hash > query ? u.Substring(query + 1, hash - query - 1) : u.Substring(query + 1);
            string[] items = qs.Split('&');
            string value = "";
            int lists = 0;
            for (int i = 0; i < items.Length; i++)
                if (items[i].StartsWith("list=")) { lists++; value = items[i].Substring(5); }
            if (lists != 1 || value.Length < 3 || value.Length > 64 || !value.StartsWith("RD")) return false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return false;
            }
            return true;
        }

        // The Mix that is loaded (revision 11): exactly https://www.youtube.com/watch (host in any case, no port, user
        // part or fragment) with one 'v' and one 'list' equal to "RD" + a seed. Both IDs are exactly 11 characters
        // of [A-Za-z0-9_-]; the current video need not be the seed. There may be
        // at most one 'start_radio=1' and one 'si' (1 to 64 of the same characters), in any order, nothing else.
        // Returns the list value, or "" (refused before download).
        private string MixImportList(string u)
        {
            if (string.IsNullOrEmpty(u) || !u.StartsWith("https://") || u.IndexOf('#') >= 0) return "";
            string rest = u.Substring(8);
            int slash = rest.IndexOf('/');
            if (slash <= 0 || rest.Substring(0, slash).ToLower() != "www.youtube.com") return "";   // also rejects ':' and '@'
            string pathAndQuery = rest.Substring(slash);
            int q = pathAndQuery.IndexOf('?');
            if (q < 0 || pathAndQuery.Substring(0, q) != "/watch") return "";
            string[] items = pathAndQuery.Substring(q + 1).Split('&');
            string video = "", list = "";
            int videos = 0, lists = 0, radios = 0, shares = 0;
            for (int i = 0; i < items.Length; i++)
            {
                string item = items[i];
                if (item.StartsWith("v=")) { videos++; video = item.Substring(2); }
                else if (item.StartsWith("list=")) { lists++; list = item.Substring(5); }
                else if (item == "start_radio=1") radios++;
                else if (item.StartsWith("si=")) { shares++; if (item.Length < 4 || item.Length > 67 || !MixIdText(item.Substring(3))) return ""; }
                else return "";
            }
            if (videos != 1 || lists != 1 || radios > 1 || shares > 1) return "";
            if (video.Length != 11 || !MixIdText(video) || list.Length != 13 || !list.StartsWith("RD") || !MixIdText(list.Substring(2))) return "";
            return list;
        }

        // URL-02: LoadMix's third argument describes the current video, not the RD seed. Validate the full URL
        // first so missing/duplicate IDs or unsupported query items cannot yield a usable argument on their own.
        private string MixImportVideo(string u)
        {
            if (MixImportList(u).Length == 0) return "";
            string[] items = u.Substring(u.IndexOf('?') + 1).Split('&');
            for (int i = 0; i < items.Length; i++)
                if (items[i].StartsWith("v=")) return items[i].Substring(2);
            return "";
        }

        private bool MixIdText(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-')) return false;
            }
            return true;
        }

        public void ScheduleImportTick()
        {
            if (importTickScheduled) return;
            importTickScheduled = true;
            SendCustomEventDelayedSeconds(nameof(ImportTick), 1f);
        }

        // Once a second while an import is running (on the primary; no Update): the waiting time in the "追加する" row
        // of every UI, and one notice when the answer has not come for ImportWaitNoticeSeconds. Nothing is given up here.
        public void ImportTick()
        {
            importTickScheduled = false;
            if (importJob == null) return;
            // A fallback parse (state 5) whose heartbeat stopped while frames went on: the import object was stopped
            // (an Udon exception). Cleaned up like ImportWatch; nothing is saved.
            if (importJob.state == 5 && Time.realtimeSinceStartup - importJob.beatTime > 5f && Time.frameCount - importJob.beatFrame >= 10)
            {
                Debug.LogWarning("[DM MyList] import PERSISTENT failed: the playlist page reading stopped; nothing was saved");
                MyListPersistentView stalledVoice = ImportVoice();
                Destroy(importJob.gameObject);
                ClearImport();
                stalledVoice.Feedback("import_failed");
                RefreshAll();
                return;
            }
            if (!importWaitShown && Time.realtimeSinceStartup - importStarted >= ImportWaitNoticeSeconds)
            {
                importWaitShown = true;
                Debug.Log("[DM MyList] import PERSISTENT still waiting after " + Mathf.FloorToInt(Time.realtimeSinceStartup - importStarted) + " s (VRChat downloads one string every 5 s for the whole world); it keeps waiting until it is answered or stopped");
                ImportVoice().Feedback("import_waiting");
            }
            UpdateAddRow();
            if (extraViews != null)
                for (int i = 0; i < extraViews.Length; i++)
                    if (Utilities.IsValid(extraViews[i])) extraViews[i].UpdateAddRow();
            ScheduleImportTick();
        }

        // The UI that messages about the running import go to: the one it was started from.
        private MyListPersistentView ImportVoice() { return Utilities.IsValid(importOwner) ? importOwner : this; }

        // "追加する" row of the open persistent playlist: while an import runs it shows the waiting time instead.
        public void UpdateAddRow()
        {
            if (addRowText == null) return;
            MyListPersistentView hub = Hub();
            if (hub.importJob == null) { addRowText.text = L("add_menu"); return; }
            addRowText.text = L("import_row_waiting").Replace("{s}", Mathf.FloorToInt(Time.realtimeSinceStartup - hub.importStarted).ToString());
        }

        private void ClearImport()
        {
            importJob = null;
            importTargetId = -1;
            importOwner = null;
        }

        // Called by the import object (on the primary) when the page was parsed or could not be loaded.
        public void ImportFinished()
        {
            if (importJob == null || (importJob.state != 3 && importJob.state != 4)) return; // 5 = still reading the page
            MyListPlaylistImport job = importJob;
            int target = importTargetId;
            int waited = Mathf.FloorToInt(Time.realtimeSinceStartup - importStarted);
            MyListPersistentView voice = ImportVoice();
            ClearImport();
            voice.ApplyImport(job, target, waited);
            Destroy(job.gameObject);
            RefreshAll();
        }

        // A stopped import was answered (its object removes itself; the answer is not used).
        public void ImportOrphanAnswered(int epoch)
        {
            if (epoch == importOrphanEpoch && importOrphans > 0) importOrphans--;
            Debug.Log("[DM MyList] import PERSISTENT: the answer of a stopped import arrived and was discarded; nothing was saved");
        }

        // The answer of an import, on the UI it was started from. All-or-nothing through the Store.
        public void ApplyImport(MyListPlaylistImport job, int target, int waited)
        {
#if UNITY_ANDROID
            Feedback("android_import_unavailable"); return;
#endif
            int savedBefore = store != null ? store.savedUrls.Length : -1;
            int parsed = job.state == 3 && Utilities.IsValid(job.tracks) ? job.tracks.Count() : 0;
            if (parsed > 0 && store != null && store.Editable() && store.PlaylistIndex(target) >= 0)
            {
                // DM's lockupViewModel reading (IMPORT-URL-01): the same video listed twice was kept once
                if (job.fbUsed && job.fbDuplicates > 0) FeedbackText(L("import_fallback_duplicates").Replace("{d}", job.fbDuplicates.ToString()));
                if (job.mixUsed) MixSavedNotice(job, parsed);
                CommitTracks(job.tracks, target, "");
            }
            else if (job.state == 4 && job.errorCode != 0) FeedbackText(L("import_error").Replace("{code}", job.errorCode.ToString()));
            else if (job.mixUsed) MixNotSaved(job);
            else if (job.fbUsed && job.fbOutcome == "rejected") FallbackRejected(job);
            else if (job.fbUsed && job.fbOutcome == "incomplete")
            {
                lastFeedback = "import_fallback_incomplete";
                FeedbackText(L("import_fallback_incomplete").Replace("{n}", job.fbAccepted.ToString()));
            }
            else Feedback("import_failed");
            if (job.state == 4 && job.errorCode != 0) { lastFeedback = "import_error"; Debug.LogWarning("[DM MyList] import PERSISTENT: download error " + job.errorCode + " " + job.errorText + " after " + waited + " s"); }
            Debug.Log("[DM MyList] import PERSISTENT finished: state " + job.state + ", parsed tracks " + parsed + ", target playlist " + target + ", saved tracks " + savedBefore + " -> " + (store != null ? store.savedUrls.Length : -1) + ", YamaPlayer playlists " + (controller != null ? controller.Playlists.Length : -1));
        }

        // Nothing was saved because items of the list could not be confirmed: how many, and why (category names and
        // counts only).
        private void FallbackRejected(MyListPlaylistImport job)
        {
            string text = RejectedText(job);
            lastFeedback = job.fbRejected > 0 ? "import_fallback_rejected" : "import_fallback_unknown";
            FeedbackText(text);
        }

        // Before CommitTracks: a Mix list is only its first part (isInfinite); the same video listed twice was kept once.
        // A refusal or a skip that CommitTracks reports replaces this message.
        private void MixSavedNotice(MyListPlaylistImport job, int parsed)
        {
            string text = job.mixInfinite ? L("import_mix_saved_first").Replace("{n}", parsed.ToString()) : "";
            if (job.mixDuplicates > 0) text += (text == "" ? "" : "\n") + L("import_fallback_duplicates").Replace("{d}", job.mixDuplicates.ToString());
            if (text != "") FeedbackText(text);
        }

        // A Mix that saved nothing: no list on the page, too many items, or a list that could not be confirmed.
        private void MixNotSaved(MyListPlaylistImport job)
        {
            string o = job.mixOutcome;
            if (o == "unavailable") { Feedback("import_mix_unavailable"); return; }
            if (o == "failed:tooMany") { Feedback("import_mix_too_many"); return; }
            if (o == "rejected" || o.StartsWith("failed:"))
            {
                string text = L("import_mix_rejected");
                if (o == "rejected") text += "\n" + RejectedText(job);
                lastFeedback = "import_mix_rejected";
                FeedbackText(text);
                return;
            }
            Feedback("import_failed");
        }

        // how many items could not be confirmed, and why (category names and counts only)
        private string RejectedText(MyListPlaylistImport job)
        {
            string text = "";
            if (job.fbRejected > 0)
            {
                string reasons = "";
                if (job.fbNotVideo > 0) reasons += L("fallback_reason_kind") + " " + job.fbNotVideo;
                if (job.fbBadId > 0) reasons += (reasons == "" ? "" : ", ") + L("fallback_reason_id") + " " + job.fbBadId;
                if (job.fbNoTitle > 0) reasons += (reasons == "" ? "" : ", ") + L("fallback_reason_title") + " " + job.fbNoTitle;
                if (job.fbEndpoint > 0) reasons += (reasons == "" ? "" : ", ") + L("fallback_reason_endpoint") + " " + job.fbEndpoint;
                if (job.fbBadShape > 0) reasons += (reasons == "" ? "" : ", ") + L("fallback_reason_shape") + " " + job.fbBadShape;
                text = L("import_fallback_rejected").Replace("{n}", job.fbLockups.ToString()).Replace("{r}", job.fbRejected.ToString()).Replace("{reasons}", reasons);
            }
            if (job.fbUnknownShape > 0)
                text += (text == "" ? "" : "\n") + L("import_fallback_unknown").Replace("{u}", job.fbUnknownShape.ToString());
            return text;
        }

        // One frame after the parser started: still "parsing" means the parser stopped the import object.
        public void ImportWatch()
        {
            if (importJob == null || importJob.state != 2) return;
            Debug.LogWarning("[DM MyList] import PERSISTENT failed: the page could not be parsed; nothing was saved");
            MyListPersistentView voice = ImportVoice();
            Destroy(importJob.gameObject); // it has been answered already: nothing is left in VRChat's queue
            ClearImport();
            voice.Feedback("import_failed");
            RefreshAll();
        }

        // Ends the running import without saving anything (on the primary). Its request may still be in VRChat's
        // queue, so the import object is kept, marked as stopped: when its answer arrives it throws the answer away
        // and removes itself. An answer that never arrives costs one idle object.
        public void AbandonImport()
        {
            if (importJob == null) return;
            MyListPlaylistImport job = importJob;
            ClearImport();
            if (job.state >= 2) Destroy(job.gameObject);
            else { job.cancelled = true; job.orphanEpoch = importOrphanEpoch; importOrphans++; importOrphanAt = Time.realtimeSinceStartup; }
        }

        // "追加する" row tapped while an import runs: YamaPlayer's Modal asks before anything is stopped.
        private void OpenImportCancel()
        {
            MyListPersistentView hub = Hub();
            nameInputRoot.SetActive(false);
            ShowDialog(7, L("import_cancel_title"), L("import_cancel_message").Replace("{s}", Mathf.FloorToInt(Time.realtimeSinceStartup - hub.importStarted).ToString()), L("import_cancel_execute"));
        }

        // Stops the running import now (the confirmed dialog; also what the product checks call).
        public void CancelImportNow()
        {
            MyListPersistentView hub = Hub();
            if (hub.importJob == null) return;
            int waited = Mathf.FloorToInt(Time.realtimeSinceStartup - hub.importStarted);
            hub.AbandonImport();
            Debug.Log("[DM MyList] import PERSISTENT stopped by the user after " + waited + " s; nothing was saved");
            Feedback("import_cancelled");
            RefreshAll();
        }

        // ---------- playlist management dialogs ----------

        private void ShowDialog(int kind, string title, string message, string execute)
        {
            pendingDialog = kind;
            nameInput.characterLimit = kind == 6 ? MyListCodec.MaxTitleLength : 48; // playlist names: 48, video titles: 256
            ApplyInputLook();
            modal.CloseEvent = UdonEvent.New(this, nameof(CancelDialog));
            modal.Show(title, message, UdonEvent.New(this, nameof(ConfirmDialog)), L("cancel"), execute);
        }

        public void CancelDialog()
        {
            if (pendingDialog == 6)
                for (int i = pendCount - 1; i >= 0; i--)
                    if (!pendBackfill[i] && pendLists[i] == manualList && pendKeys[i] == manualKey) RemovePending(i);
            pendingDialog = 0;
            pendingNative = null;
            nameInputRoot.SetActive(false);
            if (modal != null) modal.CloseEvent = UdonEvent.Empty();
        }

        private void CloseDialog()
        {
            CancelDialog();
            modal.gameObject.SetActive(false);
        }

        public void OpenCreate()
        {
            if (store == null || !store.Editable()) { Feedback("not_ready"); return; }
            if (store.playlistIds.Length >= MyListCodec.MaxPlaylists) { Feedback("playlist_limit"); return; }
            nameInput.text = "";
            nameInputRoot.SetActive(true);
            ShowDialog(1, L("new_persistent_title"), L("enter_name"), L("create"));
        }

        // Only the actual input field's submit event commits. Focus loss/cancel have no save callback.
        private void ResolveCreateRowInput()
        {
            // Existing scene instances may override the backing Udon variable table from before this
            // DM-owned child was added. Resolve from the existing row without changing scene settings.
            if (createRowNameInput != null || createPersistentRow == null) return;
            Transform input = createPersistentRow.transform.Find("DM Create Name Input");
            if (input != null) createRowNameInput = input.GetComponent<InputField>();
        }

        public void SubmitCreateRowName()
        {
            ResolveCreateRowInput();
            if (createRowNameInput == null || createRowNameInput.wasCanceled || !createRowNameInput.gameObject.activeInHierarchy ||
                !createMenuOpen || pendingDialog != 0 || store == null || !store.Editable()) return;
            string title = createRowNameInput.text;
            // Clear before saving so a duplicate submit cannot create a second playlist.
            createRowNameInput.text = "";
            createRowNameInput.DeactivateInputField();
            if (string.IsNullOrEmpty(title) || title.Trim().Length == 0) return;
            if (store.playlistIds.Length >= MyListCodec.MaxPlaylists) { Feedback("playlist_limit"); return; }
            int before = store.playlistIds.Length;
            store.CreatePlaylist(title);
            if (store.playlistIds.Length > before) { createMenuOpen = false; Refresh(); }
            else FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese));
        }

        // InputField.onSubmit, not onEndEdit: clicking Cancel or losing focus must never create a playlist.
        public void SubmitCreateName()
        {
            if (pendingDialog != 1 || nameInput == null || nameInput.wasCanceled || store == null || !store.Editable() ||
                nameInputRoot == null || !nameInputRoot.activeInHierarchy || modal == null || !modal.gameObject.activeInHierarchy ||
                string.IsNullOrEmpty(nameInput.text) || nameInput.text.Trim().Length == 0) return;
            ConfirmCreate();
        }

        private void ResolveRenameRowInput()
        {
            if (renameRowNameInput != null || persistentActions == null) return;
            Transform input = persistentActions.transform.Find("Actions/DM OpenRename/DM Rename Name Input");
            if (input != null) renameRowNameInput = input.GetComponent<InputField>();
        }

        private void PrepareRenameRowInput()
        {
            ResolveRenameRowInput();
            if (renameRowNameInput == null || store == null || selected < 0 || selected >= store.playlistIds.Length) return;
            int id = store.playlistIds[selected];
            string title = store.playlistNames[selected];
            if (renameInputPlaylistId != id)
            {
                renameRowNameInput.DeactivateInputField();
                renameInputPlaylistId = id;
                renameInputOriginalName = title;
                renameRowNameInput.text = title;
            }
            else if (!renameRowNameInput.isFocused && renameInputOriginalName != title)
            {
                renameInputOriginalName = title;
                renameRowNameInput.text = title;
            }
        }

        // The same real-click input path as creation. Cancelling or losing focus never saves.
        public void SubmitRenameRowName()
        {
            ResolveRenameRowInput();
            if (renameRowNameInput == null || renameRowNameInput.wasCanceled || !renameRowNameInput.gameObject.activeInHierarchy ||
                pendingDialog != 0 || store == null || !store.Editable() || renameInputPlaylistId < 0 || selectedId != renameInputPlaylistId) return;
            int id = renameInputPlaylistId;
            int index = store.PlaylistIndex(id);
            if (index < 0) return;
            string title = renameRowNameInput.text;
            renameRowNameInput.text = "";
            renameRowNameInput.DeactivateInputField();
            renameInputPlaylistId = -1;
            if (!string.IsNullOrEmpty(title) && title.Trim().Length > 0 && title.Trim() != store.playlistNames[index])
            {
                store.RenamePlaylist(id, title);
                if (store.playlistNames[index] != title.Trim()) FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese));
            }
            Refresh();
        }

        public void OpenRename()
        {
            if (selected < 0 || store == null || !store.Editable()) return;
            nameInput.text = store.playlistNames[selected];
            nameInputRoot.SetActive(true);
            deleteId = store.playlistIds[selected];
            ShowDialog(2, L("rename_playlist"), L("enter_new_name"), L("rename"));
        }

        // "プレイリスト削除": one confirmation (YamaPlayer's Modal: 削除 / キャンセル). The playlist to delete is
        // remembered by ID when the dialog opens, so the confirmation never depends on what is open later.
        public void OpenDelete()
        {
            if (selected < 0 || store == null || !store.Editable()) return;
            nameInputRoot.SetActive(false);
            deleteId = store.playlistIds[selected];
            ShowDialog(3, L("delete_playlist"), L("delete_confirm").Replace("{name}", store.playlistNames[selected]), L("delete"));
        }

        public void ConfirmDialog()
        {
            int kind = pendingDialog;
            if (kind == 1) ConfirmCreate();
            else if (kind == 2) ConfirmRename();
            else if (kind == 3) ConfirmDelete();
            else if (kind == 5) SaveNativeAsNew();
            else if (kind == 6) ConfirmManualTitle();
            else if (kind == 7) { CloseDialog(); CancelImportNow(); }
        }

        private void ConfirmCreate()
        {
            int before = store.playlistIds.Length;
            store.CreatePlaylist(nameInput.text);
            if (store.playlistIds.Length > before) CloseDialog();
            else FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese));
        }

        private void ConfirmRename()
        {
            int index = store == null ? -1 : store.PlaylistIndex(deleteId);
            if (index < 0) { CloseDialog(); return; }
            store.RenamePlaylist(deleteId, nameInput.text);
            if (store.playlistNames[index] == nameInput.text.Trim()) { deleteId = -1; CloseDialog(); Refresh(); }
            else FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese));
        }

        // Removes the playlist (ID, name, every video of it) from the Store; other playlists are untouched.
        private void ConfirmDelete()
        {
            int id = deleteId;
            deleteId = -1;
            CloseDialog();
            if (store == null || !store.Editable() || store.PlaylistIndex(id) < 0) { Feedback("delete_failed"); return; }
            string name = store.playlistNames[store.PlaylistIndex(id)];
            store.DeletePlaylist(id);
            if (store.PlaylistIndex(id) >= 0) { FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese)); return; }
            // Nothing may keep pointing at the deleted playlist: waiting videos, a running import, the playing mark.
            for (int i = pendCount - 1; i >= 0; i--) if (pendLists[i] == id) RemovePending(i);
            if (Hub().importTargetId == id) Hub().AbandonImport();
            if (adapter != null && adapter.snapshotPlaylistId == id) Hub().startedHere = false;
            CloseView(true);
            DoneText(L("playlist_deleted").Replace("{name}", name));
        }

        // ---------- titles through YamaPlayer's own VideoInfo ----------
        // VideoInfo downloads the watch page and parses it with YamaPlayer's YouTube.GetTitleFromHtml, the same
        // way YamaPlayer titles a URL it plays. Its cache (_info) is read; only a cached failure ("") is dropped
        // before asking again. VideoInfo needs a VRCUrl (Udon cannot build one) and VRChat string loading follows
        // no redirects, so only www.youtube.com/watch and www.twitch.tv URLs can be read.

        // URL forms whose page VRChat can load without a redirect and YamaPlayer's VideoInfo can read
        // (verified in ClientSim with real URLs): www watch, www shorts, www live, Twitch.
        private bool CanLookup(string value)
        {
            if (videoInfo == null) return false;
            return value.StartsWith("https://www.youtube.com/watch?") || value.StartsWith("https://www.youtube.com/shorts/") ||
                value.StartsWith("https://www.youtube.com/live/") || value.StartsWith("https://www.twitch.tv/");
        }

        // YouTube hosts other than www whose page may come back without a redirect (not verified on a real client).
        // youtu.be and youtube.com without www always redirect, and VRChat's string loading does not follow redirects
        // (real client, 2026-10-08: "Redirect limit exceeded" for a youtu.be URL), so those are never requested.
        private bool MayAnswerDirectly(string value)
        {
            return value.StartsWith("https://m.youtube.com/") || value.StartsWith("https://music.youtube.com/");
        }

        // A saved track of an older version that has no title and is being looked up right now.
        private bool IsTitlePending(int data)
        {
            if (data < 0 || pendCount == 0 || !string.IsNullOrEmpty(store.titles[data])) return false;
            string key = MyListCodec.TrackKey(store.savedUrls[data], store.originals[data]);
            for (int i = 0; i < pendCount; i++)
                if (pendBackfill[i] && pendStates[i] == 0 && pendKeys[i] == key) return true;
            return false;
        }

        // Only a real title is accepted: not empty, not a URL, not a generic page name, not one of DM's own
        // placeholder texts.
        private string CleanTitle(string title, string key)
        {
            if (title == null) return "";
            title = title.Trim();
            if (title == "" || title == key || title == "YouTube" || title == "- YouTube" || title == "Twitch") return "";
            if (title.StartsWith("http://") || title.StartsWith("https://") || title.StartsWith("rtsp://") || title.StartsWith("rtmp://")) return "";
            if (title == "タイトルなし" || title == "Untitled" || title.StartsWith("タイトル未取得") || title.StartsWith("No title (")) return "";
            if (title == MyListLocalization.Text("title_lookup_pending", true) || title == MyListLocalization.Text("title_lookup_pending", false)) return "";
            if (title == MyListLocalization.Text("title_failed_row", true) || title == MyListLocalization.Text("title_failed_row", false)) return "";
            return title;
        }

        // Read-only scan of YamaPlayer's own tracks for one video identity. Runs only when a video is added
        // (or retried); bounded by scanBudget. Nothing in YamaPlayer is changed.
        private string scanTitle = "";
        private VRCUrl scanUrl;
        private int scanBudget;

        private bool IsYouTubeKey(string key) { return key.StartsWith("https://www.youtube.com/watch?v="); }

        // The shared rule (MyListCodec.ConsistentIdentity): "" = contradictory track, used for nothing.
        private string TrackIdentity(VRCUrl url, string original) { return MyListCodec.ConsistentIdentity(url, original); }

        private void ScanTrack(Track track, string key)
        {
            if (!Utilities.IsValid(track)) return; // a Track is an object[] in Udon (no UnityEngine.Object comparison)
            VRCUrl url = track.GetVRCUrl();
            string identity = TrackIdentity(url, track.GetOriginalUrl());
            if (identity == "") return; // contradictory track: no title source, no URL source
            if (indexing) { IndexSource(identity, track.GetTitle(), url); return; }
            // Title: only from a track that is this video.
            if (scanTitle == "" && identity == key) scanTitle = CleanTitle(track.GetTitle(), key);
            // URL for a lookup: the VRCUrl itself must be this video (the original URL matching is not enough).
            // An existing VRCUrl object, never a new one.
            if (scanUrl == null && !VRCUrl.IsNullOrEmpty(url) && MyListCodec.Identity(url.Get()) == key && CanLookup(url.Get())) scanUrl = url;
        }

        private void ScanPlaylist(Playlist playlist, string key)
        {
            if (playlist == null || playlist.IsLoading) return;
            int n = playlist.Length;
            for (int i = 0; i < n && scanBudget > 0; i++) { scanBudget--; ScanTrack(playlist.GetTrack(i), key); }
        }

        // Sources, in order: the playing track, every YamaPlayer playlist (static / imported; DM's playback
        // slot is skipped: it only mirrors the Store), the Queue, the History.
        private void ScanYamaPlayer(string key)
        {
            scanTitle = ""; scanUrl = null; scanBudget = 4000;
            if (controller == null) return;
            ScanTrack(controller.Track, key);
            Playlist[] lists = controller.Playlists;
            for (int i = 0; i < lists.Length; i++)
                if (adapter == null || lists[i] != adapter.slot) ScanPlaylist(lists[i], key);
            ScanPlaylist(controller.Queue, key);
            ScanPlaylist(controller.History, key);
        }

        // A title already known for this video: Store -> YamaPlayer tracks -> titles verified in this session.
        private string FindKnownTitle(string key)
        {
            for (int i = 0; i < store.savedUrls.Length; i++)
            {
                if (string.IsNullOrEmpty(store.titles[i]) || TrackIdentity(store.savedUrls[i], store.originals[i]) != key) continue;
                string saved = CleanTitle(store.titles[i], key);
                if (saved != "") return saved;
            }
            ScanYamaPlayer(key);
            if (scanTitle != "") return scanTitle;
            // Titles this session read itself and verified against the response's own video ID. YamaPlayer's
            // VideoInfo cache (raw URL -> title, video ID never checked) is not used as a title source.
            DataToken verified = new DataToken("");
            if (verifiedTitles.TryGetValue(key, TokenType.String, out verified)) return CleanTitle(verified.String, key);
            return "";
        }

        // An existing VRCUrl of the same video that VideoInfo can read (from YamaPlayer's tracks or the Store).
        // Call right after FindKnownTitle(key): it reuses that scan.
        private VRCUrl FindUsableVRCUrl(string key)
        {
            if (scanUrl != null) return scanUrl;
            for (int i = 0; i < store.savedUrls.Length; i++)
                if (!VRCUrl.IsNullOrEmpty(store.savedUrls[i]) && CanLookup(store.savedUrls[i].Get()) && MyListCodec.Identity(store.savedUrls[i].Get()) == key &&
                    TrackIdentity(store.savedUrls[i], store.originals[i]) == key) return store.savedUrls[i];
            return null;
        }

        // YouTube: the page is loaded here (VRChat string loading, the same call YamaPlayer's VideoInfo makes) so
        // that the response's own videoDetails.videoId can be checked against the video that was asked for.
        // Other sites (Twitch): YamaPlayer's VideoInfo, as before.
        // YouTube: the page is loaded here (VRChat string loading, the same call YamaPlayer's VideoInfo makes) so
        // that the response's own videoDetails.videoId can be checked against the video that was asked for.
        // Other sites (Twitch): YamaPlayer's VideoInfo, as before (no video ID to check there).
        private void StartLookup(int p)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            pendStates[p] = 1; return;
#endif
            pendStates[p] = 0;
            pendDeadlines[p] = Time.realtimeSinceStartup + 240f; // string loads are rate-limited and queued
            pendRequest[p] = -1;
            ConfirmationStatus(p, "title_lookup_pending");
            string value = pendAskUrls[p].Get();
            if (IsYouTubeKey(pendKeys[p]))
            {
                if (!verifiedTitles.ContainsKey(pendKeys[p])) SendRequest(p);
            }
            else
            {
                // VideoInfo keeps a failed load as an empty title for the whole session; drop only that
                // empty entry so this explicit request asks again (runtime cache, nothing is saved).
                DataDictionary cache = (DataDictionary)videoInfo.GetProgramVariable("_info");
                DataToken cached = new DataToken("");
                if (cache != null && cache.TryGetValue(value, TokenType.String, out cached) && cached.String == "") cache.Remove(value);
                videoInfo.GetVideoInfo(pendAskUrls[p]);
            }
            TitleTick();
        }

        // One download per URL at a time. While an earlier request for the same URL is still running, this
        // lookup waits (pendRequest = -1) and sends its own request when that one has answered; an answer of
        // the earlier request never fails this newer lookup. A request with no answer for RequestStaleSeconds
        // is treated as lost, so a URL cannot stay blocked for ever.
        private void SendRequest(int p)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            return;
#endif
            string value = pendAskUrls[p].Get();
            DataToken since = new DataToken(0.0);
            if (inFlight.ContainsKey(value))
            {
                bool stale = inFlightSince.TryGetValue(value, TokenType.Double, out since) && Time.realtimeSinceStartup - (float)since.Double > RequestStaleSeconds;
                if (!stale) return;
            }
            lookupGeneration++;
            inFlight.SetValue(value, lookupGeneration);
            inFlightSince.SetValue(value, (double)Time.realtimeSinceStartup);
            pendRequest[p] = lookupGeneration;
            VRCStringDownloader.LoadUrl(pendAskUrls[p], (IUdonEventReceiver)this);
        }

        public override void OnStringLoadSuccess(IVRCStringDownload result)
        {
#if UNITY_ANDROID
            return;
#endif
            lookupResultUrl = result.Url.Get(); lookupResultBody = result.Result;
            ApplyLookupBody();
        }

        public override void OnStringLoadError(IVRCStringDownload result)
        {
#if UNITY_ANDROID
            return;
#endif
            lookupResultUrl = result.Url.Get(); lookupResultBody = "";
            ApplyLookupBody();
        }

        // One answer (lookupResultUrl / lookupResultBody). The title is accepted only when it is a real title AND
        // the same videoDetails object names the video that was asked for. A valid answer goes to verifiedTitles
        // (it is this video's title whichever request fetched it). An invalid answer fails only the lookups that
        // are attached to exactly this request; newer lookups for the same URL then send their own request.
        public void ApplyLookupBody()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            lookupResultBody = ""; lookupResultUrl = ""; return;
#endif
            string url = lookupResultUrl, body = lookupResultBody;
            lookupResultUrl = ""; lookupResultBody = "";
            if (string.IsNullOrEmpty(url)) return;
            int generation = -2; // an answer nobody is waiting for
            DataToken running = new DataToken(0);
            if (inFlight.TryGetValue(url, TokenType.Int, out running)) generation = running.Int;
            if (inFlight.ContainsKey(url)) inFlight.Remove(url);
            if (inFlightSince.ContainsKey(url)) inFlightSince.Remove(url);
            string key = MyListCodec.Identity(url);
            string title = "", source = "";
            if (IsYouTubeKey(key) && ReadVideoDetails(body) && "https://www.youtube.com/watch?v=" + parsedId == key) { title = CleanTitle(parsedTitle, key); source = "videoDetails"; }
            // A page with playlist data (watch?v=ID&list=...): YamaPlayer's playlist parser, the track of this video only.
            if (title == "" && IsYouTubeKey(key)) { title = CleanTitle(PlaylistPageTitle(body, key), key); source = "playlist data"; }
            bool direct = CanLookup(url);
            Debug.Log("[DM MyList] title lookup " + url + ": " + (title != "" ? "title read from " + source + ", video ID verified" : "no verified title (" + (string.IsNullOrEmpty(body) ? "page not loaded" : "page " + body.Length + " chars") + ")"));
            if (title != "") verifiedTitles.SetValue(key, title);
            else
            {
                bool failed = false, removedBackfill = false;
                int i = 0;
                while (i < pendCount)
                {
                    if (pendStates[i] != 0 || !IsYouTubeKey(pendKeys[i]) || pendAskUrls[i].Get() != url) { i++; continue; }
                    if (pendRequest[i] == generation)
                    {
                        if (pendBackfill[i]) { RemovePending(i); removedBackfill = true; continue; }
                        pendStates[i] = direct ? 1 : 2; failed = true;
                        ConfirmationStatus(i, "title_confirm_failure");
                    }
                    else if (pendRequest[i] == -1) SendRequest(i); // a newer lookup: its own request starts now
                    i++;
                }
                if (failed) { Feedback(direct ? "title_failed" : "title_form_unsupported"); Refresh(); }
                if (removedBackfill) ContinueBackfill();
            }
            TitleTick();
        }

        // The title of one video from a page that carries playlist data, read with YamaPlayer's playlist parser
        // (the same call the playlist import uses, in a throw-away copy of the import object so that a page the
        // parser cannot handle stops only that copy). Only the track whose URL is exactly this video is used;
        // nothing is created in YamaPlayer and nothing is saved here. "" = not found.
        private string PlaylistPageTitle(string body, string key)
        {
            if (importTemplate == null || string.IsNullOrEmpty(body)) return "";
            if (body.IndexOf("{\"playlist\":") < 0 && body.IndexOf("{\"playlistVideoListRenderer\":") < 0) return "";
            GameObject copy = Instantiate(importTemplate.gameObject, importTemplate.transform.parent);
            copy.SetActive(true);
            MyListPlaylistImport reader = copy.GetComponent<MyListPlaylistImport>();
            reader.body = body;
            reader.ParseOnly();
            string found = "";
            if (reader.state == 3 && Utilities.IsValid(reader.tracks))
            {
                int n = reader.tracks.Count();
                for (int i = 0; i < n; i++)
                {
                    Track track = reader.tracks.GetValue(i);
                    if (track.GetOriginalUrl() != key) continue;
                    found = track.GetTitle();
                    break;
                }
            }
            Destroy(copy);
            return found == null ? "" : found;
        }

        // Reads videoId and title from the page's "videoDetails" object: both from that one object, which is cut
        // out with a JSON-string-aware scan and then read with VRCJson. Only the first "videoDetails" of the page
        // is used (no search through other objects). Anything unexpected = false.
        private bool ReadVideoDetails(string html)
        {
            parsedId = ""; parsedTitle = "";
            if (string.IsNullOrEmpty(html)) return false;
            string keyword = "\"videoDetails\":";
            int at = html.IndexOf(keyword);
            if (at < 0) return false;
            int start = at + keyword.Length;
            while (start < html.Length && html[start] == ' ') start++;
            if (start >= html.Length || html[start] != '{') return false;
            string json = IsolateObject(html, start);
            if (json == "") return false; // truncated / not an object
            DataToken root;
            if (!VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary) return false;
            DataToken id, title;
            if (!root.DataDictionary.TryGetValue("videoId", TokenType.String, out id)) return false;
            if (!root.DataDictionary.TryGetValue("title", TokenType.String, out title)) return false;
            if (!MyListCodec.ValidVideoId(id.String)) return false;
            parsedId = id.String; parsedTitle = title.String;
            return true;
        }

        // The JSON object that starts at text[start] == '{', up to its matching '}'. Braces inside JSON strings
        // do not count; a quote ends a string only when it is not escaped (escape state is tracked per
        // character, so "\\" followed by a quote ends the string). "" when the object does not close within the bound.
        private string IsolateObject(string text, int start)
        {
            int depth = 0;
            bool inString = false, escaped = false;
            int limit = text.Length < start + 60000 ? text.Length : start + 60000;
            for (int i = start; i < limit; i++)
            {
                char c = text[i];
                if (inString)
                {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') inString = true;
                else if (c == '{') depth++;
                else if (c == '}')
                {
                    depth--;
                    if (depth == 0) return text.Substring(start, i - start + 1);
                }
            }
            return "";
        }


        // Tracks saved by an older version without a title: looked up once per session, quietly.
        public void BackfillTitles()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            return;
#endif
            if (backfillDone || store == null || !store.Editable()) return;
            backfillDone = true;
            int n = store.savedUrls.Length;
            // 1) every record without a title, once: which video identities are wanted
            backfillCount = 0; backfillNext = 0; backfillStarted = 0;
            backfillWanted = new DataDictionary();
            string[] identities = new string[n];
            for (int i = 0; i < n; i++)
            {
                identities[i] = MyListCodec.ConsistentIdentity(store.savedUrls[i], store.originals[i]);
                if (!string.IsNullOrEmpty(store.titles[i]) || identities[i] == "" || backfillWanted.ContainsKey(identities[i])) continue;
                backfillWanted.SetValue(identities[i], backfillCount);
                backfillKeys[backfillCount] = identities[i]; backfillUrls[backfillCount] = null; backfillFound[backfillCount] = "";
                backfillCount++;
            }
            if (backfillCount == 0) return;
            // 2) one bounded pass over the sources: titled Store records, YamaPlayer's tracks, verified titles
            for (int i = 0; i < n; i++)
                if (identities[i] != "") IndexSource(identities[i], store.titles[i], store.savedUrls[i]);
            indexing = true;
            ScanYamaPlayer("");
            indexing = false;
            // 3) titles that are already known: one Store commit, no request
            int known = 0;
            DataToken verified = new DataToken("");
            for (int k = 0; k < backfillCount; k++)
            {
                if (backfillFound[k] == "" && verifiedTitles.TryGetValue(backfillKeys[k], TokenType.String, out verified)) backfillFound[k] = CleanTitle(verified.String, backfillKeys[k]);
                if (backfillFound[k] != "") known++;
            }
            if (known > 0) store.FillTitles(backfillKeys, backfillFound, backfillCount);
            // 4) the rest: looked up a few at a time, in record order, each identity at most once per session
            ContinueBackfill();
        }

        // Records one track as a source for the wanted identities (title and / or a readable VRCUrl).
        private void IndexSource(string identity, string title, VRCUrl url)
        {
            DataToken slot = new DataToken(0);
            if (backfillWanted.TryGetValue(identity, TokenType.Int, out slot) && backfillFound[slot.Int] == "") backfillFound[slot.Int] = CleanTitle(title, identity);
            if (VRCUrl.IsNullOrEmpty(url) || !CanLookup(url.Get())) return;
            // The URL itself must be the wanted video.
            if (backfillWanted.TryGetValue(MyListCodec.Identity(url.Get()), TokenType.Int, out slot) && backfillUrls[slot.Int] == null) backfillUrls[slot.Int] = url;
        }

        // Starts the next lookups for old records: at most 4 running, at most 32 per session, never the same
        // identity twice. Called again whenever one of them ends (no polling).
        private void ContinueBackfill()
        {
            if (backfillContinuing) return;
            backfillContinuing = true;
            while (backfillNext < backfillCount && backfillStarted < 32 && pendCount < MaxPending)
            {
                int running = 0;
                for (int i = 0; i < pendCount; i++) if (pendBackfill[i]) running++;
                if (running >= 4) break;
                int k = backfillNext++;
                if (backfillFound[k] != "" || backfillUrls[k] == null) continue; // already titled / no readable URL: stays "タイトル未取得"
                int p = pendCount++;
                pendUrls[p] = backfillUrls[k]; pendAskUrls[p] = backfillUrls[k]; pendKeys[p] = backfillKeys[k]; pendOriginals[p] = backfillKeys[k];
                pendPlayers[p] = 1; pendLists[p] = -1; pendBackfill[p] = true;
                backfillStarted++;
                StartLookup(p);
            }
            backfillContinuing = false;
        }

        public override void OnVideoInfoLoaded() { TitleTick(); }

        // Finishes every lookup VideoInfo has answered: title -> the video is saved; no title -> it stays
        // unsaved and is marked "failed". Polls slowly only while something is loading (no Update).
        public void TitleTick()
        {
            lookupTickScheduled = false;
            if (pendCount == 0) return;
            DataDictionary cache = videoInfo == null ? null : (DataDictionary)videoInfo.GetProgramVariable("_info");
            bool changed = false, loading = false, backfillEnded = false;
            int i = 0;
            while (i < pendCount) // in the order the videos were entered
            {
                if (pendStates[i] != 0) { i++; continue; }
                // Each waiting video reads only its own result (YouTube: the verified title of its video identity;
                // others: VideoInfo's entry for the URL it asked with), never "whatever arrived".
                DataToken token = new DataToken("");
                bool done; string title = "";
                if (IsYouTubeKey(pendKeys[i]))
                {
                    done = verifiedTitles.TryGetValue(pendKeys[i], TokenType.String, out token);
                    if (done) title = CleanTitle(token.String, pendKeys[i]);
                }
                else
                {
                    done = cache != null && cache.TryGetValue(pendAskUrls[i].Get(), TokenType.String, out token);
                    if (done) title = CleanTitle(token.String, pendKeys[i]);
                }
                if (done && title != "" && store != null && store.Editable())
                {
                    changed = true;
                    if (pendBackfill[i]) { store.SetTitleByKey(-1, pendKeys[i], title); RemovePending(i); backfillEnded = true; }
                    else if (store.PlaylistIndex(pendLists[i]) < 0) RemovePending(i); // its playlist was deleted: dropped, never saved elsewhere
                    else { pendStates[i] = 1; PrefillTitle(i, title); i++; }
                }
                else if (done || Time.realtimeSinceStartup > pendDeadlines[i])
                {
                    changed = true;
                    if (pendBackfill[i]) { RemovePending(i); backfillEnded = true; }
                    else { pendStates[i] = 1; ConfirmationStatus(i, "title_confirm_failure"); Feedback("title_failed"); i++; }
                }
                else { loading = true; i++; }
            }
            if (changed) Refresh();
            if (backfillEnded) ContinueBackfill();
            if (pendCount > 0 && !lookupTickScheduled)
            {
                loading = false;
                for (int k = 0; k < pendCount; k++) if (pendStates[k] == 0) loading = true;
                if (loading) { lookupTickScheduled = true; SendCustomEventDelayedSeconds(nameof(TitleTick), 2f); }
            }
        }

        // "タイトルを入力して登録": the title could not be read automatically, so the user types it
        // (YamaPlayer's Modal + the same input used for playlist names). An empty title is never accepted.
        private void OpenManualTitle(int p)
        {
            if (p < 0 || p >= pendCount || pendBackfill[p]) return;
            OpenTitleConfirmation(p, "");
        }

        // The title dialog always says, in YamaPlayer's own message text, which title "登録" will save: the
        // current content of the input field (there is no other, hidden title).
        private string TitleMessage()
        {
            string current = nameInput.text == null ? "" : nameInput.text.Trim();
            return L(titleStatusKey) + "\n\n" + (current == "" ? L("title_enter") : L("title_will_save").Replace("{title}", current));
        }

        // The one place that puts a title into the dialog. The input field is the only title there is: the
        // message line is rebuilt from it and "登録" saves it. Called after the Modal and the field are active,
        // so the field has its real size when the visible text is laid out; SyncTitleField repeats that once the
        // Modal has finished its own layout.
        private void SetTitleField(string title)
        {
            titleFieldPrefilling = true;
            titleFieldInitial = title;
            LayoutRebuilder.ForceRebuildLayoutImmediate((RectTransform)nameInputRoot.transform.parent);
            nameInput.text = title;
            nameInput.ForceLabelUpdate();
            titleFieldPrefilling = false;
            ShowFieldText();
            modal.Message = TitleMessage();
            SendCustomEventDelayedFrames(nameof(SyncTitleField), 2);
        }

        public void SyncTitleField()
        {
            if (pendingDialog != 6 || modal == null || !nameInputRoot.activeInHierarchy) return;
            titleFieldPrefilling = true;
            nameInput.ForceLabelUpdate();
            titleFieldPrefilling = false;
            ShowFieldText();
            modal.Message = TitleMessage();
        }

        // The field is drawn the way YamaPlayer draws its own inputs: the InputField only takes the typing and
        // its own text stays transparent; a plain Text (a copy of the Modal's message Text) shows the field's
        // current value. The shown text is always exactly nameInput.text.
        private void ShowFieldText()
        {
            if (nameDisplay == null) return;
            nameDisplay.text = nameInput.text == null ? "" : nameInput.text;
            nameDisplay.color = Color.white;
        }

        // Re-applied whenever a dialog with the input opens.
        private void ApplyInputLook()
        {
            Text text = nameInput.textComponent;
            if (text != null) text.color = new Color(1f, 1f, 1f, 0f);
            ShowFieldText();
        }

        private void OpenTitleConfirmation(int p, string title)
        {
            manualKey = pendKeys[p]; manualList = pendLists[p];
            titleStatusKey = "title_confirm_message";
            titleFieldUserEdited = false;
            // Order: Modal and field first, the value afterwards (see SetTitleField).
            nameInputRoot.SetActive(true);
            ShowDialog(6, L("title_confirm"), TitleMessage(), L("register"));
            SetTitleField(title);
        }

        public void TitleFieldEdited()
        {
            ShowFieldText(); // every dialog that uses the field (playlist names and video titles)
            if (pendingDialog != 6) return;
            if (!titleFieldPrefilling) titleFieldUserEdited = true;
            if (modal != null) modal.Message = TitleMessage(); // typed or prefilled: the shown "will be saved" line follows the field
        }

        private void ConfirmationStatus(int p, string key)
        {
            if (pendingDialog == 6 && manualList == pendLists[p] && manualKey == pendKeys[p])
            {
                titleStatusKey = key;
                ShowDialog(6, L("title_confirm"), TitleMessage(), L("register"));
            }
        }

        private void PrefillTitle(int p, string title)
        {
            if (pendingDialog != 6 || manualList != pendLists[p] || manualKey != pendKeys[p]) return;
            ConfirmationStatus(p, "title_confirm_message");
            if (titleFieldUserEdited || nameInput.text != titleFieldInitial) return;
            SetTitleField(title);
        }

        private void ConfirmManualTitle()
        {
            string title = nameInput.text == null ? "" : nameInput.text.Trim();
            if (title == "") { Feedback("title_required_input"); return; } // the dialog stays open
            int p = -1;
            for (int i = 0; i < pendCount; i++)
                if (!pendBackfill[i] && pendLists[i] == manualList && pendKeys[i] == manualKey) p = i;
            if (p < 0) return; // cancelled or saved meanwhile
            // Same track form as an automatic add: entered VRCUrl, canonical original URL, player type.
            if (CommitVideo(pendUrls[p], title, pendOriginals[p], pendPlayers[p], pendLists[p]))
            {
                RemovePending(p);
                pendingDialog = 0; // A successful confirmation is not a cancellation.
                CloseDialog();
            }
            Refresh();
        }

        // "再試行": the whole resolver runs again (a title or a readable URL may be known by now).
        private void RetryPending(int p)
        {
            if (p < 0 || p >= pendCount || pendStates[p] == 0 || pendBackfill[p]) return;
            ResolvePending(p, true);
            Refresh();
        }

        // "URLを入力し直す": the waiting video is dropped and the add choices are opened again.
        private void ReenterPending(int p)
        {
            if (p < 0 || p >= pendCount || pendStates[p] == 0) return;
            RemovePending(p);
            addMenuOpen = true;
            Feedback("reenter_url_hint");
            Refresh();
        }

        private void RemovePending(int index)
        {
            for (int i = index; i < pendCount - 1; i++)
            {
                pendUrls[i] = pendUrls[i + 1]; pendAskUrls[i] = pendAskUrls[i + 1]; pendKeys[i] = pendKeys[i + 1]; pendOriginals[i] = pendOriginals[i + 1];
                pendPlayers[i] = pendPlayers[i + 1]; pendLists[i] = pendLists[i + 1]; pendDeadlines[i] = pendDeadlines[i + 1];
                pendStates[i] = pendStates[i + 1]; pendBackfill[i] = pendBackfill[i + 1]; pendRequest[i] = pendRequest[i + 1];
            }
            pendCount--;
        }

        // ---------- actions for an open YamaPlayer playlist (e.g. an "Add Youtube Playlist" result) ----------

        private Playlist ReadyNativePlaylist()
        {
            Playlist playlist = OpenNativePlaylist();
            if (playlist == null) return null;
            if (playlist.IsLoading) { Feedback("playlist_loading_wait"); return null; }
            if (playlist.Length == 0) { Feedback("playlist_empty"); return null; }
            return playlist;
        }

        public void NativeQueueAll()
        {
            Playlist playlist = ReadyNativePlaylist();
            if (playlist == null || !QueueAllowed()) return;
            Playlist queue = controller.Queue;
            queue.TakeOwnership();
            int added = 0;
            for (int i = 0; i < playlist.Length; i++)
            {
                Track track = playlist.GetTrack(i);
                if (!CanQueueTrack(track)) continue;
                queue.Tracks.Add(track);
                added++;
            }
            if (added == 0) return;
            queue.SendEvent();
            DoneText(L("added_queue_n").Replace("{n}", added.ToString()));
        }

        // "Save as a persistent playlist": a new playlist, name prefilled from YamaPlayer's playlist.
        public void NativeSave()
        {
            Playlist playlist = ReadyNativePlaylist();
            if (playlist == null) return;
            if (store == null || !store.Editable()) { Feedback("not_ready"); return; }
            if (store.playlistIds.Length >= MyListCodec.MaxPlaylists) { Feedback("playlist_limit"); return; }
            HidePicker();
            pendingNative = playlist;
            string name = playlist.PlaylistName;
            if (string.IsNullOrEmpty(name)) name = L("youtube_playlist");
            nameInput.text = name.Length > 48 ? name.Substring(0, 48) : name;
            nameInputRoot.SetActive(true);
            string message = L("save_message").Replace("{n}", playlist.Length.ToString()) + "\n" + L("save_partial_note");
            ShowDialog(5, L("save_as_persistent"), message, L("save"));
        }

        public void SaveNativeAsNew()
        {
            Playlist playlist = pendingNative;
            if (playlist == null) { CloseDialog(); return; }
            string name = nameInput.text == null ? "" : nameInput.text.Trim();
            if (name == "") { Feedback("name_required"); return; }
            if (store.playlistIds.Length >= MyListCodec.MaxPlaylists) { Feedback("playlist_limit"); return; }
            CloseDialog();
            CommitTracks(playlist.Tracks, -1, name);
        }

        // "Add to an existing persistent playlist": the user picks the destination explicitly.
        public void OpenAppendPicker()
        {
            Playlist playlist = ReadyNativePlaylist();
            if (playlist == null) return;
            if (store == null || !store.Editable()) { Feedback("not_ready"); return; }
            pendingNative = playlist;
            int count = store.playlistIds.Length;
            for (int i = 0; i < pickerRows.Length; i++)
            {
                MyListNativePlaylistRow row = pickerRows[i];
                if (row == null) continue;
                bool show = i < count;
                if (row.gameObject.activeSelf != show) row.gameObject.SetActive(show);
                if (!show) continue;
                row.index = i;
                SetChildText(row.transform, "Text", store.playlistNames[i]);
                SetChildText(row.transform, "TrackCount", L("tracks_kind").Replace("{n}", CountTracks(store.playlistIds[i]).ToString()).Replace("{kind}", L("kind_persistent")));
                StyleRow(row.transform, iconPersistent);
            }
            Transform info = pickerHeader.transform.Find("Info");
            SetChildText(info, "Title", L("pick_target").Replace("{n}", playlist.Length.ToString()));
            SetChildText(info, "Url", L("partial_note_short"));
            // The chooser takes the place of the track list (same position, same list style).
            nativeActions.SetActive(false);
            RectTransform rect = (RectTransform)nativeTracks.transform;
            rect.offsetMax = new Vector2(nativeTracksTop.x, nativeTracksTop.y - ((RectTransform)rect.parent).rect.height);
            pickerRoot.SetActive(true);
            ResetRow(pickerHeader);
            if (toastRoot != null) toastRoot.transform.SetAsLastSibling();
        }

        public void PickTarget(int index)
        {
            Playlist playlist = pendingNative;
            HidePicker();
            if (playlist == null || store == null || !store.Editable() || index < 0 || index >= store.playlistIds.Length) return;
            CommitTracks(playlist.Tracks, store.playlistIds[index], "");
        }

        public void HidePicker()
        {
            if (pickerRoot == null || !pickerRoot.activeSelf) return;
            pickerRoot.SetActive(false);
            pendingNative = null;
            UpdateNativeActions(); // back to the YamaPlayer playlist (or YamaPlayer's layout if it was left)
        }

        // All-or-nothing: Store.AddMany validates capacity and duplicates before committing.
        private void CommitTracks(DataList<Track> source, int playlistId, string newName)
        {
            // Titles come from YamaPlayer's playlist parser (Track.Title) and are saved as they are.
            // A track without a title is not saved (a saved video always has a title).
            int total = source.Count(), count = 0;
            for (int i = 0; i < total; i++) if (!string.IsNullOrEmpty(source.GetValue(i).GetTitle())) count++;
            int untitled = total - count;
            if (count == 0) { Feedback("import_no_titles"); return; }
            VRCUrl[] urls = new VRCUrl[count];
            string[] titles = new string[count];
            string[] originals = new string[count];
            int[] players = new int[count];
            int n = 0;
            for (int i = 0; i < total; i++)
            {
                Track track = source.GetValue(i);
                if (string.IsNullOrEmpty(track.GetTitle())) continue;
                VRCUrl url = track.GetVRCUrl();
                string original = track.GetOriginalUrl();
                urls[n] = url == null ? VRCUrl.Empty : url;
                if (string.IsNullOrEmpty(original)) original = VRCUrl.IsNullOrEmpty(urls[n]) ? "" : urls[n].Get();
                originals[n] = original;
                titles[n] = track.GetTitle();
                players[n] = (int)track.GetPlayerType();
                n++;
            }
            int beforeTracks = store.savedUrls.Length;
            int beforeLists = store.playlistIds.Length;
            store.AddMany(urls, titles, originals, players, playlistId, newName);
            bool created = store.playlistIds.Length > beforeLists;
            int added = store.savedUrls.Length - beforeTracks;
            if (!created && added == 0) { FeedbackText(MyListLocalization.LegacyStatus(store.status, japanese)); return; }
            int target = store.PlaylistIndex(created ? store.playlistIds[store.playlistIds.Length - 1] : playlistId);
            // The save itself is not announced. Only tracks that were left out are (the user has to know).
            DoneText(L("saved_to").Replace("{n}", added.ToString()).Replace("{name}", target >= 0 ? store.playlistNames[target] : ""));
            string skipped = "";
            if (count - added > 0) skipped = L("skipped_n").Replace("{n}", (count - added).ToString());
            if (untitled > 0) skipped += (skipped == "" ? "" : "\n") + L("skipped_untitled_n").Replace("{n}", untitled.ToString());
            if (skipped != "") FeedbackText(skipped);
        }

        // ---------- feedback ----------

        // Something the user has to know (a problem, a refusal, a running import): shown at the bottom of the screen.
        public void Feedback(string key) { lastFeedback = key; FeedbackText(L(key)); }

        // A normal completion (saved, added, moved, deleted, queued, playback requested): nothing is shown on
        // screen; it only goes to the log.
        private void Done(string key) { lastFeedback = key; Debug.Log("[DM MyList] " + MyListLocalization.Text(key, false)); }
        private void DoneText(string text) { Debug.Log("[DM MyList] " + text); }

        public void FeedbackText(string text)
        {
            if (toastText != null) toastText.text = text;
            if (toastRoot != null) toastRoot.SetActive(true);
            toastUntil = Time.realtimeSinceStartup + 4f;
            SendCustomEventDelayedSeconds(nameof(HideToast), 4.1f);
        }

        public void HideToast()
        {
            if (Time.realtimeSinceStartup < toastUntil) return;
            if (toastRoot != null) toastRoot.SetActive(false);
        }
    }
}
