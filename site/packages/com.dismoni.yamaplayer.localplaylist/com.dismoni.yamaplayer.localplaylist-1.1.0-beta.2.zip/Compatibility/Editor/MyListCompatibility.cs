// YamaPlayer compatibility contract. This assembly references neither YamaPlayer nor the add-on's own code: it looks
// at the installed YamaPlayer through reflection and at its prefab, so it still runs (and can say what is missing)
// when a YamaPlayer update breaks the add-on's compilation.
//   - Compatibility/compatibility.json lists the YamaPlayer versions that were verified (contract + real client).
//     A version that is not listed is NOT VERIFIED, whatever the contract check says. Adding a version there is the
//     only change needed when a new YamaPlayer passes without code changes.
//   - The version number alone never decides: the API and the screen hierarchy the add-on uses are checked.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace DM.YamaMyList.Compatibility
{
    public class MyListCompatibilityReport
    {
        public string YamaPlayerVersion = "", WebUnitVersion = "";
        public bool Listed;                    // the installed version is in compatibility.json
        public List<string> Passed = new List<string>(), Failed = new List<string>();
        public bool ContractOk { get { return Failed.Count == 0; } }
        // VERIFIED only for a listed version whose contract also holds.
        public string Status { get { return YamaPlayerVersion == "" ? "YAMAPLAYER NOT INSTALLED" : !ContractOk ? "INCOMPATIBLE" : Listed ? "VERIFIED" : "NOT VERIFIED"; } }
        // F1b "play again" is a separate capability: its items never enter Passed / Failed, so a YamaPlayer without
        // them is still compatible (every other feature works; F1b is just not shown).
        public List<string> F1bPassed = new List<string>(), F1bFailed = new List<string>();
        public bool F1bAvailable { get { return YamaPlayerVersion != "" && F1bPassed.Count > 0 && F1bFailed.Count == 0; } }
        public override string ToString()
        {
            return "YAMAPLAYER_VERSION: " + YamaPlayerVersion + "\nWEBUNIT_VERSION: " + (WebUnitVersion == "" ? "not installed" : WebUnitVersion) +
                "\nCONTRACT: " + Passed.Count + "/" + (Passed.Count + Failed.Count) + "\nSTATUS: " + Status +
                (Failed.Count > 0 ? "\nFAILED:\n  " + string.Join("\n  ", Failed) : "") +
                "\nF1B: " + (F1bAvailable ? "AVAILABLE" : "NOT AVAILABLE") + " (" + F1bPassed.Count + "/" + (F1bPassed.Count + F1bFailed.Count) + ")" +
                (F1bFailed.Count > 0 ? "\nF1B_MISSING:\n  " + string.Join("\n  ", F1bFailed) : "");
        }
    }

    public static class MyListCompatibility
    {
        public const string YamaPackage = "Packages/net.kwxxw.yama-stream";
        public const string WebUnitPackage = "Packages/net.kwxxw.yamachan-web-unit";
        public const string MatrixGuid = "5d0e8f4b6a1c4e2f9b7a3c8d2e6f1a40"; // Compatibility/compatibility.json
        const BindingFlags Any = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

        // type -> members the add-on calls or reads (method / property / field, public or serialized private).
        static readonly Dictionary<string, string[]> Api = new Dictionary<string, string[]>
        {
            { "Yamadev.YamaStream.Controller", new[] { "SetTime", "TakeOwnership", "PlayTrack", "AddListener", "AddDynamicPlaylist", "Playlists", "Queue", "History",
                "ActivePlaylist", "PlayingTrackIndex", "Track", "PlayerPermission", "IsLocal", "IsPlaying", "IsLoading", "Stopped", "SlideMode", "VideoTime", "Duration",
                "VideoPlayerType", "ResolveTrack", "_playlists", "_dynamicPlaylists" } },
            { "Yamadev.YamaStream.UI.UIController", new[] { "CheckPermission", "UpdatePlaylistsContent", "PrimaryColor", "_controller", "_playlists", "_playlistTracks",
                "_playlistName", "_playlistSelector", "_playlistIndex" } },
            { "Yamadev.YamaStream.Playlist", new[] { "Tracks", "SendEvent", "TakeOwnership", "_playlistName", "_controller" } },
            { "Yamadev.YamaStream.Track", new[] { "New" } },
            { "Yamadev.YamaStream.UI.Modal", new[] { "Show", "Message", "CloseEvent" } },
            { "Yamadev.YamaStream.UI.LoopScroll", new[] { "Render", "Indexes", "LastIndexes", "Length", "CallbackEvent" } },
            { "Yamadev.YamaStream.UI.UIColor", new[] { "_uiController" } },
            { "Yamadev.YamaStream.VideoInfo", new[] { "GetVideoInfo", "_controller", "_info" } },
            { "Yamadev.YamaStream.Modules.VideoResolver", new[] { "_controller", "_client" } },
            { "Yamadev.YamaStream.Script.YamaPlayer", new string[0] },
            // the static playlist entries (counted for the playback slot, see MyListProductSetup.StaticPlaylistCount)
            { "Yamadev.YamaStream.Script.PlayListContainer", new[] { "TargetContent" } },
            { "Yamadev.YamaStream.Script.PlayList", new[] { "PlayListName", "Tracks", "playListName", "tracks" } },
            { "Yamadev.YamaStream.Editor.PlaylistBuildProcess", new[] { "OnProcessScene", "callbackOrder" } },
            { "Yamadev.YamaStream.Editor.PlaylistUtils", new[] { "ReadPlaylists" } },
            { "Yamadev.YamaStream.VideoPlayerType", new string[0] },
            { "Yamadev.YamaStream.PlayerPermission", new[] { "Editor" } },
        };

        // WebUnit (optional): checked only when it is installed.
        static readonly Dictionary<string, string[]> WebUnitApi = new Dictionary<string, string[]>
        {
            { "Yamadev.YamachanWebUnit.Client", new[] { "Urls", "MaxLength", "IsLoading", "Request" } },
        };

        // Under the screen UI (the object with UIController) of YamaPlayer.prefab: path -> required component (or "").
        static readonly Dictionary<string, string> Hierarchy = new Dictionary<string, string>
        {
            { "Canvas", "" },
            { "Canvas/Modal", "Yamadev.YamaStream.UI.Modal" },
            { "Canvas/Modal/Scroll View/Viewport/Content", "" },
            { "Canvas/Control", "UnityEngine.Animator" },
            { "Canvas/Control/Main/Bottom", "" },
            { "Canvas/Control/Main/Bottom/Actions", "" },            // the seek buttons go next to this group
        };

        static Type Find(string fullName)
        {
            return AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType(fullName, false)).FirstOrDefault(t => t != null);
        }

        static string Version(string packageDir)
        {
            string path = packageDir + "/package.json";
            if (!File.Exists(path)) return "";
            var m = Regex.Match(File.ReadAllText(path), "\"version\"\\s*:\\s*\"([^\"]+)\"");
            return m.Success ? m.Groups[1].Value : "unknown";
        }

        public static string[] VerifiedVersions()
        {
            string path = AssetDatabase.GUIDToAssetPath(MatrixGuid);
            var asset = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<TextAsset>(path);
            if (!asset) return new string[0];
            // {"yamaplayer": [{"version": "1.5.18", "status": "VERIFIED"}, ...]}
            return Regex.Matches(asset.text, "\\{[^{}]*\"version\"\\s*:\\s*\"([^\"]+)\"[^{}]*\"status\"\\s*:\\s*\"VERIFIED\"[^{}]*\\}")
                .Cast<Match>().Select(m => m.Groups[1].Value).ToArray();
        }

        // F1b "play again" (Docs/F1B_PLAY_AGAIN_SPEC.md 9-10): what it reads and calls. Not part of the contract above.
        static readonly Dictionary<string, string[]> F1bApi = new Dictionary<string, string[]>
        {
            { "Yamadev.YamaStream.Controller", new[] { "IsReload", "VideoPlayerType", "PlayTrack", "Track", "IsLoading", "IsPlaying", "PlayerPermission", "ResolveTrack" } },
            { "Yamadev.YamaStream.Listener", new[] { "OnVideoError", "OnUrlChanged", "OnVideoStart", "OnVideoStop" } },
            { "Yamadev.YamaStream.UI.UIController", new[] { "_loading" } },
        };

        static void Check(MyListCompatibilityReport report, Dictionary<string, string[]> api)
        {
            Check(report.Passed, report.Failed, api);
        }

        static void Check(List<string> passed, List<string> failed, Dictionary<string, string[]> api)
        {
            foreach (var pair in api)
            {
                Type type = Find(pair.Key);
                if (type == null) { failed.Add("type " + pair.Key + " not found"); continue; }
                passed.Add("type " + pair.Key);
                foreach (string member in pair.Value)
                {
                    bool found = false;
                    for (Type t = type; t != null && !found; t = t.BaseType) found = t.GetMember(member, Any | BindingFlags.DeclaredOnly).Length > 0;
                    if (found) passed.Add(pair.Key + "." + member); else failed.Add(pair.Key + "." + member + " not found");
                }
            }
        }

        // F1b capability. Its result is only a warning / "F1b: available or not"; it never changes the contract status.
        static void CheckF1b(MyListCompatibilityReport report, Component ui)
        {
            Check(report.F1bPassed, report.F1bFailed, F1bApi);
            Type controller = Find("Yamadev.YamaStream.Controller"), track = Find("Yamadev.YamaStream.Track");
            if (controller != null && track != null)
            {
                bool playTrack = controller.GetMethods(Any).Any(m => m.Name == "PlayTrack" && m.GetParameters().Length == 2 &&
                    m.GetParameters()[0].ParameterType == track && m.GetParameters()[1].ParameterType == typeof(bool));
                if (playTrack) report.F1bPassed.Add("Controller.PlayTrack(Track, bool)"); else report.F1bFailed.Add("Controller.PlayTrack(Track, bool) not found");
                PropertyInfo reload = controller.GetProperty("IsReload", Any);
                if (reload != null && reload.PropertyType == typeof(bool)) report.F1bPassed.Add("Controller.IsReload is bool"); else report.F1bFailed.Add("Controller.IsReload is not a bool property");
            }
            if (report.WebUnitVersion == "") report.F1bFailed.Add("WebUnit is not installed");
            if (!ui) { report.F1bFailed.Add("YamaPlayer.prefab: no UIController"); return; }
            var p = new SerializedObject(ui).FindProperty("_loading");
            var loading = p != null && p.propertyType == SerializedPropertyType.ObjectReference ? p.objectReferenceValue as GameObject : null;
            if (!loading) { report.F1bFailed.Add("UIController._loading is not a set reference in the prefab"); return; }
            report.F1bPassed.Add("UIController._loading is set in the prefab");
            if (loading.transform.parent && loading.transform.parent.GetComponent<UnityEngine.UI.Toggle>()) report.F1bPassed.Add("the parent of _loading is a UI Toggle");
            else report.F1bFailed.Add("the parent of _loading is not a UI Toggle");
        }

        public static MyListCompatibilityReport Run()
        {
            var report = new MyListCompatibilityReport { YamaPlayerVersion = Version(YamaPackage), WebUnitVersion = Version(WebUnitPackage) };
            if (report.YamaPlayerVersion == "") { report.Failed.Add("YamaPlayer (net.kwxxw.yama-stream) is not installed"); return report; }
            report.Listed = VerifiedVersions().Contains(report.YamaPlayerVersion);
            Check(report, Api);
            if (report.WebUnitVersion != "") Check(report, WebUnitApi);

            // signatures the add-on relies on
            Type controller = Find("Yamadev.YamaStream.Controller"), playlist = Find("Yamadev.YamaStream.Playlist");
            if (controller != null && playlist != null)
            {
                bool playTrack = controller.GetMethods(Any).Any(m => m.Name == "PlayTrack" && m.GetParameters().Length == 2 &&
                    m.GetParameters()[0].ParameterType == playlist && m.GetParameters()[1].ParameterType == typeof(int));
                if (playTrack) report.Passed.Add("Controller.PlayTrack(Playlist, int)"); else report.Failed.Add("Controller.PlayTrack(Playlist, int) not found");
                bool setTime = controller.GetMethods(Any).Any(m => m.Name == "SetTime" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType == typeof(float));
                if (setTime) report.Passed.Add("Controller.SetTime(float)"); else report.Failed.Add("Controller.SetTime(float) not found");
                // Track.GetVRCUrl is an extension method
                Type track = Find("Yamadev.YamaStream.Track");
                bool getUrl = track != null && track.Assembly.GetTypes().Where(t => t.IsAbstract && t.IsSealed).SelectMany(t => t.GetMethods(Any))
                    .Any(m => m.Name == "GetVRCUrl" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType == track);
                if (getUrl) report.Passed.Add("Track.GetVRCUrl()"); else report.Failed.Add("Track.GetVRCUrl() not found");
                FieldInfo lists = controller.GetField("_playlists", Any);
                if (lists != null && lists.FieldType == playlist.MakeArrayType()) report.Passed.Add("Controller._playlists is Playlist[]"); else report.Failed.Add("Controller._playlists is not Playlist[]");
            }

            // screen hierarchy of the shipped prefab
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(YamaPackage + "/YamaPlayer.prefab");
            Type uiType = Find("Yamadev.YamaStream.UI.UIController");
            Component ui = prefab && uiType != null ? prefab.GetComponentInChildren(uiType, true) : null;
            if (!ui) report.Failed.Add("YamaPlayer.prefab: no UIController under " + YamaPackage + "/YamaPlayer.prefab");
            else
            {
                report.Passed.Add("YamaPlayer.prefab has a UIController");
                Type containerType = Find("Yamadev.YamaStream.Script.PlayListContainer");
                int containers = containerType != null ? prefab.GetComponentsInChildren(containerType, true).Length : 0;
                if (containers == 1) report.Passed.Add("YamaPlayer.prefab has exactly one PlayListContainer"); else report.Failed.Add("YamaPlayer.prefab has " + containers + " PlayListContainers (1 expected)");
                foreach (var pair in Hierarchy)
                {
                    Transform t = ui.transform.Find(pair.Key);
                    Type need = pair.Value == "" ? null : Find(pair.Value) ?? Type.GetType(pair.Value + ", UnityEngine.AnimationModule");
                    if (!t) report.Failed.Add("hierarchy: " + pair.Key + " not found");
                    else if (pair.Value != "" && (need == null || !t.GetComponent(need))) report.Failed.Add("hierarchy: " + pair.Key + " has no " + pair.Value);
                    else report.Passed.Add("hierarchy: " + pair.Key);
                }
                var so = new SerializedObject(ui);
                foreach (string field in new[] { "_controller", "_playlists", "_playlistTracks", "_playlistName", "_playlistSelector" })
                {
                    var p = so.FindProperty(field);
                    if (p != null && p.propertyType == SerializedPropertyType.ObjectReference && p.objectReferenceValue) report.Passed.Add("UIController." + field + " is set in the prefab");
                    else report.Failed.Add("UIController." + field + " is not a set reference in the prefab");
                }
                var selector = so.FindProperty("_playlistSelector") != null ? so.FindProperty("_playlistSelector").objectReferenceValue as Transform : null;
                int toggles = selector ? selector.GetComponentsInChildren<UnityEngine.UI.Toggle>(true).Length : 0;
                if (toggles >= 3) report.Passed.Add("playlist selector has Queue / History / Playlist tabs"); else report.Failed.Add("playlist selector has " + toggles + " tabs (3 expected)");
            }
            CheckF1b(report, ui);
            return report;
        }

        // For the dev runner / CI: writes Logs/DM_LocalPlaylist_Compatibility.txt and returns it.
        public static string RunAndWrite()
        {
            string text = Run().ToString();
            Directory.CreateDirectory("Logs");
            File.WriteAllText("Logs/DM_LocalPlaylist_Compatibility.txt", text);
            return text;
        }
    }
}
