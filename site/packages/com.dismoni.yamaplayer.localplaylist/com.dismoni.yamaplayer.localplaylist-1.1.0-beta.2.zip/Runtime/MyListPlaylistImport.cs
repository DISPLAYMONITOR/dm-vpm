namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;
    using VRC.SDK3.Data;
    using VRC.SDK3.StringLoading;
    using VRC.SDKBase;
    using VRC.Udon.Common.Interfaces;
    using Yamadev.YamaStream;
    using Yamadev.YamaStream.Libraries.GenericDataContainer;

    // One YouTube playlist import into a persistent playlist. Downloads the page and reads it with YamaPlayer's
    // own parser (YouTube.GetPlaylistFromHtml), exactly as YamaPlayer's Playlist.LoadPlaylist does, but without
    // Controller.AddDynamicPlaylist: no standard (temporary, shared) YamaPlayer playlist is created.
    // The view makes one copy of this object per import and destroys it afterwards, so a page the parser
    // cannot handle stops only that copy (YamaPlayer isolates it the same way: one Playlist object per import).
    //
    // IMPORT-URL-01 fallback (Docs/IMPORT_URL01_LOCKUP_FALLBACK_DESIGN.md, revision 6): when YamaPlayer's parser
    // finds no track on a "https://www.youtube.com/playlist?list=..." page, the page's ytInitialData is read here as
    // the newer "lockupViewModel" list, a few milliseconds per frame (state 5). The scan also checks the JSON grammar
    // of the whole ytInitialData (VRCJson accepts some malformed text). Tracks are kept only when the whole list
    // could be checked; anything unknown, rejected, malformed or continued saves nothing.
    //
    // IMPORT-B2 (1.1.0-beta.2): a "https://www.youtube.com/playlist?list=..." page is no longer given to YamaPlayer's
    // parser at all. YamaPlayer's ParsePlaylistRenderer reads every item of the older "playlistVideoListRenderer" list
    // without checking its kind, and the "continuationItemRenderer" item YouTube adds after the first 100 tracks
    // stopped the import object ("Attempted to access Error token as DataDictionary"). The scanner below reads both
    // forms: the older list (form A, items "playlistVideoRenderer") and the newer "lockupViewModel" list (form B).
    // One import keeps at most MaxImportTracks tracks: the first ones YouTube returned. A continuation item (or more
    // checked tracks than that) is "partial": the tracks read are saved and the user is told the rest is not imported.
    // Any item that cannot be confirmed still saves nothing.
    //
    // YouTube Mix (revision 11): a "https://www.youtube.com/watch?v=<video>&list=RD<video>" request (LoadMix) is not
    // given to YamaPlayer's parser. The same scanner reads ytInitialData and keeps only the one list at
    // contents>twoColumnWatchNextResults>playlist>playlist (its playlistId must be the requested Mix); every item must
    // be a playlistPanelVideoRenderer that names the requested Mix. At most MaxMixItems items; anything else saves nothing.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListPlaylistImport : UdonSharpBehaviour
    {
        public MyListPersistentView view;
        // 0 idle, 1 loading, 2 parsing, 3 parsed (tracks valid), 4 failed, 5 fallback parsing (several frames)
        [System.NonSerialized] public int state;
        [System.NonSerialized] public string body = "";
        [System.NonSerialized] public DataList<Track> tracks;
        // Stopped by the user (or its playlist was deleted) while the request was still waiting in VRChat's download
        // queue: the answer, whenever it arrives, is thrown away and this object removes itself.
        [System.NonSerialized] public bool cancelled;
        [System.NonSerialized] public int orphanEpoch; // the view's generation of stopped imports this one was counted in
        [System.NonSerialized] public int errorCode;
        [System.NonSerialized] public string errorText = "";

        // ---- fallback results (read by the view; counts and reason names only, never IDs or titles) ----
        [System.NonSerialized] public bool fbUsed;               // the fallback ran (state 5 was entered)
        [System.NonSerialized] public string fbOutcome = "";     // saved / rejected / failed:<reason>
        [System.NonSerialized] public int fbLockups, fbAccepted, fbDuplicates, fbRejected, fbUnknownShape, fbContinuation;
        // IMPORT-B2: the list read was form A (playlistVideoRenderer); only part of the list was saved (a continuation
        // item, or checked tracks beyond MaxImportTracks, which are counted in fbOverLimit and not saved)
        [System.NonSerialized] public bool fbFormA, fbPartial;
        [System.NonSerialized] public int fbOverLimit;
        [System.NonSerialized] public int fbNotVideo, fbBadId, fbNoTitle, fbEndpoint, fbBadShape, fbEscapedSurrogate;
        [System.NonSerialized] public int beatFrame;             // heartbeat of state 5 (the view's ImportTick watches it)
        [System.NonSerialized] public float beatTime;
        [System.NonSerialized] public double scanMaxFrameMs;     // the longest frame of state 5 (log only)

        // ---- Mix results (revision 11; the fb counters above count the item checks; never IDs or titles) ----
        [System.NonSerialized] public bool mixUsed;              // a Mix request (LoadMix)
        [System.NonSerialized] public string mixOutcome = "";    // saved / unavailable / rejected / failed:<reason>
        [System.NonSerialized] public bool mixInfinite;          // the list says isInfinite (only its first part is read)
        [System.NonSerialized] public int mixItems, mixValid, mixDuplicates, mixPagePanels;

        private const int MaxBodyChars = 3000000;
        private const int MaxInitialDataChars = 2500000;
        private const int MaxElementChars = 65536;
        private const int MaxNodesPerElement = 2000;
        private const int MaxWalkDepth = 64;
        private const int MaxDepth = 256;
        // IMPORT-B2: direct elements of the target array the scanner reads at all (videos, continuation and unknown
        // shapes together); above it nothing is saved (tooMany). At most MaxImportTracks of them are kept.
        private const int MaxCandidates = 200;
        private const int MaxImportTracks = 100;
        private const double FrameBudgetMs = 3.0;   // a budget, not a guaranteed maximum
        private const int CheckEvery = 32;
        private const int MaxFrames = 3000;
        private const double MaxWallSeconds = 60.0;
        private const string PrimaryPath = ">rendererContext>commandContext>onTap>innertubeCommand>watchEndpoint";
        private const string AuxThumbPrefix = ">contentImage>thumbnailViewModel>overlays>[]>";
        private const string AuxMenuPrefix = ">metadata>lockupMetadataViewModel>menuButton>buttonViewModel>";
        private const string AuxM1Suffix = ">signalServiceEndpoint>actions>[]>addToPlaylistCommand";
        private const string AuxM2Suffix = ">[]>addToPlaylistCommand>videoCommand>watchEndpoint";
        private const int MaxMixItems = 100;
        private const int MaxMixIdChars = 64;

        [System.NonSerialized] private bool fallbackAllowed;
        [System.NonSerialized] private string requestedList = "";   // the 'list' value of the request, in memory only
        [System.NonSerialized] private bool mixMode;
        [System.NonSerialized] private string requestedVideo = "";  // the 'v' value of a Mix request, in memory only

        public void Load(VRCUrl url)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            state = 1;
            requestedList = FallbackList(url == null ? "" : url.Get());
            fallbackAllowed = requestedList.Length > 0;
            VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
        }

        // A Mix request. The view validates list=RD<seed> separately from the current `video` (URL-02); the IDs may differ.
        public void LoadMix(VRCUrl url, string list, string video)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            state = 1;
            requestedList = list;
            requestedVideo = video;
            fallbackAllowed = false;
            mixMode = true;
            mixUsed = true;
            VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
        }

        public override void OnStringLoadSuccess(IVRCStringDownload result)
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; return;
#endif
            body = result.Result;
            Answered();
        }

        // The page arrived (`body`). A stopped import throws it away.
        public void Answered()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            if (cancelled) { Discard(); return; }
            Parse();
        }

        private void Discard()
        {
            state = 4;
            if (view != null) view.ImportOrphanAnswered(orphanEpoch);
            Destroy(gameObject);
        }

        public override void OnStringLoadError(IVRCStringDownload result)
        {
            errorCode = result.ErrorCode;
            errorText = result.Error == null ? "" : result.Error;
            Failed();
        }

        // The download ended with an error (`errorCode`, `errorText`).
        public void Failed()
        {
            if (cancelled) { Discard(); return; }
            if (errorCode == 0) errorCode = -1;
            state = 4;
            if (view != null) view.ImportFinished();
        }

        // Reads `body`. While the parser runs the state is 2; the view looks one frame later, and a state still
        // at 2 then means the parser stopped this behaviour. A /playlist page (fallbackAllowed) and a Mix go to the
        // scanner instead: the state becomes 5 and the view is told later (FallbackFinish).
        public void Parse()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            state = 2;
            if (view != null) view.SendCustomEventDelayedFrames(nameof(MyListPersistentView.ImportWatch), 1);
            if (string.IsNullOrEmpty(body)) { state = 4; if (view != null) view.ImportFinished(); return; }
            // a Mix is read only by the scanner (state 5); a page it cannot start on ends here (failReason says why)
            if (mixMode) { if (!FallbackBegin()) MixFinish(); return; }
            // IMPORT-B2: a /playlist?list= page is read only by the scanner (YamaPlayer's parser is not called for it)
            if (fallbackAllowed) { if (!FallbackBegin()) ScanNotStarted(); return; }
            ParseOnly();
            if (view != null) view.ImportFinished();
        }

        // The one place YamaPlayer's playlist parser is called (playlist import and the title of a single video
        // both come here). No callback: the caller reads `state` (3 = `tracks` valid; still 2 = the parser stopped
        // this behaviour) right after the call.
        public void ParseOnly()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            state = 2;
            tracks = YouTube.GetPlaylistFromHtml(body).GetTracks();
            state = 3;
        }

        // ---------- target URL (design §2) ----------

        // The 'list' value when the URL is exactly https://www.youtube.com/playlist?list=<value>, optionally with one
        // 'si=<value>' item (revision 8: YouTube's share links carry it), in any order (one 'list', at most one 'si',
        // no other query item, no fragment, no port, no user part, not a Mix); "" otherwise (no fallback). 'si' does
        // not loosen the check of the 'list' value.
        private string FallbackList(string u)
        {
            if (string.IsNullOrEmpty(u) || !u.StartsWith("https://")) return "";
            if (u.IndexOf('#') >= 0) return "";
            string rest = u.Substring(8);
            int slash = rest.IndexOf('/');
            if (slash <= 0) return "";
            if (rest.Substring(0, slash).ToLower() != "www.youtube.com") return "";   // also rejects ':' and '@'
            string pathAndQuery = rest.Substring(slash);
            int q = pathAndQuery.IndexOf('?');
            if (q < 0 || pathAndQuery.Substring(0, q) != "/playlist") return "";
            string query = pathAndQuery.Substring(q + 1);
            if (query.Length == 0) return "";
            string[] items = query.Split('&');
            string value = "";
            int lists = 0, shares = 0;
            for (int i = 0; i < items.Length; i++)
            {
                string item = items[i];
                if (item.StartsWith("si="))
                {
                    shares++;
                    if (!ShareValue(item.Substring(3))) return "";
                    continue;
                }
                if (!item.StartsWith("list=")) return "";
                lists++;
                value = item.Substring(5);
            }
            if (lists != 1 || shares > 1 || value.Length < 10 || value.Length > 64 || value.StartsWith("RD")) return "";
            for (int i = 0; i < value.Length; i++)
                if (!IdChar(value[i])) return "";
            return value;
        }

        // The value of YouTube's share item 'si': 1 to 64 characters of [A-Za-z0-9_-] (no percent encoding).
        private bool ShareValue(string s)
        {
            if (s.Length < 1 || s.Length > 64) return false;
            for (int i = 0; i < s.Length; i++) if (!IdChar(s[i])) return false;
            return true;
        }

        private bool IdChar(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
        }

        private bool IdFormat(string s)
        {
            if (s.Length != 11) return false;
            for (int i = 0; i < s.Length; i++) if (!IdChar(s[i])) return false;
            return true;
        }

        // At most MyListCodec.MaxTitleLength code units; one fewer when the last kept unit would be the first half of a
        // surrogate pair (so the Store's own cut to the same length never changes it).
        private string CapTitle(string s)
        {
            int max = MyListCodec.MaxTitleLength;
            if (s.Length <= max) return s;
            int last = (int)s[max - 1];
            return s.Substring(0, last >= 0xD800 && last <= 0xDBFF ? max - 1 : max);
        }

        // A real \uD800..\uDFFF escape in the JSON text (a backslash run of odd length before the 'u').
        private bool HasEscapedSurrogate(string t)
        {
            int i = t.IndexOf("\\u");
            while (i >= 0)
            {
                int k = i, run = 0;
                while (k >= 0 && t[k] == '\\') { run++; k--; }
                if (run % 2 == 1 && i + 3 < t.Length)
                {
                    char a = t[i + 2], b = t[i + 3];
                    if ((a == 'd' || a == 'D') && ((b >= '8' && b <= '9') || (b >= 'a' && b <= 'f') || (b >= 'A' && b <= 'F'))) return true;
                }
                i = t.IndexOf("\\u", i + 2);
            }
            return false;
        }

        // Every surrogate is part of a pair. The grammar accepts any \uXXXX (RFC 8259); VRCJson turns an escaped pair
        // such as 🎵 into broken text (a lone surrogate), so such a title is refused instead of saved broken.
        // Compared as numbers: a lone-surrogate char constant does not survive the Udon program's serialization.
        private bool WellFormedText(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                int c = (int)s[i];
                if (c >= 0xD800 && c <= 0xDBFF)
                {
                    if (i + 1 >= s.Length) return false;
                    int d = (int)s[i + 1];
                    if (d < 0xDC00 || d > 0xDFFF) return false;
                    i++;
                }
                else if (c >= 0xDC00 && c <= 0xDFFF) return false;
            }
            return true;
        }

        private bool SchemaName(string s)
        {
            if (s.Length == 0 || s.Length > 48) return false;
            for (int i = 0; i < s.Length; i++) { char c = s[i]; if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return false; }
            return true;
        }

        // ---------- fallback scanner (design §3.3): IndexOfAny jumps to the next structural character ----------

        [System.NonSerialized] private char[] outsideSet;
        [System.NonSerialized] private char[] insideSet;
        [System.NonSerialized] private string[] names;      // container key names by depth ("" = array item / no key)
        [System.NonSerialized] private string[] targetPath;
        [System.NonSerialized] private int sPos, sLimit, sDepth, sStrStart, sStrEnd;
        [System.NonSerialized] private bool sInStr, sAfterColon;
        [System.NonSerialized] private string sLastKey = "";
        [System.NonSerialized] private double frameStart, fbStart;
        [System.NonSerialized] private int fbFrames;
        // target array and its direct elements (design §3.4 (a))
        [System.NonSerialized] private bool tOpen, tClosed, eOpen, ePending, eKeyBad;
        [System.NonSerialized] private int tFound, tIdx, tStart, tEnd, tCommas, tDicts, tArrays, tStrings, tLock, tUnknownDict;
        [System.NonSerialized] private int tContElsewhere, eStart, eEnd, eKeyCount, ePrimary;
        [System.NonSerialized] private string eFirstKey = "";
        // walk of one lockup (other ID dictionaries)
        [System.NonSerialized] private DataList wTok, wPath, wParent, wDepth;
        [System.NonSerialized] private bool wActive, wBad;
        [System.NonSerialized] private int wNodes, wUnknown;
        [System.NonSerialized] private string wVideoId = "", wTitle = "";
        [System.NonSerialized] private DataDictionary seen;   // accepted video IDs, in memory only
        [System.NonSerialized] private string failReason = "";
        // JSON grammar (design §3.3.1, RFC 8259): what each open container expects next; no values are built.
        // Object: 0 key or '}', 1 key, 2 ':', 3 value, 4 ',' or '}'. Array: 5 value or ']', 6 value, 7 ',' or ']'.
        [System.NonSerialized] private int[] gExp;
        [System.NonSerialized] private bool gKey;             // the open string is a key
        [System.NonSerialized] private string syntaxAt = "";  // where the grammar failed (log only)
        // the text between two structural characters ("gap"): whitespace, or one number / true / false / null
        [System.NonSerialized] private int gapEnd, gPos, litState, numState, wordIdx;   // gapEnd < 0: no gap open
        [System.NonSerialized] private string word = "";
        // Mix (revision 11): the list object (contents>twoColumnWatchNextResults>playlist>playlist) and its playlistId
        [System.NonSerialized] private string[] mixObjectPath;
        [System.NonSerialized] private bool pOpen, pidPending, pidBad;
        [System.NonSerialized] private int pFound, pIdx, pidKeys;
        [System.NonSerialized] private string pidValue = "";
        [System.NonSerialized] private DataList mixIds, mixTitles;   // checked items, in memory only
        // R11-A02: how often each key on the way to the list occurs in its dictionary (root "contents",
        // "twoColumnWatchNextResults", "playlist", "playlist", the list's "contents"), whatever the value is
        [System.NonSerialized] private int[] pathKeys;
        [System.NonSerialized] private int outerFound;   // dictionaries opened at contents>twoColumnWatchNextResults>playlist
        // R11-A01: the real "var ytInitialData = {…};" statement, found in the page's markup before the JSON is read
        [System.NonSerialized] private bool locating, lInScript;
        [System.NonSerialized] private int lPos, lFound, lBrace, lEnd, lCs, lCe, lLp, lOcc, iEnd, lTemplates;
        [System.NonSerialized] private char[] tagSet, valueEndSet, jsSet, dqSet, sqSet, btSet, lineSet, nameEndSet;
        // R11-A01-R1-R2: the open SVG / MathML elements (lower-case names), fDepth = 0 outside foreign content
        [System.NonSerialized] private string[] fStack;
        [System.NonSerialized] private int fDepth;
        // the attributes of the last start tag read by ParseAttrs
        [System.NonSerialized] private string aType, aLang;
        [System.NonSerialized] private bool aSrc, aNomodule, aSelfClosing;

        // IMPORT-B2: a /playlist page the scanner could not start on (failReason says why): nothing is saved
        private void ScanNotStarted()
        {
            fbUsed = true;
            fbOutcome = "failed:" + failReason;
            tracks = DataList<Track>.New();
            state = 4;
            errorCode = 0;
            Debug.Log("[DM MyList] import PERSISTENT fallback: outcome " + fbOutcome + " (not started)");
            if (view != null) view.ImportFinished();
        }

        private bool FallbackBegin()
        {
            if (body.Length > MaxBodyChars) { failReason = "pageTooLong"; return false; }
            // no marker anywhere: nothing to locate (where a marker is, LocateRun decides whether it is the real one)
            // IMPORT-B2 F4: the markers are ASCII; Ordinal searches (culture-sensitive searches of the whole page were slow)
            if (body.IndexOf("ytInitialData = ", 0, System.StringComparison.Ordinal) < 0) { failReason = "initialDataMissing"; return false; }
            // IMPORT-B2: which list form the page carries, by its list / item marker; a page with both is not read
            // (form A is told by its list object, so an empty form A list is read as one and ends as failed:empty)
            fbFormA = false;
            if (!mixMode)
            {
                bool hasA = body.IndexOf("\"playlistVideoListRenderer\":", 0, System.StringComparison.Ordinal) >= 0;
                bool hasB = body.IndexOf("\"lockupViewModel\":", 0, System.StringComparison.Ordinal) >= 0;
                if (hasA && hasB) { failReason = "formConflict"; return false; }
                fbFormA = hasA;
            }
            outsideSet = new char[] { '"', ':', ',', '{', '}', '[', ']' };
            // inside a string: the end, an escape, or a control character (not allowed unescaped in JSON)
            insideSet = new char[34];
            insideSet[0] = '"'; insideSet[1] = '\\';
            for (int i = 0; i < 32; i++) insideSet[i + 2] = (char)i;
            names = new string[MaxDepth];
            gExp = new int[MaxDepth];
            gKey = false; syntaxAt = ""; gapEnd = -1; gPos = 0; litState = 0; numState = 0; wordIdx = 0; word = "";
            targetPath = new string[] { "contents", "twoColumnBrowseResultsRenderer", "tabs", "tabRenderer", "content",
                "sectionListRenderer", "contents", "itemSectionRenderer", "contents" };
            // form A: the same path, then the list object inside the item section (array items have no key)
            if (fbFormA)
                targetPath = new string[] { "contents", "twoColumnBrowseResultsRenderer", "tabs", "tabRenderer", "content",
                    "sectionListRenderer", "contents", "itemSectionRenderer", "contents", "playlistVideoListRenderer", "contents" };
            if (mixMode)
            {
                mixObjectPath = new string[] { "contents", "twoColumnWatchNextResults", "playlist", "playlist" };
                targetPath = new string[] { "contents", "twoColumnWatchNextResults", "playlist", "playlist", "contents" };
                pOpen = false; pidPending = false; pidBad = false; pFound = 0; pIdx = -10; pidKeys = 0; pidValue = "";
                pathKeys = new int[5]; outerFound = 0;
                mixIds = new DataList(); mixTitles = new DataList();
                mixOutcome = ""; mixInfinite = false; mixItems = 0; mixValid = 0; mixDuplicates = 0; mixPagePanels = 0;
            }
            sPos = 0; sDepth = 0; sStrStart = 0; sStrEnd = 0; sInStr = false; sAfterColon = false; sLastKey = "";
            sLimit = 0; iEnd = 0;   // set by LocateDone
            locating = true; lInScript = false; lPos = 0; lFound = 0; lBrace = -1; lEnd = -1; lTemplates = 0;
            tagSet = new char[] { '=', '>' };
            valueEndSet = new char[] { ' ', '\t', '\n', '\r', '\f', '>' };
            jsSet = new char[] { '"', '\'', '`', '/' };
            dqSet = new char[] { '"', '\\', '\n', '\r' };
            sqSet = new char[] { '\'', '\\', '\n', '\r' };
            btSet = new char[] { '`', '\\', '$' };
            lineSet = new char[] { '\n', '\r' };
            nameEndSet = new char[] { ' ', '\t', '\n', '\r', '\f', '/', '>' };
            fStack = new string[64]; fDepth = 0;
            tOpen = false; tClosed = false; eOpen = false; ePending = false; eKeyBad = false;
            tFound = 0; tIdx = -10; tStart = 0; tEnd = 0; tCommas = 0; tDicts = 0; tArrays = 0; tStrings = 0; tLock = 0;
            tUnknownDict = 0; tContElsewhere = 0; eStart = 0; eEnd = 0; eKeyCount = 0; ePrimary = 0; eFirstKey = "";
            wTok = new DataList(); wPath = new DataList(); wParent = new DataList(); wDepth = new DataList(); wActive = false;
            seen = new DataDictionary();
            tracks = DataList<Track>.New();
            fbUsed = !mixMode; fbOutcome = ""; failReason = ""; scanMaxFrameMs = 0;
            fbLockups = 0; fbAccepted = 0; fbDuplicates = 0; fbRejected = 0; fbUnknownShape = 0; fbContinuation = 0;
            fbPartial = false; fbOverLimit = 0;
            fbNotVideo = 0; fbBadId = 0; fbNoTitle = 0; fbEndpoint = 0; fbBadShape = 0; fbEscapedSurrogate = 0;
            fbStart = Time.realtimeSinceStartupAsDouble; fbFrames = 0;
            beatFrame = Time.frameCount; beatTime = Time.realtimeSinceStartup;
            state = 5;
            SendCustomEventDelayedFrames(nameof(FallbackChunk), 1);
            return true;
        }

        private bool OverBudget() { return (Time.realtimeSinceStartupAsDouble - frameStart) * 1000.0 >= FrameBudgetMs; }

        // One frame of the fallback. A stopped or replaced import does nothing and schedules nothing.
        public void FallbackChunk()
        {
#if UNITY_ANDROID
            // QUEST-05: reject PC-only work before communication or parsing.
            state = 4; body = ""; errorCode = -1; errorText = "android_import_unavailable";
            if (view != null) view.ImportFinished();
            return;
#endif
            if (cancelled || view == null || view.importJob != this || state != 5) return;
            frameStart = Time.realtimeSinceStartupAsDouble;
            beatFrame = Time.frameCount; beatTime = Time.realtimeSinceStartup;
            fbFrames++;
            int r = 0;
            while (failReason.Length == 0)
            {
                if (locating) { if (!LocateRun()) break; continue; }
                if (wActive) { if (!WalkStep()) break; if (OverBudget()) break; continue; }
                if (ePending) { ePending = false; Element(); if (OverBudget()) break; continue; }
                r = ScanRun();
                if (r == 2) { ePending = true; if (OverBudget()) break; continue; }
                break;
            }
            double frameMs = (Time.realtimeSinceStartupAsDouble - frameStart) * 1000.0;
            if (frameMs > scanMaxFrameMs) scanMaxFrameMs = frameMs;
            // Limits (design §3.6), judged on every frame including the one that finishes the reading: the work must be
            // done within MaxFrames frames (a frame count above it fails) and within MaxWallSeconds (elapsed time above
            // it fails). A reading that finishes after a limit is a failure, not a success.
            if (failReason.Length == 0)
            {
                if (fbFrames > MaxFrames) failReason = "frameLimit";
                else if (Time.realtimeSinceStartupAsDouble - fbStart > MaxWallSeconds) failReason = "timeLimit";
            }
            if (failReason.Length > 0) { FallbackFinish(); return; }
            bool more = locating || wActive || ePending || r == 0 || r == 2;
            if (more)
            {
                if (fbFrames >= MaxFrames) { failReason = "frameLimit"; FallbackFinish(); return; }   // a next frame would exceed it
                SendCustomEventDelayedFrames(nameof(FallbackChunk), 1);
                return;
            }
            if (r == -2) failReason = "tooDeep";
            else if (r == -1) failReason = sLimit < iEnd ? "initialDataTooLong" : "pageEnded";   // pageEnded: its script ended first
            FallbackFinish();
        }

        // 1 = ytInitialData closed (and well-formed), 0 = frame budget used or a failure was set (failReason),
        // -1 = the text (or the ytInitialData limit) ended first, -2 = deeper than MaxDepth,
        // 2 = a direct dictionary element of the target array has just closed
        private int ScanRun()
        {
            int n = 0;
            while (true)
            {
                if (sInStr)
                {
                    if (sPos >= sLimit) return -1;
                    int j = body.IndexOfAny(insideSet, sPos, sLimit - sPos);
                    if (j < 0) { sPos = sLimit; return -1; }
                    char sc = body[j];
                    if (sc == '\\')
                    {
                        if (j + 1 >= sLimit) { sPos = sLimit; return -1; }
                        char e = body[j + 1];
                        if (e == 'u')
                        {
                            if (j + 5 >= sLimit) { sPos = sLimit; return -1; }
                            if (!Hex(body[j + 2]) || !Hex(body[j + 3]) || !Hex(body[j + 4]) || !Hex(body[j + 5])) return Syntax("unicodeEscape");
                            sPos = j + 6;
                        }
                        else if (e == '"' || e == '\\' || e == '/' || e == 'b' || e == 'f' || e == 'n' || e == 'r' || e == 't') sPos = j + 2;
                        else return Syntax("escape");
                    }
                    else if (sc == '"')
                    {
                        sInStr = false; sStrEnd = j; sPos = j + 1;
                        if (gKey) gExp[sDepth - 1] = 2;
                        else { if (pidPending && sDepth - 1 == pIdx) MixListId(); AfterValue(); }
                    }
                    else return Syntax("controlCharacter");
                }
                else
                {
                    // the gap before the next structural character: whitespace or one primitive value
                    if (gapEnd < 0)
                    {
                        if (sPos >= sLimit) return -1;
                        int j = body.IndexOfAny(outsideSet, sPos, sLimit - sPos);
                        if (j < 0) { sPos = sLimit; return -1; }
                        gapEnd = j; gPos = sPos; litState = 0;
                    }
                    while (gPos < gapEnd)
                    {
                        if (!GapChar(body[gPos])) return Syntax(litState == 1 ? "number" : litState == 2 ? "literal" : "unexpected");
                        gPos++;
                        n++;
                        if (n >= CheckEvery) { n = 0; if (OverBudget()) return 0; }
                    }
                    if (litState == 1 && !NumberDone()) return Syntax("number");
                    if (litState == 2 && wordIdx != word.Length) return Syntax("literal");
                    if (litState != 0)
                    {
                        if (sDepth == 0 || !ValueExpected(gExp[sDepth - 1])) return Syntax("value");
                        AfterValue();
                    }
                    int g = gapEnd;
                    gapEnd = -1;
                    char c = body[g];
                    sPos = g + 1;
                    int top = sDepth - 1;
                    if (c == '"')
                    {
                        if (top < 0) return Syntax("value");
                        int x = gExp[top];
                        if (x == 0 || x == 1) gKey = true;
                        else if (ValueExpected(x)) gKey = false;
                        else return Syntax("string");
                        sInStr = true; sStrStart = g + 1; sAfterColon = false;
                        if (tOpen && sDepth == tIdx + 1) tStrings++;   // a string directly in the target array
                    }
                    else if (c == ':')
                    {
                        if (top < 0 || gExp[top] != 2) return Syntax("colon");
                        gExp[top] = 3;
                        int kl = sStrEnd - sStrStart;
                        sLastKey = kl > 0 && kl <= 48 ? body.Substring(sStrStart, kl) : "";
                        Key();
                        if (failReason.Length > 0) return 0;   // a refused key (R11-A02) ends the reading here
                        sAfterColon = true;
                    }
                    else if (c == ',')
                    {
                        if (top < 0) return Syntax("comma");
                        if (gExp[top] == 4) gExp[top] = 1;
                        else if (gExp[top] == 7) gExp[top] = 6;
                        else return Syntax("comma");
                        sAfterColon = false;
                        if (tOpen && sDepth == tIdx + 1) tCommas++;
                    }
                    else if (c == '{' || c == '[')
                    {
                        if (top >= 0 && !ValueExpected(gExp[top])) return Syntax("value");
                        if (sDepth >= MaxDepth) return -2;
                        names[sDepth] = sAfterColon ? sLastKey : "";
                        gExp[sDepth] = c == '{' ? 0 : 5;
                        Push(c, g);
                        if (failReason.Length > 0) return 0;
                        sDepth++;
                        sAfterColon = false;
                    }
                    else
                    {
                        if (top < 0) return Syntax("close");
                        int x = gExp[top];
                        if (c == '}' ? !(x == 0 || x == 4) : !(x == 5 || x == 7)) return Syntax("close");
                        bool element = Pop(c, g);
                        sDepth--;
                        sAfterColon = false;
                        if (sDepth > 0) AfterValue();
                        if (element) return 2;
                        if (sDepth <= 0) return AfterRoot() ? 1 : 0;
                    }
                }
                n++;
                if (n >= CheckEvery) { n = 0; if (OverBudget()) return 0; }
            }
        }

        // ---------- JSON grammar helpers (no values are built) ----------

        private int Syntax(string where)
        {
            if (failReason.Length == 0) { failReason = "jsonError"; syntaxAt = where; }
            return 0;
        }

        private bool Hex(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
        private bool ValueExpected(int x) { return x == 3 || x == 5 || x == 6; }

        // the value of the open container (at sDepth - 1) is complete
        private void AfterValue()
        {
            int top = sDepth - 1;
            if (top < 0) return;
            gExp[top] = gExp[top] <= 4 ? 4 : 7;
        }

        // after the closing brace of ytInitialData (R11-A01): only whitespace, at most one ';', and whitespace may follow up
        // to the end of its script element; nothing else may run in that script after the assignment
        private bool AfterRoot()
        {
            int k = sPos;
            while (k < iEnd && Ws(body[k])) k++;
            if (k < iEnd && body[k] == ';') k++;
            while (k < iEnd && Ws(body[k])) k++;
            if (k == iEnd) return true;
            Syntax("afterValue");
            return false;
        }

        private bool Ws(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f'; }

        // ---------- R11-A01: locating the real assignment (several frames, like the scan) ----------
        // HTML: comments and the raw text of style / textarea / title / xmp / iframe / noembed / noframes / noscript are
        // skipped, tags are read with their quoted attribute values, so a marker in an attribute, a comment or page text
        // is never a candidate. Each script element whose text holds the marker is read as JavaScript up to the marker:
        // strings ('…', "…", `…`) and comments (// …, /* … */) are skipped, so a marker inside them is not a candidate.
        // A '/' that starts neither comment (division or regular expression) or a `${` in a template cannot be told apart
        // here: the rest of that script gives no candidate (fail closed). A candidate is "var ytInitialData = " + '{' at
        // the start of its script or right after a ';' of the code. Exactly one candidate in the whole page is accepted;
        // the JSON is then read only inside its script element (AfterRoot).
        // R11-A01-R1: only a script element that would run as a classic script is read (ScriptKind: no src / nomodule, no
        // type or a JavaScript MIME type), and none inside a template element.

        // false = the frame budget is used (continues next frame)
        private bool LocateRun()
        {
            int n = 0;
            while (locating && failReason.Length == 0)
            {
                if (lInScript) ScriptStep(); else HtmlStep();
                n++;
                if (n >= 8) { n = 0; if (OverBudget()) return false; }
            }
            return true;
        }

        private void LocateDone()
        {
            locating = false;
            lInScript = false;
            if (lFound == 0) { failReason = "initialDataMissing"; return; }
            if (lFound > 1) { failReason = "initialDataAmbiguous"; return; }
            sPos = lBrace;
            iEnd = lEnd;
            sLimit = lBrace + MaxInitialDataChars < iEnd ? lBrace + MaxInitialDataChars : iEnd;
        }

        // R11-A01-R1-R2: markup that is not a tag is skipped as the HTML tokenizer does (comments with their abrupt and
        // "--!>" ends; "<!…>", "<?…>" and "</" + a non-letter are bogus comments up to the first '>', so an HTML
        // "<![CDATA[" is one too). SVG / MathML (foreign content) is followed only in a small subset: elements opened and
        // closed by name, comments, and CDATA sections (skipped to "]]>", which exist only there). Anything else there,
        // and any construct the scan cannot follow, goes to Unsupported.
        private void HtmlStep()
        {
            int j = body.IndexOf('<', lPos);
            if (j < 0 || j + 1 >= body.Length) { LocateDone(); return; }
            char c1 = body[j + 1];
            if (c1 == '!')
            {
                if (j + 3 < body.Length && body[j + 2] == '-' && body[j + 3] == '-') { SkipComment(j); return; }
                if (fDepth > 0 && j + 9 <= body.Length && body.Substring(j, 9) == "<![CDATA[")
                {
                    int e = body.IndexOf("]]>", j + 9, System.StringComparison.Ordinal);
                    if (e < 0) { failReason = "cdataNotClosed"; return; }
                    lPos = e + 3;
                    return;
                }
                Bogus(j);
                return;
            }
            if (c1 == '?') { Bogus(j); return; }
            bool end = c1 == '/';
            int ns = end ? j + 2 : j + 1;
            string name = TagName(ns);
            if (name.Length == 0)
            {
                if (!end) { lPos = j + 1; return; }                            // a '<' that starts no tag is text
                if (ns >= body.Length) { lPos = body.Length; return; }         // "</" at the very end is text
                if (body[ns] == '>') { lPos = ns + 1; return; }                // "</>" is ignored
                Bogus(j);                                                      // "</" + a non-letter: a bogus comment
                return;
            }
            int te = TagEnd(ns + name.Length);
            if (te < 0) { Unsupported("tagNotClosed", j); return; }
            lPos = te + 1;
            if (fDepth > 0) { ForeignTag(name, end, ns + name.Length, te, j); return; }
            if (!end && (name == "svg" || name == "math"))
            {
                if (!ParseAttrs(ns + name.Length, te)) { Unsupported("tagMalformed", j); return; }
                if (!aSelfClosing) { fStack[0] = name; fDepth = 1; }   // "<svg/>" holds nothing; "<svg a=x/>" stays open
                return;
            }
            // R11-A01-R1: the content of a template is never run (nested templates are counted; a stray end tag is ignored)
            if (name == "template")
            {
                if (!end) lTemplates++;
                else if (lTemplates > 0) lTemplates--;
                return;
            }
            if (end) return;
            if (name == "plaintext") { LocateDone(); return; }
            bool script = name == "script";
            if (!script && name != "style" && name != "textarea" && name != "title" && name != "xmp" && name != "iframe"
                && name != "noembed" && name != "noframes" && name != "noscript") return;
            int ce = CloseTag(lPos, name);
            if (ce < 0) { Unsupported("elementNotClosed", j); return; }   // never closed: no candidate can be complete
            // "<!--" in script text starts the tokenizer's escaped states, where "</script>" may not end the element
            if (script && body.IndexOf("<!--", lPos, ce - lPos, System.StringComparison.Ordinal) >= 0) { Unsupported("scriptEscape", j); return; }
            if (script && lTemplates == 0 && body.IndexOf("ytInitialData", lPos, ce - lPos, System.StringComparison.Ordinal) >= 0)
            {
                int kind = ScriptKind(ns + name.Length, te);
                if (kind < 0) { failReason = "scriptTagMalformed"; return; }   // ambiguous attributes: the page is refused
                if (kind == 1) { lInScript = true; lCs = lPos; lCe = ce; lLp = lPos; lOcc = -1; }
            }
            lPos = ce;   // the end tag is read as a tag next
        }

        // A construct the scan does not follow at j: the page is refused when the marker occurs at or after it (a candidate
        // there could not be told from a fake); otherwise nothing after j can matter and the search ends here.
        private void Unsupported(string what, int j)
        {
            if (body.IndexOf("ytInitialData", j, System.StringComparison.Ordinal) >= 0) failReason = what;
            else LocateDone();
        }

        // "<!--" at j: ends at "-->" or "--!>"; "<!-->" and "<!--->" are empty comments
        private void SkipComment(int j)
        {
            int s = j + 4;
            if (s < body.Length && body[s] == '>') { lPos = s + 1; return; }
            if (s + 1 < body.Length && body[s] == '-' && body[s + 1] == '>') { lPos = s + 2; return; }
            int e1 = body.IndexOf("-->", s, System.StringComparison.Ordinal), e2 = body.IndexOf("--!>", s, System.StringComparison.Ordinal);
            if (e1 < 0 && e2 < 0) { Unsupported("commentNotClosed", j); return; }
            lPos = e2 >= 0 && (e1 < 0 || e2 < e1) ? e2 + 4 : e1 + 3;
        }

        // a bogus comment from j to the first '>'
        private void Bogus(int j)
        {
            int e = body.IndexOf('>', j + 2);
            if (e < 0) { Unsupported("markupNotClosed", j); return; }
            lPos = e + 1;
        }

        // a tag inside SVG / MathML: the supported subset opens and closes foreign elements by name
        private void ForeignTag(string name, bool end, int p, int te, int j)
        {
            if (end)
            {
                int k = fDepth - 1;
                while (k >= 0 && fStack[k] != name) k--;
                if (k < 0) { Unsupported("foreignContent", j); return; }   // nothing of that name is open here
                fDepth = k;   // closes it and everything inside it
                return;
            }
            if (ForeignUnsupported(name)) { Unsupported("foreignContent", j); return; }
            if (!ParseAttrs(p, te)) { Unsupported("tagMalformed", j); return; }
            if (aSelfClosing) return;
            if (fDepth >= fStack.Length) { Unsupported("foreignContent", j); return; }
            fStack[fDepth] = name;
            fDepth++;
        }

        // start tags in SVG / MathML outside the subset: a script (it runs), the HTML integration points (HTML is parsed
        // inside them), and the HTML tags that leave foreign content
        private bool ForeignUnsupported(string name)
        {
            string[] list = { "script", "foreignobject", "desc", "title", "mi", "mo", "mn", "ms", "mtext", "annotation-xml",
                "b", "big", "blockquote", "body", "br", "center", "code", "dd", "div", "dl", "dt", "em", "embed", "font",
                "h1", "h2", "h3", "h4", "h5", "h6", "head", "hr", "i", "img", "li", "listing", "menu", "meta", "nobr", "ol",
                "p", "pre", "ruby", "s", "small", "span", "strong", "strike", "sub", "sup", "table", "tt", "u", "ul", "var" };
            for (int i = 0; i < list.Length; i++) if (name == list[i]) return true;
            return false;
        }

        // R11-A01-R1: how a script element holding the marker would be run, from the attributes between p and its '>' (te).
        // 1 = a classic script (no type, an empty type or a JavaScript MIME type, after ASCII whitespace is trimmed and
        //     ASCII letters are lowered; with no type attribute, language="x" means "text/x"), without src and nomodule.
        // 0 = not run as a classic script (JSON, template, module, src, nomodule, any other or unknown type).
        // -1 = malformed or ambiguous: a quote, '<' or '=' where a name or an unquoted value is read, no whitespace after a
        //      quoted value, '=' without a value, type or language given twice, or '&' (a character reference, not decoded
        //      here) in type or language (ParseAttrs).
        private int ScriptKind(int p, int te)
        {
            if (!ParseAttrs(p, te)) return -1;
            if (aSrc || aNomodule) return 0;
            string t = aType != null ? aType : (aLang != null && aLang.Length > 0 ? "text/" + aLang : "");
            t = AsciiTrim(t);
            if (t.Length == 0) return 1;
            for (int i = 0; i < t.Length; i++) if ((int)t[i] > 127) return 0;   // only ASCII is compared
            return IsJavaScriptMime(t.ToLower()) ? 1 : 0;
        }

        // The attributes of a start tag between p and its '>' at te, read as the tokenizer reads them. Sets aType / aLang
        // (null = absent), aSrc, aNomodule and aSelfClosing (R11-R2-01: a '/' outside every attribute value right before
        // '>'; a '/' inside a quoted or unquoted value, as in <svg a=x/>, is part of that value). False = malformed or
        // ambiguous (see ScriptKind).
        private bool ParseAttrs(int p, int te)
        {
            aType = null; aLang = null; aSrc = false; aNomodule = false; aSelfClosing = false;
            int k = p;
            while (true)
            {
                while (k < te && (Ws(body[k]) || body[k] == '/'))
                {
                    if (body[k] == '/' && k + 1 == te) aSelfClosing = true;
                    k++;
                }
                if (k >= te) break;
                int n0 = k;
                while (k < te && !Ws(body[k]) && body[k] != '/' && body[k] != '=')
                {
                    char c = body[k];
                    if (c == '"' || c == '\'' || c == '<') return false;
                    k++;
                }
                if (k == n0) return false;   // '=' where a name starts
                string an = body.Substring(n0, k - n0).ToLower();
                int k2 = k;
                while (k2 < te && Ws(body[k2])) k2++;
                string val = "";
                if (k2 < te && body[k2] == '=')
                {
                    k = k2 + 1;
                    while (k < te && Ws(body[k])) k++;
                    if (k >= te) return false;
                    char q = body[k];
                    if (q == '"' || q == '\'')
                    {
                        int e = body.IndexOf(q, k + 1);
                        if (e < 0 || e > te) return false;
                        val = body.Substring(k + 1, e - k - 1);
                        k = e + 1;
                        if (k < te && !Ws(body[k]) && body[k] != '/') return false;
                    }
                    else
                    {
                        int s0 = k;
                        while (k < te && !Ws(body[k]))
                        {
                            char c = body[k];
                            if (c == '"' || c == '\'' || c == '<' || c == '=' || c == '`') return false;
                            k++;
                        }
                        val = body.Substring(s0, k - s0);
                    }
                }
                else k = k2;
                if (an == "type") { if (aType != null || val.IndexOf('&') >= 0) return false; aType = val; }
                else if (an == "language") { if (aLang != null || val.IndexOf('&') >= 0) return false; aLang = val; }
                else if (an == "src") aSrc = true;
                else if (an == "nomodule") aNomodule = true;
            }
            return true;
        }

        private string AsciiTrim(string s)
        {
            int a = 0, b = s.Length;
            while (a < b && Ws(s[a])) a++;
            while (b > a && Ws(s[b - 1])) b--;
            return s.Substring(a, b - a);
        }

        // the JavaScript MIME type essences of the HTML standard (exact, no parameters)
        private bool IsJavaScriptMime(string t)
        {
            string[] js = { "application/ecmascript", "application/javascript", "application/x-ecmascript", "application/x-javascript",
                "text/ecmascript", "text/javascript", "text/javascript1.0", "text/javascript1.1", "text/javascript1.2", "text/javascript1.3",
                "text/javascript1.4", "text/javascript1.5", "text/jscript", "text/livescript", "text/x-ecmascript", "text/x-javascript" };
            for (int i = 0; i < js.Length; i++) if (t == js[i]) return true;
            return false;
        }

        // a tag name as the tokenizer reads it: an ASCII letter, then every character up to whitespace, '/' or '>' (lower
        // case; "a\"b" is a name too). "" = no tag (no letter at p, or the text ends inside the name)
        private string TagName(int p)
        {
            if (p >= body.Length) return "";
            char c = body[p];
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return "";
            int k = body.IndexOfAny(nameEndSet, p);
            if (k < 0) return "";
            return body.Substring(p, k - p).ToLower();
        }

        // the '>' that ends a tag, reading attribute values ("…", '…' or unquoted) after '='; -1 = never ended
        private int TagEnd(int p)
        {
            int k = p;
            while (true)
            {
                int m = body.IndexOfAny(tagSet, k);
                if (m < 0) return -1;
                if (body[m] == '>') return m;
                k = m + 1;
                while (k < body.Length && Ws(body[k])) k++;
                if (k >= body.Length) return -1;
                char q = body[k];
                if (q == '"' || q == '\'')
                {
                    int e = body.IndexOf(q, k + 1);
                    if (e < 0) return -1;
                    k = e + 1;
                }
                else
                {
                    int e = body.IndexOfAny(valueEndSet, k);
                    if (e < 0) return -1;
                    k = e;
                }
            }
        }

        // the start of "</name" (any case, then whitespace, '/' or '>') at or after p; -1 = none
        private int CloseTag(int p, string name)
        {
            int k = p;
            while (true)
            {
                int m = body.IndexOf("</", k, System.StringComparison.Ordinal);
                if (m < 0) return -1;
                int e = m + 2 + name.Length;
                if (e < body.Length && body.Substring(m + 2, name.Length).ToLower() == name && (Ws(body[e]) || body[e] == '/' || body[e] == '>')) return m;
                k = m + 2;
            }
        }

        // one step through the script text lCs..lCe: the next marker (lOcc) and the strings / comments before it
        private void ScriptStep()
        {
            if (lOcc < lLp) lOcc = lLp < lCe ? body.IndexOf("ytInitialData", lLp, lCe - lLp, System.StringComparison.Ordinal) : -1;
            if (lOcc < 0) { EndScript(); return; }
            int m = body.IndexOfAny(jsSet, lLp, lOcc - lLp);
            if (m < 0)
            {
                // the marker is code: is it the start of the assignment?
                if (Candidate(lOcc)) { EndScript(); return; }   // the JSON and the end of this script are checked by the scan
                lLp = lOcc + 13;
                return;
            }
            int after = JsToken(m);
            if (after < 0) { EndScript(); return; }   // cannot be read here: no candidate from the rest of this script
            lLp = after;
        }

        private void EndScript()
        {
            lInScript = false;
            lPos = lCe;
        }

        // "var " before the marker (all code), at the start of the script or after a ';' of the code, and " = " then
        // (after whitespace) '{' after it
        private bool Candidate(int occ)
        {
            int v = occ - 4;
            if (v < lLp || body.Substring(v, 4) != "var ") return false;
            int k = v - 1;
            while (k >= lCs && Ws(body[k])) k--;
            if (k >= lCs && !(k >= lLp && body[k] == ';')) return false;
            int a = occ + 13;
            if (a + 3 > lCe || body.Substring(a, 3) != " = ") return false;
            int b = a + 3;
            while (b < lCe && Ws(body[b])) b++;
            if (b >= lCe || body[b] != '{') return false;
            lFound++;
            lBrace = b;
            lEnd = lCe;
            return true;
        }

        // the end of the string or comment starting at m (exclusive); -1 = not readable here
        private int JsToken(int m)
        {
            char c = body[m];
            if (c == '"' || c == '\'')
            {
                int k = m + 1;
                while (k < lCe)
                {
                    int e = body.IndexOfAny(c == '"' ? dqSet : sqSet, k, lCe - k);
                    if (e < 0) return -1;
                    char x = body[e];
                    if (x == '\\') { k = e + 2; continue; }
                    if (x == c) return e + 1;
                    return -1;   // a line break ends no string
                }
                return -1;
            }
            if (c == '`')
            {
                int k = m + 1;
                while (k < lCe)
                {
                    int e = body.IndexOfAny(btSet, k, lCe - k);
                    if (e < 0) return -1;
                    char x = body[e];
                    if (x == '\\') { k = e + 2; continue; }
                    if (x == '`') return e + 1;
                    if (e + 1 < lCe && body[e + 1] == '{') return -1;   // ${ … }: not read here
                    k = e + 1;
                }
                return -1;
            }
            // '/'
            if (m + 1 >= lCe) return -1;
            char d = body[m + 1];
            if (d == '/')
            {
                int e = body.IndexOfAny(lineSet, m + 2, lCe - (m + 2));
                return e < 0 ? lCe : e;
            }
            if (d == '*')
            {
                int e = body.IndexOf("*/", m + 2, lCe - (m + 2), System.StringComparison.Ordinal);
                return e < 0 ? -1 : e + 2;
            }
            return -1;   // division or a regular expression
        }

        // one character of a gap. litState: 0 only whitespace so far, 1 in a number, 2 in true/false/null, 3 after one
        private bool GapChar(char c)
        {
            bool ws = c == ' ' || c == '\t' || c == '\n' || c == '\r';
            if (ws)
            {
                if (litState == 1) { if (!NumberDone()) return false; litState = 3; }
                else if (litState == 2) { if (wordIdx != word.Length) return false; litState = 3; }
                return true;
            }
            if (litState == 3) return false;
            if (litState == 0)
            {
                if (c == '-' || (c >= '0' && c <= '9')) { litState = 1; numState = 0; return NumberChar(c); }
                if (c == 't') word = "true"; else if (c == 'f') word = "false"; else if (c == 'n') word = "null"; else return false;
                litState = 2; wordIdx = 1;
                return true;
            }
            if (litState == 1) return NumberChar(c);
            if (wordIdx >= word.Length || word[wordIdx] != c) return false;
            wordIdx++;
            return true;
        }

        // RFC 8259 number: -? (0 | [1-9][0-9]*) (. [0-9]+)? ([eE] [+-]? [0-9]+)?
        // numState: 0 start, 1 after '-', 2 after a leading 0, 3 integer digits, 4 after '.', 5 fraction digits,
        // 6 after e/E, 7 after the exponent sign, 8 exponent digits
        private bool NumberChar(char c)
        {
            bool d = c >= '0' && c <= '9';
            int s = numState;
            if (s == 0) { if (c == '-') { numState = 1; return true; } if (c == '0') { numState = 2; return true; } if (d) { numState = 3; return true; } return false; }
            if (s == 1) { if (c == '0') { numState = 2; return true; } if (d) { numState = 3; return true; } return false; }
            if (s == 2 || s == 3)
            {
                if (s == 3 && d) return true;
                if (c == '.') { numState = 4; return true; }
                if (c == 'e' || c == 'E') { numState = 6; return true; }
                return false;   // a digit after a leading 0 is not allowed
            }
            if (s == 4) { if (d) { numState = 5; return true; } return false; }
            if (s == 5) { if (d) return true; if (c == 'e' || c == 'E') { numState = 6; return true; } return false; }
            if (s == 6) { if (c == '+' || c == '-') { numState = 7; return true; } if (d) { numState = 8; return true; } return false; }
            if (s == 7) { if (d) { numState = 8; return true; } return false; }
            return d;   // 8: exponent digits
        }

        private bool NumberDone() { return numState == 2 || numState == 3 || numState == 5 || numState == 8; }

        private bool IsTargetPath(int top)
        {
            int k = targetPath.Length - 1;
            for (int d = top; d >= 0; d--)
            {
                string nm = names[d];
                if (nm == null || nm.Length == 0) continue;
                if (k < 0 || nm != targetPath[k]) return false;
                k--;
            }
            return k < 0;
        }

        // Mix: the container at `top` is reached from the root by exactly these keys (no array, no other key between)
        private bool IsExactPath(int top, string[] path)
        {
            if (top != path.Length) return false;
            for (int d = 1; d <= top; d++) if (names[d] != path[d - 1]) return false;
            return true;
        }

        // a container opens at depth sDepth (its key name is already in names[sDepth])
        private void Push(char c, int j)
        {
            int i = sDepth;
            if (mixMode) { MixPush(c, j, i); return; }
            // primary endpoint: element (tIdx+1) > lockupViewModel (+2) > rendererContext > commandContext > onTap >
            // innertubeCommand > watchEndpoint (+7), each opened by its key, no array in between (design §3.4 (b) 2)
            if (eOpen && c == '{' && i == tIdx + 7 && names[tIdx + 2] == "lockupViewModel" && names[tIdx + 3] == "rendererContext"
                && names[tIdx + 4] == "commandContext" && names[tIdx + 5] == "onTap" && names[tIdx + 6] == "innertubeCommand"
                && names[tIdx + 7] == "watchEndpoint") ePrimary++;
            if (tOpen && i == tIdx + 1)
            {
                if (tDicts + tArrays + tStrings + 1 > MaxCandidates) { failReason = "tooMany"; return; }
                if (c == '{') { eOpen = true; eStart = j; eKeyCount = 0; eFirstKey = ""; eKeyBad = false; ePrimary = 0; tDicts++; }
                else tArrays++;
                return;
            }
            if (c == '[' && names[i] == "contents" && IsTargetPath(i))
            {
                tFound++;
                if (tFound == 1) { tOpen = true; tIdx = i; tStart = j; }
                else failReason = "targetConflict";
            }
        }

        // a key was read (sLastKey, "" when longer than 48 characters); the dictionary holding it is at depth sDepth - 1
        private void Key()
        {
            if (mixMode) { MixKey(); return; }
            if (eOpen && sDepth == tIdx + 2)
            {
                eKeyCount++;
                if (sLastKey.Length == 0) eKeyBad = true;
                if (eKeyCount == 1) eFirstKey = sLastKey;
                return;
            }
            if (sLastKey == "continuationItemRenderer") tContElsewhere++;
        }

        // a container at depth sDepth - 1 closes; true = a direct dictionary element of the target array closed
        private bool Pop(char c, int j)
        {
            // Mix: the list object closes; a playlistId that was not followed by a string value is bad
            if (pOpen && sDepth - 1 == pIdx) { if (pidPending) { pidBad = true; pidPending = false; } pOpen = false; }
            if (!tOpen) return false;
            int ci = sDepth - 1;
            if (ci == tIdx + 1 && eOpen && c == '}') { eOpen = false; eEnd = j; return true; }
            if (ci == tIdx) { tOpen = false; tClosed = true; tEnd = j; }
            return false;
        }

        // one direct dictionary element of the target array (eStart..eEnd), classified by its top-level keys
        private void Element()
        {
            if (mixMode) { MixElement(); return; }
            if (eKeyCount == 1 && !eKeyBad && eFirstKey == "continuationItemRenderer") { fbContinuation++; return; }
            if (eKeyCount != 1 || eKeyBad || eFirstKey != (fbFormA ? "playlistVideoRenderer" : "lockupViewModel")) { tUnknownDict++; return; }
            tLock++;
            int len = eEnd + 1 - eStart;
            if (len > MaxElementChars) { failReason = "elementTooLong"; return; }   // checked before any JSON reading
            string part = body.Substring(eStart, len);
            // VRCJson turns an escaped surrogate (🎵) into the text "\uudfb5": such a lockup is refused
            // before reading, so broken text is never saved (design §3.3.1)
            if (HasEscapedSurrogate(part)) { fbEscapedSurrogate++; Reject(6); return; }
            DataToken tok;
            if (!VRCJson.TryDeserializeFromJson(part, out tok)) { failReason = "jsonError"; return; }
            if (tok.TokenType != TokenType.DataDictionary) { Reject(6); return; }
            DataToken lv;
            if (fbFormA)
            {
                if (!tok.DataDictionary.TryGetValue("playlistVideoRenderer", TokenType.DataDictionary, out lv)) { Reject(6); return; }
                VideoRendererElement(lv);
                return;
            }
            if (!tok.DataDictionary.TryGetValue("lockupViewModel", TokenType.DataDictionary, out lv)) { Reject(6); return; }
            LockupBegin(lv);
        }

        // IMPORT-B2, form A: one playlistVideoRenderer (a dictionary, checked by the caller). Every value is read with a
        // typed TryGetValue (no index on a value whose kind is not known). The video ID and the requested list must be
        // the ones of its watch endpoint; the title is title>runs>[0]>text, or title>simpleText.
        private void VideoRendererElement(DataToken vr)
        {
            DataDictionary d = vr.DataDictionary;
            DataToken vid, t, runs, run0, text, ne, we, wv, wp;
            if (!d.TryGetValue("videoId", TokenType.String, out vid) || !IdFormat(vid.String)) { Reject(2); return; }
            string videoId = vid.String;
            string title = "";
            if (d.TryGetValue("title", TokenType.DataDictionary, out t))
            {
                DataDictionary td = t.DataDictionary;
                if (td.TryGetValue("runs", TokenType.DataList, out runs))
                {
                    DataList rl = runs.DataList;
                    if (rl.Count > 0 && rl.TryGetValue(0, TokenType.DataDictionary, out run0)
                        && run0.DataDictionary.TryGetValue("text", TokenType.String, out text)) title = text.String;
                }
                else if (td.TryGetValue("simpleText", TokenType.String, out text)) title = text.String;
            }
            if (title.Trim().Length == 0 || !WellFormedText(title)) { Reject(3); return; }
            title = CapTitle(title);
            if (!WellFormedText(title)) { Reject(3); return; }
            if (!d.TryGetValue("navigationEndpoint", TokenType.DataDictionary, out ne)) { Reject(4); return; }
            if (!ne.DataDictionary.TryGetValue("watchEndpoint", TokenType.DataDictionary, out we)) { Reject(4); return; }
            DataDictionary wd = we.DataDictionary;
            if (!wd.TryGetValue("videoId", TokenType.String, out wv) || !wd.TryGetValue("playlistId", TokenType.String, out wp)) { Reject(4); return; }
            if (wv.String != videoId || wp.String != requestedList) { Reject(4); return; }
            wVideoId = videoId;
            wTitle = title;
            AcceptTrack();
        }

        // design §3.5: the checks that need no walk; then the walk over the other ID dictionaries
        private void LockupBegin(DataToken lv)
        {
            DataDictionary d = lv.DataDictionary;
            DataToken cid, ct, a, b, c, t;
            string contentId = d.TryGetValue("contentId", TokenType.String, out cid) ? cid.String : "";
            wTitle = d.TryGetValue("metadata", TokenType.DataDictionary, out a)
                && a.DataDictionary.TryGetValue("lockupMetadataViewModel", TokenType.DataDictionary, out b)
                && b.DataDictionary.TryGetValue("title", TokenType.DataDictionary, out c)
                && c.DataDictionary.TryGetValue("content", TokenType.String, out t) ? t.String : "";
            if (!d.ContainsKey("contentType") || !d.ContainsKey("contentId")) { Reject(6); return; }
            if (!d.TryGetValue("contentType", TokenType.String, out ct) || ct.String != "LOCKUP_CONTENT_TYPE_VIDEO") { Reject(1); return; }
            if (!IdFormat(contentId)) { Reject(2); return; }
            if (wTitle.Trim().Length == 0 || !WellFormedText(wTitle)) { Reject(3); return; }
            // the Store keeps MaxTitleLength UTF-16 code units; cut here so that a surrogate pair is never split there
            wTitle = CapTitle(wTitle);
            if (!WellFormedText(wTitle)) { Reject(3); return; }
            // primary endpoint: exactly one by the scan, readable by its keys, both IDs strings and equal
            if (ePrimary != 1) { Reject(4); return; }
            DataToken cur = lv;
            DataToken next;
            if (!cur.DataDictionary.TryGetValue("rendererContext", TokenType.DataDictionary, out next)) { Reject(4); return; }
            cur = next;
            if (!cur.DataDictionary.TryGetValue("commandContext", TokenType.DataDictionary, out next)) { Reject(4); return; }
            cur = next;
            if (!cur.DataDictionary.TryGetValue("onTap", TokenType.DataDictionary, out next)) { Reject(4); return; }
            cur = next;
            if (!cur.DataDictionary.TryGetValue("innertubeCommand", TokenType.DataDictionary, out next)) { Reject(4); return; }
            cur = next;
            if (!cur.DataDictionary.TryGetValue("watchEndpoint", TokenType.DataDictionary, out next)) { Reject(4); return; }
            DataToken v, p;
            if (!next.DataDictionary.TryGetValue("videoId", TokenType.String, out v)
                || !next.DataDictionary.TryGetValue("playlistId", TokenType.String, out p)) { Reject(4); return; }
            if (v.String != contentId || p.String != requestedList) { Reject(4); return; }
            wVideoId = contentId;
            wTok.Clear(); wPath.Clear(); wParent.Clear(); wDepth.Clear();
            wNodes = 0; wUnknown = 0; wBad = false;
            WalkPush(lv, "", "lockupViewModel", 0);
            wActive = true;
        }

        private void WalkPush(DataToken t, string path, string parent, int depth)
        {
            wTok.Add(t); wPath.Add(new DataToken(path)); wParent.Add(new DataToken(parent)); wDepth.Add(new DataToken(depth));
        }

        // false = the frame budget is used (the walk continues next frame)
        private bool WalkStep()
        {
            int n = 0;
            while (wTok.Count > 0)
            {
                int last = wTok.Count - 1;
                DataToken t = wTok[last];
                string path = wPath[last].String;
                string parent = wParent[last].String;
                int depth = wDepth[last].Int;
                wTok.RemoveAt(last); wPath.RemoveAt(last); wParent.RemoveAt(last); wDepth.RemoveAt(last);
                wNodes++;
                if (wNodes > MaxNodesPerElement || depth > MaxWalkDepth)
                {
                    wBad = true;
                    wTok.Clear(); wPath.Clear(); wParent.Clear(); wDepth.Clear();
                    break;
                }
                if (t.TokenType == TokenType.DataDictionary)
                {
                    DataDictionary d = t.DataDictionary;
                    if (d.ContainsKey("videoId") || d.ContainsKey("playlistId")) IdDictionary(path, parent);
                    DataList keys = d.GetKeys();
                    for (int i = 0; i < keys.Count; i++)
                    {
                        DataToken kt = keys[i];
                        if (kt.TokenType != TokenType.String) continue;
                        DataToken child;
                        if (!d.TryGetValue(kt, out child)) continue;
                        if (child.TokenType != TokenType.DataDictionary && child.TokenType != TokenType.DataList) continue;
                        string k = kt.String;
                        WalkPush(child, path + ">" + (SchemaName(k) ? k : "<other>"), k, depth + 1);
                    }
                }
                else if (t.TokenType == TokenType.DataList)
                {
                    DataList l = t.DataList;
                    for (int i = 0; i < l.Count; i++)
                    {
                        DataToken child = l[i];
                        if (child.TokenType == TokenType.DataDictionary || child.TokenType == TokenType.DataList)
                            WalkPush(child, path + ">[]", "[]", depth + 1);
                    }
                }
                n++;
                if (n >= 16) { n = 0; if (OverBudget()) return false; }
            }
            WalkFinish();
            return true;
        }

        // design §3.4 (b) 4: the primary endpoint itself, an auxiliary action (T, M1, M2), or unknown
        private void IdDictionary(string path, string parent)
        {
            if (path == PrimaryPath) return;
            if (path.StartsWith(AuxThumbPrefix)
                && (parent == "addToPlaylistCommand" || parent == "playlistEditEndpoint" || parent == "watchEndpoint")) return;
            if (path.StartsWith(AuxMenuPrefix))
            {
                if (parent == "addToPlaylistCommand" && path.EndsWith(AuxM1Suffix)) return;
                if (parent == "watchEndpoint" && path.EndsWith(AuxM2Suffix)) return;
            }
            wUnknown++;
        }

        private void WalkFinish()
        {
            wActive = false;
            if (wBad) { Reject(6); return; }
            if (wUnknown > 0) { Reject(5); return; }
            AcceptTrack();
        }

        // A checked track (wVideoId, wTitle): a repeat is kept once; IMPORT-B2: beyond MaxImportTracks kept tracks it is
        // counted (fbOverLimit) and not kept, so one import keeps the first MaxImportTracks tracks of the list.
        private void AcceptTrack()
        {
            if (seen.ContainsKey(wVideoId)) { fbDuplicates++; wVideoId = ""; wTitle = ""; return; }
            seen.SetValue(wVideoId, true);
            if (fbAccepted >= MaxImportTracks) { fbOverLimit++; wVideoId = ""; wTitle = ""; return; }
            tracks.Add(Track.New(VideoPlayerType.AVProVideoPlayer, wTitle, VRCUrl.Empty, "https://www.youtube.com/watch?v=" + wVideoId));
            fbAccepted++;
            wVideoId = ""; wTitle = "";
        }

        // B reasons: 1 not a video, 2 bad ID, 3 no title, 4 primary endpoint (missing, duplicate, field, ID or list
        // mismatch), 5 an unknown ID dictionary (endpointUnknown), 6 unexpected shape
        private void Reject(int reason)
        {
            fbRejected++;
            if (reason == 1) fbNotVideo++;
            else if (reason == 2) fbBadId++;
            else if (reason == 3) fbNoTitle++;
            else if (reason == 4 || reason == 5) fbEndpoint++;
            else fbBadShape++;
            wVideoId = ""; wTitle = "";
        }

        // design §4: all or nothing
        private void FallbackFinish()
        {
            if (mixMode) { MixFinish(); return; }
            // direct elements: dictionaries are classified one by one; arrays, strings and the rest (numbers,
            // true/false/null, counted as commas + 1 minus the others) are unknown shapes
            bool nonEmpty = tDicts + tArrays + tStrings > 0 || tCommas > 0;
            if (!nonEmpty && tClosed && tEnd > tStart + 1) nonEmpty = body.Substring(tStart + 1, tEnd - tStart - 1).Trim().Length > 0;
            int total = nonEmpty ? tCommas + 1 : 0;
            int primitives = total - tDicts - tArrays - tStrings;
            fbUnknownShape = tUnknownDict + tArrays + tStrings + (primitives > 0 ? primitives : 0);
            fbLockups = tLock;
            if (failReason.Length == 0)
            {
                if (tFound == 0) failReason = "targetMissing";
                else if (!tClosed) failReason = "targetNotClosed";
                else if (total > MaxCandidates) failReason = "tooMany";
                else if (primitives < 0 || tDicts != tLock + fbContinuation + tUnknownDict
                    || total != tLock + fbContinuation + fbUnknownShape || tLock != fbAccepted + fbDuplicates + fbRejected + fbOverLimit)
                    failReason = "countMismatch";
            }
            if (failReason.Length > 0) fbOutcome = "failed:" + failReason;
            else if (fbRejected > 0 || fbUnknownShape > 0) fbOutcome = "rejected";
            else if (fbAccepted == 0) fbOutcome = "failed:empty";
            else fbOutcome = "saved";
            // IMPORT-B2: the list goes on after what was read (a continuation item in the list) or had more checked
            // tracks than one import keeps: the tracks read are saved, the rest is not imported. A continuation item
            // elsewhere on the page is only counted (form A pages carry one outside the list also for short lists; it
            // cannot be tied to this list), so it never makes an import partial (B2-02).
            fbPartial = fbOutcome == "saved" && (fbContinuation > 0 || fbOverLimit > 0);
            fbContinuation += tContElsewhere;
            if (fbOutcome != "saved") tracks = DataList<Track>.New();
            // drop the scan state (IDs were held in memory only)
            seen = null; names = null; gExp = null; wTok = null; wPath = null; wParent = null; wDepth = null;
            state = fbOutcome == "saved" ? 3 : 4;
            errorCode = 0;
            Debug.Log("[DM MyList] import PERSISTENT fallback: outcome " + fbOutcome + (syntaxAt.Length > 0 ? " (JSON grammar: " + syntaxAt + ")" : "") + ", form " + (fbFormA ? "A" : "B")
                + ", partial " + fbPartial + ", overLimit " + fbOverLimit + ", elements " + total + " (" + (fbFormA ? "video " : "lockup ") + tLock
                + ", continuation " + (fbContinuation - tContElsewhere) + ", unknownShape " + fbUnknownShape + "), accepted " + fbAccepted
                + ", rejected " + fbRejected + " {notVideo " + fbNotVideo + ", badId " + fbBadId + ", noTitle " + fbNoTitle
                + ", endpoint " + fbEndpoint + ", badShape " + fbBadShape + " (escapedSurrogate " + fbEscapedSurrogate + ")}, duplicate " + fbDuplicates
                + ", continuationElsewhere " + tContElsewhere + ", frames " + fbFrames + ", maxFrameMs " + scanMaxFrameMs.ToString("F1")
                + ", wallMs " + (int)((Time.realtimeSinceStartupAsDouble - fbStart) * 1000.0));
            if (view != null) view.ImportFinished();
        }

        // ---------- YouTube Mix (revision 11) ----------

        // a container opens at depth i in Mix mode: the list object, the list (its 'contents' array) and its items
        private void MixPush(char c, int j, int i)
        {
            if (tOpen && i == tIdx + 1)
            {
                if (tDicts + tArrays + tStrings + 1 > MaxMixItems) { failReason = "tooMany"; return; }
                if (c == '{') { eOpen = true; eStart = j; eKeyCount = 0; eFirstKey = ""; eKeyBad = false; tDicts++; }
                else tArrays++;
                return;
            }
            if (pidPending && i == pIdx + 1) { pidBad = true; pidPending = false; }   // the list's playlistId is not a string
            if (c == '{' && i == 3 && IsPathPrefix(3)) outerFound++;
            if (c == '{' && names[i] == "playlist" && IsExactPath(i, mixObjectPath))
            {
                pFound++;
                if (pFound == 1) { pOpen = true; pIdx = i; }
                else if (failReason.Length == 0) failReason = "listConflict";
            }
            else if (c == '[' && names[i] == "contents" && IsExactPath(i, targetPath))
            {
                tFound++;
                if (tFound == 1) { tOpen = true; tIdx = i; tStart = j; }
                else if (failReason.Length == 0) failReason = "targetConflict";
            }
        }

        // a key was read in Mix mode (sLastKey); the dictionary holding it is at depth sDepth - 1
        private void MixKey()
        {
            if (sLastKey == "playlistPanelVideoRenderer") mixPagePanels++;   // anywhere on the page (log only)
            if (eOpen && sDepth == tIdx + 2)
            {
                eKeyCount++;
                if (sLastKey.Length == 0) eKeyBad = true;
                if (eKeyCount == 1) eFirstKey = sLastKey;
                return;
            }
            // R11-A02: a key of a dictionary on the way to the list (the root, contents, twoColumnWatchNextResults,
            // playlist, playlist). Counted whatever its value is: a JSON reader keeps the last of two equal keys, so a
            // second one (a null, another object, …) would replace what is read here. An escaped key name cannot be
            // compared with these names and is refused in these dictionaries. Equal names elsewhere are not counted.
            int h = sDepth - 1;
            if (h <= 4 && IsPathPrefix(h))
            {
                if (body.IndexOf('\\', sStrStart, sStrEnd - sStrStart) >= 0) { failReason = "escapedKey"; return; }
                string want = h < 4 ? mixObjectPath[h] : "contents";
                if (sLastKey == want)
                {
                    pathKeys[h] = pathKeys[h] + 1;
                    if (pathKeys[h] > 1) { failReason = "duplicateKey"; return; }
                }
            }
            if (!pOpen || h != pIdx) return;
            if (pidPending) { pidBad = true; pidPending = false; }   // the previous playlistId had no string value
            if (sLastKey == "playlistId")
            {
                pidKeys++;
                if (pidKeys > 1) { failReason = "duplicateKey"; return; }
                pidPending = true;
            }
            else if (sLastKey == "isInfinite") mixInfinite = LiteralTrue(sPos);
        }

        // the container at depth h is reached from the root by the first h keys of the way to the list (no array between)
        private bool IsPathPrefix(int h)
        {
            for (int d = 1; d <= h; d++) if (names[d] != mixObjectPath[d - 1]) return false;
            return true;
        }

        // the string value that follows the list object's playlistId key (raw JSON text: an escape never matches)
        private void MixListId()
        {
            pidPending = false;
            int len = sStrEnd - sStrStart;
            if (len < 1 || len > MaxMixIdChars) { pidBad = true; return; }
            pidValue = body.Substring(sStrStart, len);
        }

        private bool LiteralTrue(int k)
        {
            while (k < sLimit && (body[k] == ' ' || body[k] == '\t' || body[k] == '\n' || body[k] == '\r')) k++;
            return k + 4 <= sLimit && body.Substring(k, 4) == "true";
        }

        // one direct dictionary element of the Mix list: exactly {"playlistPanelVideoRenderer": {...}} with a video ID,
        // a plain title and a watch endpoint naming the same video and the requested Mix. Kept in memory only; nothing
        // is used unless every element passes (MixFinish).
        private void MixElement()
        {
            if (eKeyCount != 1 || eKeyBad || eFirstKey != "playlistPanelVideoRenderer") { tUnknownDict++; return; }
            tLock++;
            int len = eEnd + 1 - eStart;
            if (len > MaxElementChars) { failReason = "elementTooLong"; return; }   // checked before any JSON reading
            string part = body.Substring(eStart, len);
            if (HasEscapedSurrogate(part)) { fbEscapedSurrogate++; Reject(6); return; }
            DataToken tok;
            if (!VRCJson.TryDeserializeFromJson(part, out tok)) { failReason = "jsonError"; return; }
            DataToken pr;
            if (tok.TokenType != TokenType.DataDictionary || !tok.DataDictionary.TryGetValue("playlistPanelVideoRenderer", TokenType.DataDictionary, out pr))
            {
                Reject(6);
                return;
            }
            DataDictionary d = pr.DataDictionary;
            DataToken v, t, st, ne, we, wv, wp;
            if (!d.TryGetValue("videoId", TokenType.String, out v) || !IdFormat(v.String)) { Reject(2); return; }
            string title = d.TryGetValue("title", TokenType.DataDictionary, out t)
                && t.DataDictionary.TryGetValue("simpleText", TokenType.String, out st) ? st.String : "";
            if (title.Trim().Length == 0 || !WellFormedText(title)) { Reject(3); return; }
            title = CapTitle(title);
            if (!WellFormedText(title)) { Reject(3); return; }
            if (!d.TryGetValue("navigationEndpoint", TokenType.DataDictionary, out ne)
                || !ne.DataDictionary.TryGetValue("watchEndpoint", TokenType.DataDictionary, out we)
                || !we.DataDictionary.TryGetValue("videoId", TokenType.String, out wv)
                || !we.DataDictionary.TryGetValue("playlistId", TokenType.String, out wp)) { Reject(4); return; }
            if (wv.String != v.String || wp.String != requestedList) { Reject(4); return; }
            mixIds.Add(new DataToken(v.String));
            mixTitles.Add(new DataToken(title));
            mixValid++;
        }

        // All or nothing: the one list object with the requested playlistId, its list closed, at most MaxMixItems
        // elements, every one checked. Only then the same video listed twice is kept once (the first).
        private void MixFinish()
        {
            bool nonEmpty = tDicts + tArrays + tStrings > 0 || tCommas > 0;
            if (!nonEmpty && tClosed && tEnd > tStart + 1) nonEmpty = body.Substring(tStart + 1, tEnd - tStart - 1).Trim().Length > 0;
            int total = nonEmpty ? tCommas + 1 : 0;
            int primitives = total - tDicts - tArrays - tStrings;
            fbUnknownShape = tUnknownDict + tArrays + tStrings + (primitives > 0 ? primitives : 0);
            fbLockups = tLock;
            mixItems = total;
            // R11-A02: a playlist key on the way that holds no object (null, an array, …) is not "no list on the page"
            if (failReason.Length == 0 && pathKeys != null && ((pathKeys[2] > 0 && outerFound == 0) || (pathKeys[3] > 0 && pFound == 0)))
                failReason = "listNotObject";
            if (failReason.Length == 0 && pFound > 0)
            {
                if (tFound == 0) failReason = "targetMissing";
                else if (!tClosed) failReason = "targetNotClosed";
                else if (pidKeys != 1 || pidBad) failReason = "listIdMissing";
                else if (pidValue != requestedList) failReason = "listIdMismatch";
                else if (total > MaxMixItems) failReason = "tooMany";
                else if (primitives < 0 || tDicts != tLock + tUnknownDict || total != tLock + fbUnknownShape || tLock != mixValid + fbRejected)
                    failReason = "countMismatch";
            }
            // "unavailable": the whole ytInitialData was read and holds no Mix list (or an empty one)
            if (failReason.Length > 0) mixOutcome = "failed:" + failReason;
            else if (pFound == 0 || total == 0) mixOutcome = "unavailable";
            else if (fbRejected > 0 || fbUnknownShape > 0) mixOutcome = "rejected";
            else mixOutcome = "saved";
            tracks = DataList<Track>.New();
            bool startListed = false;
            if (mixOutcome == "saved")
            {
                DataDictionary once = new DataDictionary();
                for (int i = 0; i < mixIds.Count; i++)
                {
                    string id = mixIds[i].String;
                    if (id == requestedVideo) startListed = true;
                    if (once.ContainsKey(id)) { mixDuplicates++; continue; }
                    once.SetValue(id, true);
                    tracks.Add(Track.New(VideoPlayerType.AVProVideoPlayer, mixTitles[i].String, VRCUrl.Empty, "https://www.youtube.com/watch?v=" + id));
                }
            }
            // drop the scan state (IDs and titles were held in memory only)
            mixIds = null; mixTitles = null; names = null; gExp = null; wTok = null; wPath = null; wParent = null; wDepth = null; seen = null;
            pidValue = "";
            state = mixOutcome == "saved" ? 3 : 4;
            errorCode = 0;
            int wallMs = fbFrames > 0 ? (int)((Time.realtimeSinceStartupAsDouble - fbStart) * 1000.0) : 0;
            Debug.Log("[DM MyList] import PERSISTENT mix: outcome " + mixOutcome + (syntaxAt.Length > 0 ? " (JSON grammar: " + syntaxAt + ")" : "")
                + ", elements " + total + " (panel " + tLock + ", unknownShape " + fbUnknownShape + "), valid " + mixValid
                + ", rejected " + fbRejected + " {badId " + fbBadId + ", noTitle " + fbNoTitle + ", endpoint " + fbEndpoint + ", badShape " + fbBadShape
                + " (escapedSurrogate " + fbEscapedSurrogate + ")}, duplicate " + mixDuplicates + ", tracks " + tracks.Count()
                + ", listObjects " + pFound + ", pagePanels " + mixPagePanels + ", infinite " + mixInfinite + ", startListed " + startListed
                + ", frames " + fbFrames + ", wallMs " + wallMs + ", maxFrameUs " + (int)(scanMaxFrameMs * 1000.0));
            if (view != null) view.ImportFinished();
        }
    }
}
