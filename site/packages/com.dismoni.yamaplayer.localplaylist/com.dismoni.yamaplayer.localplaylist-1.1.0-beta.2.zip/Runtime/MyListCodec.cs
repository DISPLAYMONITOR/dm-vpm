namespace DM.YamaMyList
{
    using VRC.SDKBase;
    using VRC.SDK3.Data;

    // Shared by Udon and Editor tests. No URL construction occurs in this codec.
    public static class MyListCodec
    {
        // Total over every playlist. MaxEstimatedBytes is checked as well and can stop a list earlier
        // (long titles / URLs). Up to 1.0.1-rc.11 this was 100: those versions lock (never rewrite) data with more rows.
        public const int MaxEntries = 150;
        public const int MaxPlaylists = 16;
        public const int MaxUrlLength = 2048;
        public const int MaxTitleLength = 256;
        public const int MaxEstimatedBytes = 60000;

        public static bool ValidVideoId(string id)
        {
            if (string.IsNullOrEmpty(id) || id.Length != 11) return false;
            for (int i = 0; i < id.Length; i++)
            {
                char c = id[i];
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') || c == '_' || c == '-') continue;
                return false;
            }
            return true;
        }

        // Same-video identity (duplicate rule, title lookup, stored original URL): the common YouTube
        // forms (www / no-www / m. / music. watch, youtu.be, shorts) share the canonical watch URL
        // https://www.youtube.com/watch?v={11-char id}; every other URL keeps exact-string identity.
        public static string Identity(string url)
        {
            if (string.IsNullOrEmpty(url)) return "";
            string id = "";
            if (url.StartsWith("https://www.youtube.com/watch?v=")) id = url.Substring(32);
            else if (url.StartsWith("https://youtube.com/watch?v=")) id = url.Substring(28);
            else if (url.StartsWith("https://m.youtube.com/watch?v=")) id = url.Substring(30);
            else if (url.StartsWith("https://youtu.be/")) id = url.Substring(17);
            else if (url.StartsWith("https://music.youtube.com/watch?v=")) id = url.Substring(34);
            else if (url.StartsWith("https://www.youtube.com/shorts/")) id = url.Substring(31);
            else if (url.StartsWith("https://youtube.com/shorts/")) id = url.Substring(27);
            else if (url.StartsWith("https://m.youtube.com/shorts/")) id = url.Substring(29);
            else if (url.StartsWith("https://www.youtube.com/live/")) id = url.Substring(29);
            else if (url.StartsWith("https://youtube.com/live/")) id = url.Substring(25);
            if (id != "") id = id.Split('&', '?', '#')[0];
            return ValidVideoId(id) ? "https://www.youtube.com/watch?v=" + id : url;
        }

        public static bool IsVideoKey(string key) { return key != null && key.StartsWith("https://www.youtube.com/watch?v="); }

        // The identity used for every automatic title decision (Store and view share this one rule):
        // original URL first, then the VRCUrl. A track whose VRCUrl and original URL name two different
        // YouTube videos is contradictory and has no identity ("") - it is never matched automatically.
        public static string ConsistentIdentity(VRCUrl url, string original)
        {
            string u = VRCUrl.IsNullOrEmpty(url) ? "" : Identity(url.Get());
            string o = string.IsNullOrEmpty(original) ? "" : Identity(original);
            if (u != "" && o != "" && u != o && IsVideoKey(u) && IsVideoKey(o)) return "";
            return o != "" ? o : u;
        }

        public static string TrackKey(VRCUrl url, string original)
        {
            return Identity(VRCUrl.IsNullOrEmpty(url) ? original : url.Get());
        }

        public static bool ValidUrl(string value)
        {
            if (string.IsNullOrEmpty(value) || value.Length > MaxUrlLength) return false;
            int start = value.StartsWith("https://") ? 8 : value.StartsWith("http://") ? 7 : value.StartsWith("rtsp://") ? 7 : value.StartsWith("rtmp://") ? 7 : 0;
            if (start == 0 || value.Length <= start || value[start] == '/' || value[start] == '?' || value[start] == '#') return false;
            for (int i = 0; i < value.Length; i++) if (value[i] <= ' ' || value[i] == '\\') return false;
            return true;
        }

        // ---------- text escape of schema v3 ----------
        // VRCJson writes '"' as \" but writes '\' unescaped, so a text with '\' (a '\' before '"', or at the end) comes
        // back changed or not at all. Schema v3 stores every text field (title, original URL, playlist name) with
        // '%', '"', '\' and the control characters (0x00-0x1F, 0x7F) as %XX (two upper-case hex digits). The saved text
        // then holds no character VRCJson writes with a backslash. v3 is written only when a text needs it
        // ('"', '\' or a control character); everything else is written as schema v2, byte for byte as before.

        // the characters a v3 text escapes: control characters, 0x7F, '"', '%', '\'
        private static char[] EscapedChars()
        {
            char[] set = new char[36];
            for (int i = 0; i < 32; i++) set[i] = (char)i;
            set[32] = (char)0x7F; set[33] = '"'; set[34] = '\\'; set[35] = '%';
            return set;
        }

        // the characters that make v3 necessary (the escaped ones except '%')
        private static char[] TriggerChars()
        {
            char[] set = new char[35];
            for (int i = 0; i < 32; i++) set[i] = (char)i;
            set[32] = (char)0x7F; set[33] = '"'; set[34] = '\\';
            return set;
        }

        private static bool Escaped(int c) { return c < 0x20 || c == 0x7F || c == '"' || c == '%' || c == '\\'; }

        public static string EscapeText(string s, char[] escaped)
        {
            if (string.IsNullOrEmpty(s)) return "";
            int i = s.IndexOfAny(escaped);
            if (i < 0) return s;
            const string hex = "0123456789ABCDEF";
            string result = "";
            int start = 0;
            while (i >= 0)
            {
                int c = s[i];
                result += s.Substring(start, i - start) + "%" + hex.Substring(c >> 4, 1) + hex.Substring(c & 15, 1);
                start = i + 1;
                i = start < s.Length ? s.IndexOfAny(escaped, start) : -1;
            }
            return result + s.Substring(start);
        }

        // Strict reverse of EscapeText: only %XX with upper-case hex digits naming an escaped character; a raw '"', '\'
        // or control character, or any other '%' form, is invalid (null). Returns the original text otherwise.
        public static string UnescapeText(string s, char[] trigger)
        {
            if (s == null) return null;
            if (s.IndexOfAny(trigger) >= 0) return null;
            int i = s.IndexOf('%');
            if (i < 0) return s;
            string result = "";
            int start = 0;
            while (i >= 0)
            {
                if (i + 2 >= s.Length) return null;
                int hi = HexValue(s[i + 1]), lo = HexValue(s[i + 2]);
                if (hi < 0 || lo < 0) return null;
                int c = hi * 16 + lo;
                if (!Escaped(c)) return null;
                result += s.Substring(start, i - start) + ((char)c).ToString();
                start = i + 3;
                i = start < s.Length ? s.IndexOf('%', start) : -1;
            }
            return result + s.Substring(start);
        }

        private static int HexValue(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }

        // ---------- UTF-16 (T1-A02) ----------
        // Every high surrogate (0xD800-0xDBFF) followed by a low one (0xDC00-0xDFFF), no low surrogate on its own.
        // Numeric comparisons only: surrogate char constants do not survive UdonSharp.
        public static bool WellFormed(string s)
        {
            if (s == null) return true;
            int n = s.Length;
            for (int i = 0; i < n; i++)
            {
                int c = s[i];
                if (c < 0xD800 || c > 0xDFFF) continue;
                if (c >= 0xDC00) return false;
                if (i + 1 >= n) return false;
                int d = s[i + 1];
                if (d < 0xDC00 || d > 0xDFFF) return false;
                i++;
            }
            return true;
        }

        // At most max UTF-16 code units; one fewer when the last kept unit would be the high half of a pair.
        public static string CapText(string s, int max)
        {
            if (s == null || s.Length <= max) return s;
            int last = s[max - 1];
            return s.Substring(0, last >= 0xD800 && last <= 0xDBFF ? max - 1 : max);
        }

        // ---------- strict JSON (T1-A01) ----------
        // True when the whole text is exactly one JSON value (RFC 8259): objects, arrays, strings with the standard
        // escapes only (\" \\ \/ \b \f \n \r \t \uXXXX), no raw control character in a string, numbers
        // -?(0|[1-9][0-9]*)(.[0-9]+)?([eE][+-]?[0-9]+)?, true / false / null, whitespace (space, tab, CR, LF) between
        // tokens; no trailing comma, nothing after the value, at most JsonMaxDepth levels. Independent of the import's
        // scanner (no dependency between the two). Used before a schema v3 text is read.
        public const int JsonMaxDepth = 32;

        public static bool StrictJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return false;
            int n = s.Length, i = 0, depth = 0;
            int[] stack = new int[JsonMaxDepth + 1];   // 1 object, 2 array
            char[] stops = new char[34];
            for (int k = 0; k < 32; k++) stops[k] = (char)k;
            stops[32] = '"'; stops[33] = '\\';
            // 0 a value, 1 after a value, 2 a key or '}' (just after '{'), 3 a key (after ',' in an object), 4 ':', 5 a value or ']' (just after '[')
            int state = 0;
            while (true)
            {
                while (i < n && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++;
                if (i >= n) return depth == 0 && state == 1;
                char c = s[i];
                if (state == 1)
                {
                    if (depth == 0) return false;   // something after the root value
                    int top = stack[depth - 1];
                    if (c == ',') { state = top == 1 ? 3 : 0; i++; continue; }
                    if ((c == '}' && top == 1) || (c == ']' && top == 2)) { depth--; i++; continue; }
                    return false;
                }
                if (state == 4) { if (c != ':') return false; state = 0; i++; continue; }
                if (state == 2 || state == 3)
                {
                    if (state == 2 && c == '}') { depth--; state = 1; i++; continue; }
                    if (c != '"') return false;
                    i = JsonString(s, i, stops);
                    if (i < 0) return false;
                    state = 4;
                    continue;
                }
                // state 0 or 5: a value
                if (state == 5 && c == ']') { depth--; state = 1; i++; continue; }
                if (c == '{' || c == '[')
                {
                    if (depth >= JsonMaxDepth) return false;
                    stack[depth] = c == '{' ? 1 : 2; depth++;
                    state = c == '{' ? 2 : 5; i++;
                    continue;
                }
                if (c == '"') i = JsonString(s, i, stops);
                else if (c == '-' || (c >= '0' && c <= '9')) i = JsonNumber(s, i);
                else if (c == 't') i = JsonWord(s, i, "true");
                else if (c == 'f') i = JsonWord(s, i, "false");
                else if (c == 'n') i = JsonWord(s, i, "null");
                else return false;
                if (i < 0) return false;
                state = 1;
            }
        }

        // index after the closing quote, or -1
        private static int JsonString(string s, int i, char[] stops)
        {
            int n = s.Length;
            i++;
            while (true)
            {
                int j = i < n ? s.IndexOfAny(stops, i) : -1;
                if (j < 0) return -1;              // not closed
                char c = s[j];
                if (c == '"') return j + 1;
                if (c != '\\') return -1;          // raw control character
                if (j + 1 >= n) return -1;
                char e = s[j + 1];
                if (e == '"' || e == '\\' || e == '/' || e == 'b' || e == 'f' || e == 'n' || e == 'r' || e == 't') { i = j + 2; continue; }
                if (e != 'u' || j + 5 >= n) return -1;
                for (int k = j + 2; k < j + 6; k++)
                {
                    char h = s[k];
                    if (!((h >= '0' && h <= '9') || (h >= 'a' && h <= 'f') || (h >= 'A' && h <= 'F'))) return -1;
                }
                i = j + 6;
            }
        }

        // index after the number, or -1
        private static int JsonNumber(string s, int i)
        {
            int n = s.Length;
            if (s[i] == '-') { i++; if (i >= n) return -1; }
            if (s[i] == '0') i++;
            else if (s[i] >= '1' && s[i] <= '9') { while (i < n && s[i] >= '0' && s[i] <= '9') i++; }
            else return -1;
            if (i < n && s[i] == '.')
            {
                i++;
                int start = i;
                while (i < n && s[i] >= '0' && s[i] <= '9') i++;
                if (i == start) return -1;
            }
            if (i < n && (s[i] == 'e' || s[i] == 'E'))
            {
                i++;
                if (i < n && (s[i] == '+' || s[i] == '-')) i++;
                int start = i;
                while (i < n && s[i] >= '0' && s[i] <= '9') i++;
                if (i == start) return -1;
            }
            return i;
        }

        private static int JsonWord(string s, int i, string word)
        {
            if (i + word.Length > s.Length || s.Substring(i, word.Length) != word) return -1;
            return i + word.Length;
        }

        public static string Encode(string[] titles, string[] originals, int[] players, int[] owners, int[] ids, string[] names, int nextId)
        {
            // broken UTF-16 (a lone surrogate) is never written: "" makes the Store refuse the change (T1-A02)
            for (int i = 0; i < titles.Length; i++) if (!WellFormed(titles[i]) || !WellFormed(originals[i])) return "";
            for (int i = 0; i < names.Length; i++) if (!WellFormed(names[i])) return "";
            char[] trigger = TriggerChars();
            bool v3 = false;
            for (int i = 0; i < titles.Length && !v3; i++)
                if ((titles[i] != null && titles[i].IndexOfAny(trigger) >= 0) || (originals[i] != null && originals[i].IndexOfAny(trigger) >= 0)) v3 = true;
            for (int i = 0; i < names.Length && !v3; i++)
                if (names[i] != null && names[i].IndexOfAny(trigger) >= 0) v3 = true;
            char[] escaped = v3 ? EscapedChars() : null;
            DataList rows = new DataList();
            for (int i = 0; i < titles.Length; i++)
            {
                DataList row = new DataList();
                row.Add(v3 ? EscapeText(titles[i], escaped) : titles[i]); row.Add(v3 ? EscapeText(originals[i], escaped) : originals[i]); row.Add(players[i]); row.Add(owners[i]); rows.Add(row);
            }
            DataDictionary root = new DataDictionary();
            root.Add("v", v3 ? 3 : 2); root.Add("rows", rows); root.Add("next", nextId);
            DataList lists = new DataList();
            for (int i = 0; i < ids.Length; i++) { DataList list = new DataList(); list.Add(ids[i]); list.Add(v3 ? EscapeText(names[i], escaped) : names[i]); lists.Add(list); }
            root.Add("lists", lists);
            DataToken result;
            return VRCJson.TrySerializeToJson(root, JsonExportType.Minify, out result) ? result.String : "";
        }

        public static bool Decode(VRCUrl[] urls, string json, out string[] titles, out string[] originals, out int[] players, out int[] owners, out int[] ids, out string[] names, out int nextId)
        {
            // Nothing saved yet = no playlist. A playlist exists only because the user made one (or saved data lists it):
            // none is created here. (Up to 1.0.1-rc.5 an unsaved "Favorites" with ID 1 was shown in this state. It was
            // never written by itself; saved data that lists it is read below like any other playlist.)
            titles = new string[0]; originals = new string[0]; players = new int[0]; owners = new int[0]; ids = new int[0]; names = new string[0]; nextId = 2;
            if (urls == null || urls.Length > MaxEntries || json == null || json.Length > MaxEstimatedBytes) return false;
            if (urls.Length == 0 && json == "") return true; // pristine PlayerObject: no playlists (the first one made gets ID 2; schema v2 needs next >= 2)
            DataToken root;
            if (!VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary) return false;
            DataToken version, rows, lists, next;
            // v2: texts as written; v3: texts escaped (EscapeText), read back strictly. Any other version is not read.
            if (!root.DataDictionary.TryGetValue("v", TokenType.Double, out version) || (version.Double != 2 && version.Double != 3)) return false;
            bool v3 = version.Double == 3;
            // v3 is read only from a text that is strictly valid JSON (T1-A01); VRCJson alone accepts some invalid JSON.
            // The v2 reading is unchanged.
            if (v3 && !StrictJson(json)) return false;
            char[] trigger = v3 ? TriggerChars() : null;
            if (!root.DataDictionary.TryGetValue("rows", TokenType.DataList, out rows) || rows.DataList.Count != urls.Length) return false;
            if (!root.DataDictionary.TryGetValue("lists", TokenType.DataList, out lists) || lists.DataList.Count > MaxPlaylists) return false; // 0 playlists is valid (the user deleted them all)
            if (!root.DataDictionary.TryGetValue("next", TokenType.Double, out next) || next.Double < 2 || next.Double > 1000000000 || next.Double != (int)next.Double) return false;
            nextId = (int)next.Double; ids = new int[lists.DataList.Count]; names = new string[ids.Length];
            for (int i = 0; i < ids.Length; i++)
            {
                DataToken item = lists.DataList[i];
                if (item.TokenType != TokenType.DataList || item.DataList.Count != 2) return false;
                DataToken id = item.DataList[0], name = item.DataList[1];
                if (id.TokenType != TokenType.Double || id.Double < 1 || id.Double >= nextId || id.Double != (int)id.Double || name.TokenType != TokenType.String) return false;
                string nameText = v3 ? UnescapeText(name.String, trigger) : name.String;
                if (nameText == null || string.IsNullOrEmpty(nameText.Trim()) || nameText.Length > 48 || (v3 && !WellFormed(nameText))) return false;
                ids[i] = (int)id.Double; names[i] = nameText;
                for (int j = 0; j < i; j++) if (ids[j] == ids[i]) return false;
            }
            owners = new int[urls.Length];
            titles = new string[urls.Length]; originals = new string[urls.Length]; players = new int[urls.Length];
            for (int i = 0; i < urls.Length; i++)
            {
                DataToken row = rows.DataList[i];
                if (row.TokenType != TokenType.DataList || row.DataList.Count != 4) return false;
                DataToken t = row.DataList[0], o = row.DataList[1], p = row.DataList[2];
                if (t.TokenType != TokenType.String || o.TokenType != TokenType.String || p.TokenType != TokenType.Double) return false;
                string title = v3 ? UnescapeText(t.String, trigger) : t.String;
                string original = v3 ? UnescapeText(o.String, trigger) : o.String;
                if (title == null || original == null || (v3 && (!WellFormed(title) || !WellFormed(original)))) return false;
                if (title.Length > MaxTitleLength || original.Length > MaxUrlLength || (original != "" && !ValidUrl(original)) || (p.Double != 0 && p.Double != 1)) return false;
                // YamaPlayer's playlist parser supplies an original URL with VRCUrl.Empty.
                if (VRCUrl.IsNullOrEmpty(urls[i]) ? original == "" : !ValidUrl(urls[i].Get())) return false;
                DataToken owner = row.DataList[3];
                if (owner.TokenType != TokenType.Double || owner.Double != (int)owner.Double) return false;
                owners[i] = (int)owner.Double; bool found = false;
                for (int j = 0; j < ids.Length; j++) if (owners[i] == ids[j]) found = true;
                if (!found) return false;
                titles[i] = title; originals[i] = original; players[i] = (int)p.Double;
            }
            return EstimateBytes(urls, json) <= MaxEstimatedBytes;
        }

        // Conservative UTF-8 bound, plus per-element overhead. Actual wire/compressed usage is separate.
        public static int EstimateBytes(VRCUrl[] urls, string json)
        {
            int bytes = 128 + json.Length * 3;
            for (int i = 0; i < urls.Length; i++) bytes += urls[i].Get().Length * 3 + 16;
            return bytes;
        }

        // True only for a YouTube "list of videos" playlist page with a real, non-special list id.
        // A single video URL (watch?v=..&list=.., youtu.be/..?list=.., shorts, etc.) returns false so
        // callers fall back to a normal single-track add / stock PlayUrl instead of a playlist import.
        public static bool IsImportablePlaylistUrl(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            int schemeEnd = value.StartsWith("https://") ? 8 : value.StartsWith("http://") ? 7 : -1;
            if (schemeEnd < 0) return false;
            int hostEnd = value.IndexOf('/', schemeEnd);
            if (hostEnd < 0) return false;
            string host = value.Substring(schemeEnd, hostEnd - schemeEnd);
            int colon = host.IndexOf(':');
            if (colon >= 0) host = host.Substring(0, colon);
            host = host.ToLower();
            if (host != "youtube.com" && host != "www.youtube.com" && host != "m.youtube.com" && host != "music.youtube.com") return false;
            string rest = value.Substring(hostEnd);
            int query = rest.IndexOf('?');
            string path = query < 0 ? rest : rest.Substring(0, query);
            if (path != "/playlist" || query < 0) return false;
            string qs = rest.Substring(query + 1);
            int hash = qs.IndexOf('#');
            if (hash >= 0) qs = qs.Substring(0, hash);
            string id = ExtractQueryParam(qs, "list");
            if (string.IsNullOrEmpty(id)) return false;
            if (id.StartsWith("RD") || id.StartsWith("UL") || id == "WL" || id == "LL" || id == "LM") return false;
            return true;
        }

        private static string ExtractQueryParam(string query, string key)
        {
            int i = 0;
            while (i < query.Length)
            {
                int amp = query.IndexOf('&', i);
                string part = amp < 0 ? query.Substring(i) : query.Substring(i, amp - i);
                int eq = part.IndexOf('=');
                if (eq >= 0 && part.Substring(0, eq) == key) return part.Substring(eq + 1);
                if (amp < 0) break;
                i = amp + 1;
            }
            return "";
        }

        // Target time of a relative seek ("-60" .. "+60" buttons): current + delta, kept inside 0 .. duration.
        // -1 = no seek possible (live stream, unknown or zero duration, invalid time).
        public static float SeekTarget(float current, float duration, float delta)
        {
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f) return -1f;
            if (float.IsNaN(current) || float.IsInfinity(current)) return -1f;
            float target = current + delta;
            return target < 0f ? 0f : target > duration ? duration : target;
        }
    }
}
