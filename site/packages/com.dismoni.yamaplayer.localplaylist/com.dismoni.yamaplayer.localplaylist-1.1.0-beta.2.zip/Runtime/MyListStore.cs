namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;
    using VRC.SDKBase;
    using VRC.Udon.Common;

    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class MyListStore : UdonSharpBehaviour
    {
        public MyListPersistentView view;
        public MyListNativePlaylistAdapter nativeAdapter;
        [UdonSynced, HideInInspector] public VRCUrl[] savedUrls = new VRCUrl[0];
        [UdonSynced, HideInInspector] public string savedMetadata = "";
        [System.NonSerialized] public string[] titles = new string[0];
        [System.NonSerialized] public string[] originals = new string[0];
        [System.NonSerialized] public int[] players = new int[0];
        [System.NonSerialized] public int[] trackPlaylists = new int[0];
        [System.NonSerialized] public int[] playlistIds = new int[0];       // no playlist until the saved data says so or the user makes one
        [System.NonSerialized] public string[] playlistNames = new string[0];
        [System.NonSerialized] public int nextPlaylistId = 2;
        [System.NonSerialized] public bool ready;
        [System.NonSerialized] public bool corrupt;
        [System.NonSerialized] public string status = "Waiting for restoration...";
        // Not synced. Bumped on every Commit so UI can distinguish an actual data change from a
        // status-only Refresh (e.g. a save-progress notice) and skip an expensive re-render.
        [System.NonSerialized] public int dataVersion;
        private bool _saveScheduled;
        private bool _dirty;
        private int _revision;
        private int _sendingRevision;
        private int _retries;

        public override void OnPlayerRestored(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal || !Networking.IsOwner(gameObject) || ready) return;
            ready = true;
            corrupt = !MyListCodec.Decode(savedUrls, savedMetadata, out titles, out originals, out players, out trackPlaylists, out playlistIds, out playlistNames, out nextPlaylistId);
            status = corrupt ? "Saved data is invalid / unsupported. Editing is locked; data preserved." : savedUrls.Length == 0 ? "Restored. MyList is empty." : "MyList restored.";
            if (Utilities.IsValid(view)) view.Bind(this);
            if (Utilities.IsValid(nativeAdapter)) { nativeAdapter.store = this; nativeAdapter.StoreChanged(); }
        }

        public bool Editable()
        {
            return ready && !corrupt && Networking.IsOwner(gameObject);
        }

        public void Add(VRCUrl url, string title, string original, int player, int playlistId, string newPlaylistName)
        {
            if (!Editable()) return;
            bool create = !string.IsNullOrEmpty(newPlaylistName);
            if (create && (!ValidName(newPlaylistName) || playlistIds.Length >= MyListCodec.MaxPlaylists || nextPlaylistId >= 1000000000)) { Notify("Invalid name or playlist limit reached."); return; }
            if (!create && PlaylistIndex(playlistId) < 0) { Notify("Select a destination playlist."); return; }
            if (create) playlistId = nextPlaylistId;
            if (original == null) original = "";
            if (original != "" && !MyListCodec.ValidUrl(original)) { Notify("Invalid original URL."); return; }
            if (VRCUrl.IsNullOrEmpty(url) ? original == "" : !MyListCodec.ValidUrl(url.Get())) { Notify("Invalid URL."); return; }
            // A saved track always has a title: the caller commits only after the title is known.
            if (title == null || title.Trim() == "") { Notify("Title required. Nothing was saved."); return; }
            // broken UTF-16 (a lone surrogate) is refused; a long title is cut without splitting a surrogate pair
            if (!MyListCodec.WellFormed(title) || !MyListCodec.WellFormed(original)) { Notify("Invalid playlist track. List unchanged."); return; }
            title = MyListCodec.CapText(title, MyListCodec.MaxTitleLength);
            for (int i = 0; i < savedUrls.Length; i++)
                if (trackPlaylists[i] == playlistId && SameTrack(savedUrls[i], originals[i], url, original)) { Notify("Already in MyList."); return; }
            int count = savedUrls.Length;
            if (count >= MyListCodec.MaxEntries) { Notify("Entry limit reached."); return; }
            VRCUrl[] u = new VRCUrl[count + 1]; string[] t = new string[count + 1]; string[] o = new string[count + 1]; int[] p = new int[count + 1]; int[] owners = new int[count + 1];
            for (int i = 0; i < count; i++) { u[i] = savedUrls[i]; t[i] = titles[i]; o[i] = originals[i]; p[i] = players[i]; owners[i] = trackPlaylists[i]; }
            u[count] = url; t[count] = title; o[count] = original; p[count] = player == 0 ? 0 : 1; owners[count] = playlistId;
            int[] ids = playlistIds; string[] names = playlistNames;
            if (create) { ids = AppendId(nextPlaylistId); names = AppendName(newPlaylistName.Trim()); }
            Commit(u, t, o, p, owners, ids, names, create ? nextPlaylistId + 1 : nextPlaylistId);
        }

        private bool SameTrack(VRCUrl left, string leftOriginal, VRCUrl right, string rightOriginal)
        {
            // Original URLs identify empty-VRCUrl tracks. Known YouTube watch/short URLs share
            // the canonical video identity; all other URLs retain exact-string matching.
            string leftKey = VRCUrl.IsNullOrEmpty(left) ? leftOriginal : left.Get();
            string rightKey = VRCUrl.IsNullOrEmpty(right) ? rightOriginal : right.Get();
            return MyListCodec.Identity(leftKey) == MyListCodec.Identity(rightKey);
        }

        // Late / known title: matched by the record's consistent identity (never by index), written only into
        // tracks that still exist and have no title. playlistId < 0 = every playlist. One commit.
        public void SetTitleByKey(int playlistId, string key, string title)
        {
            if (!Editable() || string.IsNullOrEmpty(key) || string.IsNullOrEmpty(title) || !MyListCodec.WellFormed(title)) return;
            title = MyListCodec.CapText(title, MyListCodec.MaxTitleLength);
            string[] updatedTitles = new string[titles.Length];
            bool changed = false;
            for (int i = 0; i < titles.Length; i++)
            {
                // MyListCodec.ConsistentIdentity: a record whose VRCUrl and original URL are two different
                // videos has no identity and is never filled in automatically.
                bool match = (playlistId < 0 || trackPlaylists[i] == playlistId) && string.IsNullOrEmpty(titles[i]) &&
                    MyListCodec.ConsistentIdentity(savedUrls[i], originals[i]) == key;
                updatedTitles[i] = match ? title : titles[i];
                changed |= match;
            }
            if (changed) Commit(savedUrls, updatedTitles, originals, players, trackPlaylists, playlistIds, playlistNames, nextPlaylistId);
        }

        // Several late titles at once (old records without a title): one pass, one commit, same identity rule.
        public void FillTitles(string[] keys, string[] newTitles, int count)
        {
            if (!Editable() || keys == null || newTitles == null || count <= 0) return;
            string[] updatedTitles = new string[titles.Length];
            bool changed = false;
            for (int i = 0; i < titles.Length; i++)
            {
                updatedTitles[i] = titles[i];
                if (!string.IsNullOrEmpty(titles[i])) continue;
                string identity = MyListCodec.ConsistentIdentity(savedUrls[i], originals[i]);
                if (identity == "") continue;
                for (int k = 0; k < count; k++)
                {
                    if (keys[k] != identity || string.IsNullOrEmpty(newTitles[k]) || !MyListCodec.WellFormed(newTitles[k])) continue;
                    updatedTitles[i] = MyListCodec.CapText(newTitles[k], MyListCodec.MaxTitleLength);
                    changed = true;
                    break;
                }
            }
            if (changed) Commit(savedUrls, updatedTitles, originals, players, trackPlaylists, playlistIds, playlistNames, nextPlaylistId);
        }

        public void AddMany(VRCUrl[] urls, string[] batchTitles, string[] batchOriginals, int[] batchPlayers, int playlistId, string newPlaylistName)
        {
            if (!Editable()) return;
            bool create = !string.IsNullOrEmpty(newPlaylistName);
            if (create && (!ValidName(newPlaylistName) || playlistIds.Length >= MyListCodec.MaxPlaylists || nextPlaylistId >= 1000000000)) { Notify("Invalid name or playlist limit reached."); return; }
            if (!create && PlaylistIndex(playlistId) < 0) { Notify("Select a destination playlist."); return; }
            if (urls == null || batchTitles == null || batchOriginals == null || batchPlayers == null ||
                urls.Length != batchTitles.Length || urls.Length != batchOriginals.Length || urls.Length != batchPlayers.Length) { Notify("Invalid playlist data."); return; }
            if (create) playlistId = nextPlaylistId;
            int keep = 0;
            for (int i = 0; i < urls.Length; i++)
            {
                string original = batchOriginals[i];
                if (batchTitles[i] == null || batchTitles[i].Trim() == "") { Notify("Title required. Nothing was saved."); return; }
                if (original == null || !MyListCodec.WellFormed(batchTitles[i]) || !MyListCodec.WellFormed(original) || (original != "" && !MyListCodec.ValidUrl(original)) ||
                    (VRCUrl.IsNullOrEmpty(urls[i]) ? original == "" : !MyListCodec.ValidUrl(urls[i].Get()))) { Notify("Invalid playlist track. List unchanged."); return; }
                bool duplicate = false;
                for (int j = 0; j < savedUrls.Length; j++)
                    if (trackPlaylists[j] == playlistId && SameTrack(savedUrls[j], originals[j], urls[i], original)) { duplicate = true; break; }
                for (int j = 0; j < i && !duplicate; j++)
                    if (SameTrack(urls[j], batchOriginals[j], urls[i], original)) duplicate = true;
                if (!duplicate) keep++;
            }
            if (savedUrls.Length + keep > MyListCodec.MaxEntries) { Notify("Entry limit reached. List unchanged."); return; }
            if (keep == 0 && !create) { Notify("No new tracks to add."); return; }
            int count = savedUrls.Length;
            VRCUrl[] u = new VRCUrl[count + keep]; string[] t = new string[count + keep]; string[] o = new string[count + keep]; int[] p = new int[count + keep]; int[] owners = new int[count + keep];
            for (int i = 0; i < count; i++) { u[i] = savedUrls[i]; t[i] = titles[i]; o[i] = originals[i]; p[i] = players[i]; owners[i] = trackPlaylists[i]; }
            int dst = count;
            for (int i = 0; i < urls.Length; i++)
            {
                bool duplicate = false;
                for (int j = 0; j < dst; j++)
                    if (owners[j] == playlistId && SameTrack(u[j], o[j], urls[i], batchOriginals[i])) { duplicate = true; break; }
                if (duplicate) continue;
                u[dst] = urls[i]; t[dst] = batchTitles[i] == null ? "" : MyListCodec.CapText(batchTitles[i], MyListCodec.MaxTitleLength);
                o[dst] = batchOriginals[i]; p[dst] = batchPlayers[i] == 0 ? 0 : 1; owners[dst] = playlistId; dst++;
            }
            int[] ids = create ? AppendId(nextPlaylistId) : playlistIds;
            string[] names = create ? AppendName(newPlaylistName.Trim()) : playlistNames;
            Commit(u, t, o, p, owners, ids, names, create ? nextPlaylistId + 1 : nextPlaylistId);
        }

        public void RemoveAt(int index)
        {
            if (!Editable() || index < 0 || index >= savedUrls.Length) return;
            int count = savedUrls.Length - 1;
            VRCUrl[] u = new VRCUrl[count]; string[] t = new string[count]; string[] o = new string[count]; int[] p = new int[count]; int[] owners = new int[count];
            int dst = 0;
            for (int i = 0; i < savedUrls.Length; i++)
            {
                if (i == index) continue;
                u[dst] = savedUrls[i]; t[dst] = titles[i]; o[dst] = originals[i]; p[dst] = players[i]; owners[dst] = trackPlaylists[i]; dst++;
            }
            Commit(u, t, o, p, owners, playlistIds, playlistNames, nextPlaylistId);
        }

        public void Move(int index, int delta)
        {
            int target = -1;
            if (index >= 0 && index < savedUrls.Length && (delta == -1 || delta == 1))
                for (int i = index + delta; i >= 0 && i < savedUrls.Length; i += delta) if (trackPlaylists[i] == trackPlaylists[index]) { target = i; break; }
            if (!Editable() || index < 0 || target < 0 || index >= savedUrls.Length || target >= savedUrls.Length || (delta != -1 && delta != 1)) return;
            int count = savedUrls.Length;
            VRCUrl[] u = new VRCUrl[count]; string[] t = new string[count]; string[] o = new string[count]; int[] p = new int[count]; int[] owners = new int[count];
            for (int i = 0; i < count; i++)
            {
                int source = i == index ? target : i == target ? index : i;
                u[i] = savedUrls[source]; t[i] = titles[source]; o[i] = originals[source]; p[i] = players[source]; owners[i] = trackPlaylists[source];
            }
            Commit(u, t, o, p, owners, playlistIds, playlistNames, nextPlaylistId);
        }


        public int PlaylistIndex(int id) { for (int i = 0; i < playlistIds.Length; i++) if (playlistIds[i] == id) return i; return -1; }
        private bool ValidName(string name) { return name != null && name.Trim().Length > 0 && name.Length <= 48 && MyListCodec.WellFormed(name); }
        private int[] AppendId(int id) { int[] a = new int[playlistIds.Length + 1]; for(int i=0;i<playlistIds.Length;i++) a[i]=playlistIds[i]; a[a.Length-1]=id; return a; }
        private string[] AppendName(string name) { string[] a = new string[playlistNames.Length + 1]; for(int i=0;i<playlistNames.Length;i++) a[i]=playlistNames[i]; a[a.Length-1]=name; return a; }
        public void CreatePlaylist(string name)
        {
            if (!Editable()) return;
            if (!ValidName(name) || playlistIds.Length >= MyListCodec.MaxPlaylists || nextPlaylistId >= 1000000000) { Notify("Invalid name or 16 playlist limit reached."); return; }
            Commit(savedUrls, titles, originals, players, trackPlaylists, AppendId(nextPlaylistId), AppendName(name.Trim()), nextPlaylistId+1);
        }
        public void RenamePlaylist(int id, string name)
        {
            int index = PlaylistIndex(id);
            if (!Editable() || index < 0) return;
            if (!ValidName(name)) { Notify("Enter a name (1-48 characters)."); return; }
            if (playlistNames[index] == name.Trim()) return;
            string[] names = new string[playlistNames.Length];
            for(int i=0;i<names.Length;i++) names[i] = i == index ? name.Trim() : playlistNames[i];
            Commit(savedUrls, titles, originals, players, trackPlaylists, playlistIds, names, nextPlaylistId);
        }
        public void DeletePlaylist(int id)
        {
            int index = PlaylistIndex(id);
            if (!Editable() || index < 0) return;
            int count=0; for(int i=0;i<savedUrls.Length;i++) if(trackPlaylists[i]!=id) count++;
            VRCUrl[] u=new VRCUrl[count]; string[] t=new string[count]; string[] o=new string[count]; int[] p=new int[count]; int[] owners=new int[count];
            int dst=0; for(int i=0;i<savedUrls.Length;i++) { if(trackPlaylists[i]==id) continue; u[dst]=savedUrls[i];t[dst]=titles[i];o[dst]=originals[i];p[dst]=players[i];owners[dst]=trackPlaylists[i];dst++; }
            int[] ids=new int[playlistIds.Length-1]; string[] names=new string[ids.Length]; dst=0;
            for(int i=0;i<playlistIds.Length;i++) { if(i==index) continue;ids[dst]=playlistIds[i];names[dst]=playlistNames[i];dst++; }
            Commit(u,t,o,p,owners,ids,names,nextPlaylistId);
        }

        // Swaps a playlist with its neighbour in the list order (schema v2 keeps the array order).
        public void MovePlaylist(int id, int delta)
        {
            int index = PlaylistIndex(id);
            int target = index + delta;
            if (!Editable() || index < 0 || (delta != -1 && delta != 1) || target < 0 || target >= playlistIds.Length) return;
            int[] ids = new int[playlistIds.Length]; string[] names = new string[playlistNames.Length];
            for (int i = 0; i < ids.Length; i++)
            {
                int source = i == index ? target : i == target ? index : i;
                ids[i] = playlistIds[source]; names[i] = playlistNames[source];
            }
            Commit(savedUrls, titles, originals, players, trackPlaylists, ids, names, nextPlaylistId);
        }

        private void Commit(VRCUrl[] u, string[] t, string[] o, int[] p, int[] owners, int[] ids, string[] names, int nextId)
        {
            string json = MyListCodec.Encode(t, o, p, owners, ids, names, nextId);
            if (json == "" || MyListCodec.EstimateBytes(u, json) > MyListCodec.MaxEstimatedBytes) { Notify("Storage budget reached. List unchanged."); return; }
            savedUrls = u; savedMetadata = json; titles = t; originals = o; players = p; trackPlaylists = owners; playlistIds = ids; playlistNames = names; nextPlaylistId = nextId;
            dataVersion++;
            _dirty = true; _revision++; _retries = 0;
            Notify("Changed. Save pending...");
            ScheduleSave();
        }

        private void ScheduleSave()
        {
            if (_saveScheduled) return;
            _saveScheduled = true;
            SendCustomEventDelayedSeconds(nameof(FlushSave), 1f);
        }

        public void FlushSave()
        {
            _saveScheduled = false;
            if (!Editable() || !_dirty) return;
            RequestSerialization();
        }

        public override void OnPreSerialization() { _sendingRevision = _revision; }

        public override void OnPostSerialization(SerializationResult result)
        {
            if (!Editable()) return;
            if (result.success)
            {
                _dirty = _sendingRevision != _revision;
                Notify(_dirty ? "Changed. Save pending..." : "Saved / sent. Cloud restore requires rejoin verification.");
                if (_dirty) ScheduleSave();
            }
            else
            {
                Notify("Save send failed. Keep this session open; press Retry save.");
                if (_retries < 1) { _retries++; ScheduleSave(); }
            }
        }

        public void RetrySave() { if (Editable() && _dirty) { _retries = 0; ScheduleSave(); } }

        private void Notify(string message)
        {
            status = message;
            if (Utilities.IsValid(nativeAdapter) && Editable()) { nativeAdapter.store = this; nativeAdapter.StoreChanged(); }
            if (Utilities.IsValid(view)) view.StoreChanged();
        }
    }
}
