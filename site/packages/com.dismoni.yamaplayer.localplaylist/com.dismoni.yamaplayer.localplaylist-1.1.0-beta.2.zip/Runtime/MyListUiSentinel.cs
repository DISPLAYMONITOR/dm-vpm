namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;

    // Placed at runtime as a child of a YamaPlayer list view. YamaPlayer's own buttons show/hide
    // those views; OnEnable/OnDisable report that without adding any listener to YamaPlayer controls.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListUiSentinel : UdonSharpBehaviour
    {
        public MyListPersistentView owner;
        public int kind; // 0 = native playlist list, 1 = native track list
        private void OnEnable() { if (owner != null) owner.SentinelChanged(kind, true); }
        private void OnDisable() { if (owner != null) owner.SentinelChanged(kind, false); }
    }
}
