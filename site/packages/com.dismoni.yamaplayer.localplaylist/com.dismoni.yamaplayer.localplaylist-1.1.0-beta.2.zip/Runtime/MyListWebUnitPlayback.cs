namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;
    using VRC.SDKBase;
    using Yamadev.YamaStream;
    using Yamadev.YamaStream.Modules;
#if WEB_UNIT_INCLUDED
    using Yamadev.YamachanWebUnit;
#endif

    // Pre-flight check for tracks saved without a VRCUrl (title + original URL only). Those play
    // through YamaPlayer's own resolver + WebUnit; this never replaces the resolver hook.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListWebUnitPlayback : UdonSharpBehaviour
    {
        public Controller controller;
        public VideoResolver resolver;
        public MyListPersistentView view;

        private void Feedback(string key) { if (view != null) view.Feedback(key); }

        // True when the track can be handed to Controller.PlayTrack on this client.
        public bool CanPlay(Track track)
        {
            if (controller == null) { Feedback("yama_missing"); return false; }
            if ((int)controller.PlayerPermission < (int)PlayerPermission.Editor)
            { Feedback("yama_locked"); return false; }
            if (!VRCUrl.IsNullOrEmpty(track.GetVRCUrl())) return true;
#if UNITY_ANDROID || UNITY_IOS
            Feedback("webunit_pc_only"); return false;
#elif WEB_UNIT_INCLUDED
            string original = track.GetOriginalUrl();
            if (string.IsNullOrEmpty(original) || !original.StartsWith("https://www.youtube.com/watch?v=") ||
                !MyListCodec.ValidVideoId(original.Substring(32).Split('&')[0]))
            { Feedback("webunit_failed"); return false; }
            if (resolver == null || !resolver.gameObject.activeInHierarchy)
            { Feedback("webunit_required"); return false; }
            Client client = (Client)resolver.GetProgramVariable("_client");
            object[] hook = (object[])(object)controller.ResolveTrack;
            if (client == null || !client.gameObject.activeInHierarchy || client.Urls == null ||
                client.Urls.Length < client.MaxLength * 256 || hook == null || hook.Length != 2 ||
                (UdonSharpBehaviour)hook[0] != resolver || (string)hook[1] != "ResolveTrack")
            { Feedback("webunit_required"); return false; }
            // Stock Client.Request rejects concurrent requests and notifies the previous receiver, so a busy
            // Client is refused here. DM Modified WebUnit v5+ replaces the request in flight instead; only then
            // the track is passed on while the Client is busy.
            if (client.IsLoading && !ReplacesRequestInFlight(client)) { Feedback("webunit_busy"); return false; }
            if (track.GetPlayerType() != VideoPlayerType.AVProVideoPlayer)
            { Feedback("webunit_failed"); return false; }
            return true;
#else
            Feedback("webunit_required"); return false;
#endif
        }

#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
        // True only for a WebUnit Client that states both its DM revision (5 or later) and that it replaces a
        // request in flight. Anything missing, of another type or lower counts as the official Client (fail closed).
        private bool ReplacesRequestInFlight(Client client)
        {
            object revision = client.GetProgramVariable("DmRevision");
            object replacement = client.GetProgramVariable("DmRequestReplacement");
            if (revision == null || replacement == null) return false;
            if (revision.GetType() != typeof(int) || replacement.GetType() != typeof(int)) return false;
            return (int)revision >= 5 && (int)replacement >= 1;
        }
#endif

        // Queue entries are resolved later by the native resolver; only the platform matters here.
        public bool CanQueue(Track track)
        {
            if (!VRCUrl.IsNullOrEmpty(track.GetVRCUrl())) return true;
#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
            return true;
#else
            Feedback("webunit_pc_only"); return false;
#endif
        }

        // F1b "play again" (Docs/F1B_PLAY_AGAIN_SPEC.md, chapter 3, conditions 2-4): true for a YouTube track without a
        // VRCUrl on PC with a usable WebUnit set-up. The same conditions as CanPlay, without its permission check and
        // without any feedback (F1b asks this for every error; nothing is shown from here).
        public bool IsF1bTarget(Track track)
        {
#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
            // Track is YamaPlayer's object[] pseudo class: `track == null` compiles to UnityEngine.Object equality in Udon
            // and halts this behaviour (found by the ClientSim check). Utilities.IsValid is the safe test.
            if (controller == null || !Utilities.IsValid(track)) return false;
            if (!MyListPlayAgainRules.IsYouTubeWithoutVrcUrl(VRCUrl.IsNullOrEmpty(track.GetVRCUrl()), track.GetOriginalUrl())) return false;
            if (track.GetPlayerType() != VideoPlayerType.AVProVideoPlayer) return false;
            return F1bClient() != null;
#else
            return false;
#endif
        }

        // True while the WebUnit Client is sending a request (F1b refuses a press and keeps tracking its request).
        // False when there is no usable Client.
        public bool WebUnitBusy()
        {
#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
            Client client = F1bClient();
            return client != null && client.IsLoading;
#else
            return false;
#endif
        }

        // The Client a F1b press hands its request to (taken just before the press calls PlayTrack); null without one.
        public UdonSharpBehaviour F1bRequestClient()
        {
#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
            return F1bClient();
#else
            return null;
#endif
        }

        // The state of that Client (MyListPlayAgainRules.ClientIdle / ClientBusy / ClientUnknown). Read from the Client
        // object itself, so a later change of the resolver or its hook does not turn "busy" into "idle".
        public int F1bClientState(UdonSharpBehaviour client)
        {
#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
            if (client == null || !Utilities.IsValid(client)) return MyListPlayAgainRules.ClientGone;
            return ((Client)client).IsLoading ? MyListPlayAgainRules.ClientBusy : MyListPlayAgainRules.ClientIdle;
#else
            return MyListPlayAgainRules.ClientUnknown;
#endif
        }

#if WEB_UNIT_INCLUDED && !UNITY_ANDROID && !UNITY_IOS
        // The Client of YamaPlayer's resolver when the WebUnit set-up is complete (the CanPlay checks); null otherwise.
        private Client F1bClient()
        {
            if (controller == null || resolver == null || !resolver.gameObject.activeInHierarchy) return null;
            Client client = (Client)resolver.GetProgramVariable("_client");
            object[] hook = (object[])(object)controller.ResolveTrack;
            if (client == null || !client.gameObject.activeInHierarchy || client.Urls == null ||
                client.Urls.Length < client.MaxLength * 256 || hook == null || hook.Length != 2 ||
                (UdonSharpBehaviour)hook[0] != resolver || (string)hook[1] != "ResolveTrack") return null;
            return client;
        }
#endif
    }
}
