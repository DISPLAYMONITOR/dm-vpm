namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;
    using VRC.SDKBase;
    using Yamadev.YamaStream;
    using Yamadev.YamaStream.Libraries.GenericDataContainer;

    // Owns the single networked DM_PERSISTENT_PLAYBACK_SLOT (a standard YamaPlayer Playlist).
    // Only RegisterSlot touches the existing Controller, at runtime only: it appends the slot once
    // to the static playlist array, so every client computes the same index.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListNativePlaylistAdapter : UdonSharpBehaviour
    {
        public Controller controller;
        public Playlist slot;
        public MyListWebUnitPlayback playbackGuard;
        public MyListPersistentView view;
        public int expectedStaticCount = -1;
        [System.NonSerialized] public MyListStore store;
        [System.NonSerialized] public int snapshotPlaylistId = -1;
        // Canonical identity of every snapshot track, in snapshot order (playing-mark safety check).
        [System.NonSerialized] public string[] snapshotKeys = new string[0];
        [System.NonSerialized] public int slotIndex = -1;
        [System.NonSerialized] public string status = "Not initialized";
        [System.NonSerialized] public int observedStoreVersion = -1;
        private bool runtimeStarted;

        private void Start() { runtimeStarted = true; SendCustomEventDelayedFrames(nameof(RegisterSlot), 2); }

        public void RegisterSlot()
        {
            if (!runtimeStarted) { status = "Runtime registration only"; return; }
            if (controller == null || slot == null) { status = "YamaPlayer / slot missing"; return; }
            if (slotIndex >= 0) return;
            Playlist[] existing = (Playlist[])controller.GetProgramVariable("_playlists");
            if (existing == null) existing = new Playlist[0];
            for (int i = 0; i < existing.Length; i++)
            {
                if (existing[i] == slot)
                {
                    if (i != expectedStaticCount || existing.Length != expectedStaticCount + 1)
                    { status = "Registration position mismatch"; slotIndex = -1; return; }
                    slotIndex = i; status = "Registered"; NotifyRegistered(); return;
                }
                if (existing[i] != null && existing[i].gameObject.name == "DM_PERSISTENT_PLAYBACK_SLOT")
                { status = "Another DM slot already registered"; return; }
            }
            if (existing.Length != expectedStaticCount)
            { status = "Static playlist count mismatch; registration refused"; return; }
            Playlist[] dynamicLists = (Playlist[])controller.GetProgramVariable("_dynamicPlaylists");
            if (dynamicLists != null && dynamicLists.Length > 0)
            { status = "Dynamic playlists already initialized; registration refused"; return; }
            Playlist[] extended = new Playlist[existing.Length + 1];
            for (int i = 0; i < existing.Length; i++) extended[i] = existing[i];
            extended[existing.Length] = slot;
            controller.SetProgramVariable("_playlists", extended);
            slotIndex = existing.Length;
            status = "Registered";
            NotifyRegistered();
        }

        private void NotifyRegistered() { if (view != null) view.OnSlotRegistered(); }

        public void StoreChanged()
        {
            // Editing never mutates the currently playing snapshot.
            if (store != null) observedStoreVersion = store.dataVersion;
        }

        public bool CopySnapshot(int playlistId)
        {
            if (store == null || !store.ready || store.corrupt || slot == null) return false;
            int list = store.PlaylistIndex(playlistId);
            if (list < 0 || store.savedUrls.Length != store.titles.Length ||
                store.savedUrls.Length != store.originals.Length || store.savedUrls.Length != store.players.Length ||
                store.savedUrls.Length != store.trackPlaylists.Length) return false;
            int count = 0;
            for (int i = 0; i < store.savedUrls.Length; i++) if (store.trackPlaylists[i] == playlistId) count++;
            string[] keys = new string[count];
            // Called only when a new playback begins, never from StoreChanged.
            slot.Tracks.Clear();
            int n = 0;
            for (int i = 0; i < store.savedUrls.Length; i++)
            {
                if (store.trackPlaylists[i] != playlistId) continue;
                // A fresh Track per copy: the snapshot never shares mutable Store data.
                slot.Tracks.Add(Track.New((VideoPlayerType)store.players[i], store.titles[i],
                    store.savedUrls[i], store.originals[i]));
                keys[n++] = MyListCodec.TrackKey(store.savedUrls[i], store.originals[i]);
            }
            slot.SetProgramVariable("_playlistName", store.playlistNames[list]);
            snapshotPlaylistId = playlistId;
            snapshotKeys = keys;
            observedStoreVersion = store.dataVersion;
            return true;
        }

        // Starts native playback of the saved track at Store data index `dataIndex`.
        public bool PlaySavedTrack(int dataIndex)
        {
            if (store == null || !store.Editable() || dataIndex < 0 || dataIndex >= store.savedUrls.Length) return false;
            RegisterSlot();
            if (slotIndex < 0) return false;
            if ((int)controller.PlayerPermission < (int)PlayerPermission.Editor || controller.IsLocal)
            { status = "Native autoplay requires an unlocked, non-local Controller"; return false; }
            Track selected = Track.New((VideoPlayerType)store.players[dataIndex], store.titles[dataIndex],
                store.savedUrls[dataIndex], store.originals[dataIndex]);
            if (playbackGuard != null)
            { if (!playbackGuard.CanPlay(selected)) return false; }
            else if (VRCUrl.IsNullOrEmpty(selected.GetVRCUrl()))
            { status = "WebUnit playback guard required"; return false; }
            int playlistId = store.trackPlaylists[dataIndex];
            int index = 0;
            for (int i = 0; i < dataIndex; i++) if (store.trackPlaylists[i] == playlistId) index++;
            slot.TakeOwnership();
            controller.TakeOwnership();
            if (!Networking.IsOwner(slot.gameObject) || !Networking.IsOwner(controller.gameObject))
            { status = "Ownership not acquired"; return false; }
            if (!CopySnapshot(playlistId)) return false;
            slot.SendEvent();
            controller.PlayTrack(slot, index);
            status = "Native playback requested";
            return true;
        }
    }
}
