namespace DM.YamaMyList
{
    // F1b "play again" (Docs/F1B_PLAY_AGAIN_SPEC.md): the pure rules of its state machine and of the press check.
    // No Unity, no Udon state, no network: MyListPersistentView keeps the state and calls these, so the rules are
    // tested on their own (Tests/F1b). F1b is a manual rescue after a failed WebUnit playback; it does not fix the
    // cause (PLAYBACK-01) and never starts anything by itself.
    public static class MyListPlayAgainRules
    {
        // States (spec chapter 4)
        public const int Idle = 0;        // nothing shown
        public const int ArmWait = 1;     // failed, the button is shown but not yet pressable
        public const int Armed = 2;       // failed, the button can be pressed
        public const int Preparing = 3;   // pressed, waiting for start / error / no response
        public const int Exhausted = 4;   // pressed twice and still failed: no button

        // Provisional values (approved as provisional in Phase 2; review them after the real-client test).
        public const float ArmDelaySeconds = 3f;
        public const int MaxPresses = 2;
        public const float NoResponseSeconds = 30f;
        public const float WarningSeconds = 10f;
        // In-flight tracking of a DM request: poll the WebUnit Client every second, every 5 s after 120 s.
        public const float WatchFastSeconds = 1f;
        public const float WatchSlowSeconds = 5f;
        public const float WatchFastWindowSeconds = 120f;

        // Press check results (spec chapter 5). The order of the checks is the order of these values.
        public const int PressOk = 0;
        public const int PressNotArmed = 1;      // not in the Armed state (also: a second press while preparing)
        public const int PressLimit = 2;         // MaxPresses already used for this observed request
        public const int PressNotTarget = 3;     // the current track is not a WebUnit YouTube track (or WebUnit is missing)
        public const int PressLoading = 4;       // YamaPlayer is loading
        public const int PressPlaying = 5;       // YamaPlayer is playing
        public const int PressBusy = 6;          // the WebUnit Client is busy (the official Client would refuse silently)
        public const int PressPlayerType = 7;    // the player type differs from the track (would sync from the owner)
        public const int PressReload = 8;        // YamaPlayer's _isReload is still set (spec 5, check 8)
        public const int PressPermission = 9;    // the owner of the YamaPlayer without editor permission

        // The state after a target error (an error that the view already classified as a target).
        // Same rule from every state: with MaxPresses used it is Exhausted; otherwise Idle / Preparing arm a new
        // failure and the other states keep their state (a duplicate notice of the same failure).
        public static int OnTargetError(int state, int presses)
        {
            if (presses >= MaxPresses) return Exhausted;
            if (state == Idle || state == Preparing) return ArmWait;
            return state;
        }

        // The 3 s timer: ArmWait becomes Armed. Any other state is left alone.
        public static int OnArmTimer(int state)
        {
            return state == ArmWait ? Armed : state;
        }

        // The 30 s timer after a press: still preparing means no response.
        public static int OnNoResponseTimer(int state, int presses)
        {
            if (state != Preparing) return state;
            return presses >= MaxPresses ? Exhausted : Armed;
        }

        // A delayed event carries no arguments in Udon, so the view keeps one set of timer data per timer. The event
        // acts only when the request generation and the attempt are the ones the timer was made for, and its due
        // time has been reached (spec 4: an older event of the same timer could otherwise act early on newer data).
        public const int TimerStale = 0;   // made for another request / attempt: do nothing
        public const int TimerEarly = 1;   // the right timer, but before its due time: do nothing now, wait for the rest
        public const int TimerDue = 2;     // act

        public static int TimerCheck(int gen, int attempt, int timerGen, int timerAttempt, float now, float due)
        {
            if (gen != timerGen || attempt != timerAttempt) return TimerStale;
            return now >= due ? TimerDue : TimerEarly;
        }

        public static bool TimerValid(int gen, int attempt, int timerGen, int timerAttempt, float now, float due)
        {
            return TimerCheck(gen, attempt, timerGen, timerAttempt, now, due) == TimerDue;
        }

        // In-flight tracking (plan 3.1): the state of the WebUnit Client that took DM's request. Tracking ends only
        // when that Client was seen idle, or when it no longer exists (a destroyed Client can neither send nor finish
        // a request). A busy Client, or one whose state cannot be read, keeps it running; time never ends it.
        public const int ClientIdle = 0;
        public const int ClientBusy = 1;
        public const int ClientUnknown = 2;   // not readable (a build without WebUnit)
        public const int ClientGone = 3;      // no Client took the request, or the Client object was destroyed

        public static bool InFlightEnds(int clientState)
        {
            return clientState == ClientIdle || clientState == ClientGone;
        }

        // The refusal text while DM's previous request is open: "busy, try shortly" first; after the 120 s window,
        // "the previous request has not finished" (the Client may never finish, e.g. when it was disabled; F1b then
        // stays unavailable until it finishes or is gone, or the user rejoins. Spec 5, check 10).
        public static string BusyKey(bool previousOpen, float previousElapsed)
        {
            return previousOpen && previousElapsed >= WatchFastWindowSeconds ? "f1b_previous_open" : "webunit_busy";
        }

        // A press is refused like a busy Client while DM's previous request is not known to be finished: the Client
        // that took it is busy or unknown (e.g. the resolver now has another Client). Only one DM request at a time.
        public static bool PreviousRequestOpen(bool inFlight, int previousClientState)
        {
            return inFlight && !InFlightEnds(previousClientState);
        }

        // One pending delayed event per timer: a new due time never adds an event while one is pending. The pending
        // event always runs at or before the newest due time (every timer is set to "now + its fixed length"), sees
        // the newest timer data, and waits for the rest when early (so at most one event per timer is ever queued).
        public static bool NeedsSchedule(bool pending)
        {
            return !pending;
        }

        // Spec chapter 5. Nothing is called unless this returns PressOk.
        public static int CheckPress(int state, int presses, bool target, bool loading, bool playing, bool clientBusy,
            bool playerTypeMatches, bool reload, bool owner, bool editor)
        {
            if (state != Armed) return PressNotArmed;
            if (presses >= MaxPresses) return PressLimit;
            if (!target) return PressNotTarget;
            if (loading) return PressLoading;
            if (playing) return PressPlaying;
            if (clientBusy) return PressBusy;
            if (!playerTypeMatches) return PressPlayerType;
            if (reload) return PressReload;
            if (owner && !editor) return PressPermission;
            return PressOk;
        }

        // The track part of "is this a F1b target" (spec chapter 3, condition 2): no VRCUrl, and an original URL in
        // the canonical YouTube watch form with a valid video ID. The same form MyListWebUnitPlayback.CanPlay accepts.
        public static bool IsYouTubeWithoutVrcUrl(bool vrcUrlEmpty, string original)
        {
            if (!vrcUrlEmpty || string.IsNullOrEmpty(original)) return false;
            if (!original.StartsWith("https://www.youtube.com/watch?v=")) return false;
            return MyListCodec.ValidVideoId(original.Substring(32).Split('&')[0]);
        }

        // What the panel shows (one value per kind of content; the view turns it into text in its own language).
        public const int ShowNothing = 0;
        public const int ShowArmWait = 1;
        public const int ShowArmed = 2;
        public const int ShowPreparing = 3;
        public const int ShowExhausted = 4;
        public const int ShowTrackChanged = 5;   // the warning after a track change while a DM request was in flight

        // A failure state always wins over the warning; the warning shows only while it is due and nothing else is.
        public static int Display(int state, bool warning)
        {
            if (state == ArmWait) return ShowArmWait;
            if (state == Armed) return ShowArmed;
            if (state == Preparing) return ShowPreparing;
            if (state == Exhausted) return ShowExhausted;
            return warning ? ShowTrackChanged : ShowNothing;
        }

        // The localization key for a refused press (shown in the panel until the state changes).
        public static string PressRefusalKey(int result)
        {
            if (result == PressBusy) return "webunit_busy";
            if (result == PressReload || result == PressPlayerType) return "f1b_not_ready";
            if (result == PressPermission) return "yama_locked";
            if (result == PressNotTarget) return "f1b_not_target";
            if (result == PressLoading || result == PressPlaying) return "f1b_already_loading";
            return "";
        }
    }
}
