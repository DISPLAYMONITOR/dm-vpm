namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;

    // One cell of the persistent track list; `index` is the visible position in the open playlist.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListNativeTrackRow : UdonSharpBehaviour
    {
        public MyListPersistentView owner;
        public int index;
        public void Play() { if (owner != null) owner.PlayPosition(index); }
        public void Queue() { if (owner != null) owner.QueuePosition(index); }
        public void PlayNext() { if (owner != null) owner.PlayNextPosition(index); }
        public void Up() { if (owner != null) owner.MovePosition(index, -1); }
        public void Down() { if (owner != null) owner.MovePosition(index, 1); }
        public void Remove() { if (owner != null) owner.RemovePosition(index); }
    }
}
