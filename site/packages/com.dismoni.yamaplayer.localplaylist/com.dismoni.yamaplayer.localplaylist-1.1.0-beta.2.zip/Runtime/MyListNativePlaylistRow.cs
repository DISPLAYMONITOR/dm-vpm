namespace DM.YamaMyList
{
    using UdonSharp;
    using UnityEngine;

    // A persistent playlist row. In YamaPlayer's playlist list it opens the playlist (index -1 =
    // "create"); in the destination chooser (`picker`) it selects the append target.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class MyListNativePlaylistRow : UdonSharpBehaviour
    {
        public MyListPersistentView owner;
        public int index;
        public bool picker;
        public void Open()
        {
            if (owner == null) return;
            if (picker) owner.PickTarget(index); else owner.OpenPlaylist(index);
        }
    }
}
