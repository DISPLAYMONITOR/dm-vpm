# NOTICE — DM YamaPlayer Local Playlist

© 2026 DISPLAY_MONITOR（第三者に属する部分を除きます）

## 利用条件 / Terms

利用条件は、同梱の **LICENSE.md**（利用規約。日本語版が正本）に従います。英語の参考訳は **LICENSE.en.md** です。
The terms of use are in **LICENSE.md** (Japanese, authoritative) and **LICENSE.en.md** (English reference translation).

正規の配布元 / Official source: `https://displaymonitor.github.io/dm-vpm/index.json`

## 一緒に使う第三者のソフトウェア（同梱していません）

このパッケージは、次のソフトウェアと一緒に使います。どのファイルもこのパッケージには含まれていません。VCC・ALCOM が各作者の配布元から導入します。それぞれの作者の規約・ライセンスに従って使ってください。このパッケージの作者は、これらのソフトウェアについて何も許諾しません。

- **YamaPlayer**（`net.kwxxw.yama-stream` 1.5.18）— やま@kwxxw 氏 — https://yamadev.booth.pm ／ 配布元 https://vpm.kwxxw.net/index.json
- **YamachanWebUnit**（`net.kwxxw.yamachan-web-unit` 1.1.0）— kwxxw 氏 — 配布元 https://vpm.kwxxw.net/index.json
- **VRChat SDK - Worlds**（3.10.5 以上）— VRChat Inc.

### YamaPlayer の UI について

`Prefabs/` の画面の行は、YamaPlayer の UI の行を元に作った構造です。YamaPlayer の画像・フォント・アニメーター・スクリプトを参照していますが、それらのファイル自体は含みません。

クレジット：**YamaPlayer — やま@kwxxw 氏（https://yamadev.booth.pm）**

### YamachanWebUnit について

このパッケージは、公式の YamachanWebUnit 1.1.0 で動作します。YamachanWebUnit のファイル（改変したものを含む）は含みません。

このパッケージの WebUnit の設定欄（Inspector・自動配置・セットアップ）には「DM Modified WebUnit v5.4 (PC)」という項目があります。ただし、その改変 Client は**このパッケージに同梱されていない**ため、選ぶことはできません。画面には「このパッケージには DM Modified WebUnit v5.4 は同梱されていません（Official YamachanWebUnit で動作します）。」と表示され、何も書き込みません。

## このパッケージの作者が作ったもの

- `Icons/` の 4 点は、このパッケージの作者が新たに作ったものです（既存の画像の加工ではありません）。
- `Runtime/*.asset` は、このパッケージのコードから UdonSharp が生成したデータです。
