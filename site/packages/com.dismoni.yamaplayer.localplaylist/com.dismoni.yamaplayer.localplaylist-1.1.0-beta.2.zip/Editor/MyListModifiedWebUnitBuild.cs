#if WEB_UNIT_INCLUDED
// DM Modified WebUnit build step (part of the release package; its self tests live in a development-only file).
// When the installed WebUnit Client is a verified DM modified revision, this gives the Client created by YamaPlayer's
// own build step its transport players B, C, ... (TransportPlayers - 1 of them): child objects of that Client, each with a copy of its
// VRCAVProVideoPlayer. With the official Client it does nothing. With anything else that carries the DM fields it
// stops the build: nothing is changed unless every check passes. If a later step fails, everything is put back
// (created objects removed, reused transport objects restored from a snapshot) and the result is compared with a
// fingerprint taken before the first change; the error says "nothing was changed" only when that comparison holds.
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Video.Components.AVPro;
using Yamadev.YamachanWebUnit;

namespace DM.YamaMyList.Editor
{
    public partial class MyListModifiedWebUnitBuild : IProcessSceneWithReport
    {
        // Total transport players (the Client's own player A included). Must match DmPlayerCount in the Client.
        public const int TransportPlayers = 11; // DM Modified WebUnit v5.4 (v5.2: 4)
        // An object directly under a WebUnit Client whose name is exactly this prefix plus one capital letter is owned
        // by this build step (it must then consist of Transform + VRCAVProVideoPlayer only, without children).
        // Nothing else is ever modified or removed.
        public const string OwnedPrefix = "DM_WebUnitTransport_";
        public const string RequiredWebUnitVersion = "1.1.0";
        public const int RequiredRevision = 6; // DM Modified WebUnit v5.4 (v5.2: 5)
        // RequiredRevision is compared with the Client's CODE revision (const DmBuildRevision, never stored in a scene).
        // The serialized DmRevision of each Client is the runtime contract of the playback code (>= 5) and may be an
        // older value saved with a scene-placed Client; it must lie in [MinimumRuntimeRevision, RequiredRevision].
        public const int MinimumRuntimeRevision = 5;
        const string OfficialSha256 = "57c6be2a92d2cb442d51acfc361cd49e9ef09a6d003258d2b7bb50b4e4ff7e7c";

        public int callbackOrder => 0; // after YamaPlayer (-10, creates WebUnitClient) and WebUnit (-1, fills Urls)

        public void OnProcessScene(Scene scene, BuildReport report)
        {
            // The platform of this build (a build report is not given when play mode starts in the editor).
            BuildTarget target = report != null ? report.summary.platform : EditorUserBuildSettings.activeBuildTarget;
            if (!IsPcTarget(target))
            {
                // PC extension only. On any other platform nothing here may stop the build.
                try { string skipped = ExcludeFromBuild(scene, target); if (skipped != null) Debug.Log("[DM Modified WebUnit] " + skipped); }
                catch (System.Exception ex) { Debug.LogWarning("[DM Modified WebUnit] not a Windows build; the PC transport players could not be checked: " + ex.Message); }
                return;
            }
            string result;
            try { result = Apply(scene); }
            catch (StepFailure ex)
            {
                if (ex.SceneUnchanged) throw new BuildFailedException("[DM Modified WebUnit] build stopped, nothing was changed: " + ex.Message);
                throw new BuildFailedException("[DM Modified WebUnit] build stopped AND THE SCENE COULD NOT BE FULLY RESTORED (discard this build's scene copy): " + ex.Message);
            }
            // Anything else comes from the gate or the planning phase, which change nothing.
            catch (System.Exception ex) { throw new BuildFailedException("[DM Modified WebUnit] build stopped, nothing was changed: " + ex.Message); }
            if (result != null) Debug.Log("[DM Modified WebUnit] " + result);
        }

        static string Sha256(string path)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return string.Concat(sha.ComputeHash(File.ReadAllBytes(path)).Select(b => b.ToString("x2")));
        }

        static string OwnedName(int index) { return OwnedPrefix + (char)('B' + index); }

        static bool IsOwnedName(string name)
        {
            return name.Length == OwnedPrefix.Length + 1 && name.StartsWith(OwnedPrefix) && name[name.Length - 1] >= 'A' && name[name.Length - 1] <= 'Z';
        }

        static bool OwnedShape(Transform t)
        {
            var components = t.GetComponents<Component>();
            return t.childCount == 0 && components.Length == 2 && components.All(c => c is Transform || c is VRCAVProVideoPlayer);
        }

        static List<string> SettingDifferences(VRCAVProVideoPlayer a, VRCAVProVideoPlayer b)
        {
            var differences = new List<string>();
            var sa = new SerializedObject(a); var sb = new SerializedObject(b);
            var it = sa.GetIterator();
            while (it.NextVisible(true))
            {
                if (it.propertyPath == "m_Script" || it.propertyType == SerializedPropertyType.Generic) continue;
                var other = sb.FindProperty(it.propertyPath);
                if (other == null || !SerializedProperty.DataEquals(it, other)) differences.Add(it.propertyPath);
            }
            return differences;
        }

        // A failure after the first change. SceneUnchanged is true only when the rollback ran without errors and the
        // fingerprint of every Client subtree equals the one taken before the first change.
        public class StepFailure : System.Exception
        {
            public readonly bool SceneUnchanged;
            public StepFailure(string message, bool sceneUnchanged, System.Exception inner) : base(message, inner) { SceneUnchanged = sceneUnchanged; }
        }

        // Failure injection for the development self test. Nothing in the release package sets it; it is always null.
        internal static System.Action<string> DevHook;

        static string Value(SerializedProperty p)
        {
            switch (p.propertyType)
            {
                case SerializedPropertyType.Integer: case SerializedPropertyType.LayerMask: case SerializedPropertyType.Character: case SerializedPropertyType.ArraySize: case SerializedPropertyType.Enum: return p.longValue.ToString();
                case SerializedPropertyType.Boolean: return p.boolValue ? "1" : "0";
                case SerializedPropertyType.Float: return p.doubleValue.ToString("R");
                case SerializedPropertyType.String: return p.stringValue;
                case SerializedPropertyType.ObjectReference: return "ref" + p.objectReferenceInstanceIDValue;
                case SerializedPropertyType.Color: return p.colorValue.ToString();
                case SerializedPropertyType.Vector2: return p.vector2Value.ToString("R");
                case SerializedPropertyType.Vector3: return p.vector3Value.ToString("R");
                case SerializedPropertyType.Vector4: return p.vector4Value.ToString("R");
                case SerializedPropertyType.Quaternion: return p.quaternionValue.ToString("R");
                case SerializedPropertyType.Rect: return p.rectValue.ToString();
                case SerializedPropertyType.Bounds: return p.boundsValue.ToString();
                default: return "(" + p.propertyType + ")";
            }
        }

        // Every serialized property (hidden ones included) of every object and component under `root`, read through
        // SerializedObject. Independent of the mechanism the rollback restores with (EditorJsonUtility).
        static void Fingerprint(Transform root, List<string> lines)
        {
            foreach (Transform t in root.GetComponentsInChildren<Transform>(true))
            {
                var targets = new List<Object> { t.gameObject };
                targets.AddRange(t.GetComponents<Component>().Where(c => c != null));
                foreach (Object target in targets)
                {
                    string head = t.name + "#" + t.gameObject.GetInstanceID() + "/" + target.GetType().Name + "#" + target.GetInstanceID() + " flags=" + (int)target.hideFlags + " ";
                    var it = new SerializedObject(target).GetIterator();
                    bool enter = true;
                    while (it.Next(enter))
                    {
                        enter = it.propertyType == SerializedPropertyType.Generic;
                        if (!enter) lines.Add(head + it.propertyPath + "=" + Value(it));
                    }
                }
            }
        }

        static List<string> Fingerprint(IEnumerable<Transform> roots)
        {
            var lines = new List<string>();
            foreach (Transform root in roots) Fingerprint(root, lines);
            return lines;
        }

        static string FirstDifferences(List<string> before, List<string> after)
        {
            var gone = before.Except(after).Take(3).ToArray(); var added = after.Except(before).Take(3).ToArray();
            return "lines " + before.Count + " -> " + after.Count + (gone.Length > 0 ? " | before only: " + string.Join(" ; ", gone) : "") + (added.Length > 0 ? " | after only: " + string.Join(" ; ", added) : "");
        }

        // State of a reused transport object before this step touches it.
        class Saved
        {
            readonly GameObject go; readonly VRCAVProVideoPlayer player; readonly string playerJson, name, tag;
            readonly bool active; readonly int layer, sibling; readonly HideFlags goFlags, playerFlags;
            readonly Transform parent; readonly Vector3 position, scale; readonly Quaternion rotation;

            public Saved(Transform t, VRCAVProVideoPlayer p)
            {
                go = t.gameObject; player = p; playerJson = EditorJsonUtility.ToJson(p); name = go.name; tag = go.tag;
                active = go.activeSelf; layer = go.layer; sibling = t.GetSiblingIndex(); goFlags = go.hideFlags; playerFlags = p.hideFlags;
                parent = t.parent; position = t.localPosition; rotation = t.localRotation; scale = t.localScale;
            }

            public void Restore()
            {
                DevHook?.Invoke("rollback");
                EditorJsonUtility.FromJsonOverwrite(playerJson, player);
                player.hideFlags = playerFlags;
                Transform t = go.transform;
                if (t.parent != parent) t.SetParent(parent, false);
                if (t.localPosition != position) t.localPosition = position;
                if (t.localRotation != rotation) t.localRotation = rotation;
                if (t.localScale != scale) t.localScale = scale;
                if (go.name != name) go.name = name;
                if (go.tag != tag) go.tag = tag;
                if (go.layer != layer) go.layer = layer;
                if (go.hideFlags != goFlags) go.hideFlags = goFlags;
                if (go.activeSelf != active) go.SetActive(active);
                if (t.GetSiblingIndex() != sibling) t.SetSiblingIndex(sibling);
            }

            public string Name => name;
        }

        // Compatibility gate. Returns null when the installed Client is the official one (this step then does nothing).
        // Throws when the Client carries DM fields but is not exactly what was verified.
        public static string Gate()
        {
            var script = MonoImporter.GetAllRuntimeMonoScripts().FirstOrDefault(s => s != null && s.GetClass() == typeof(Client));
            if (script == null) throw new System.Exception("the MonoScript of Yamadev.YamachanWebUnit.Client was not found");
            string path = AssetDatabase.GetAssetPath(script);
            string sha = Sha256(path);
            var extraField = typeof(Client).GetField("DmExtraPlayers");
            if (sha == OfficialSha256 || extraField == null) return null; // official (or a Client without DM fields): not ours to touch

            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(Client).Assembly);
            string version = package != null ? package.version : "not a package";
            if (version != RequiredWebUnitVersion) throw new System.Exception("YamachanWebUnit version is " + version + ", verified only with " + RequiredWebUnitVersion);
            if (!MyListModifiedWebUnitRevisions.Verified.Contains(sha))
                throw new System.Exception("Client.cs (" + path + ") sha256 " + sha + " is not a verified DM Modified WebUnit revision");
            if (extraField.FieldType != typeof(VRCAVProVideoPlayer[])) throw new System.Exception("Client.DmExtraPlayers is " + extraField.FieldType + ", expected VRCAVProVideoPlayer[]");
            var revisionField = typeof(Client).GetField("DmRevision");
            if (revisionField == null || revisionField.FieldType != typeof(int)) throw new System.Exception("Client.DmRevision (int) is missing");
            var replacementField = typeof(Client).GetField("DmRequestReplacement");
            if (replacementField == null || replacementField.FieldType != typeof(int)) throw new System.Exception("Client.DmRequestReplacement (int) is missing");
            // The installed Client code must state the revision this step was written for (v5.2 has no DmBuildRevision).
            var buildRevisionField = typeof(Client).GetField("DmBuildRevision", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            if (buildRevisionField == null || !buildRevisionField.IsLiteral || buildRevisionField.FieldType != typeof(int))
                throw new System.Exception("Client.DmBuildRevision (const int) is missing: the installed Client code is older than this build step (expected code revision " + RequiredRevision + "; update the DM Modified WebUnit)");
            int codeRevision = (int)buildRevisionField.GetRawConstantValue();
            if (codeRevision != RequiredRevision) throw new System.Exception("Client code revision (DmBuildRevision) is " + codeRevision + ", expected " + RequiredRevision);
            // The Client reads these two YamaPlayer variables (read-only) to drop a request whose track is no longer current.
            const System.Reflection.BindingFlags any = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic;
            if (typeof(Yamadev.YamaStream.Modules.VideoResolver).GetField("_controller", any) == null) throw new System.Exception("YamaPlayer VideoResolver._controller is missing (track check of the Client would not work)");
            var track = typeof(Yamadev.YamaStream.Controller).GetField("_track", any);
            if (track == null || track.FieldType != typeof(Yamadev.YamaStream.Track)) throw new System.Exception("YamaPlayer Controller._track (Track) is missing (track check of the Client would not work)");
            return "WebUnit " + version + " / Client sha256 " + sha;
        }

        // DM Modified WebUnit (TransportPlayers transport players) is a PC feature: it is built in for Windows only.
        public static bool IsPcTarget(BuildTarget target) { return target == BuildTarget.StandaloneWindows64; }

        // What a build for a platform decides: Windows -> Apply (gate, transport players B, C, ...);
        // any other platform -> ExcludeFromBuild (no gate, no transport players; the rest of the product is untouched).
        public static string ApplyFor(Scene scene, BuildTarget target) { return IsPcTarget(target) ? Apply(scene) : ExcludeFromBuild(scene, target); }

        // A build for another platform (Android / Quest, ...): no gate, nothing is created, and a missing or
        // different Client is not an error. Transport objects that are already in the scene being built (this
        // step's own objects, recognised by name and shape) are left out of that build; the saved scene is a
        // different object and is not changed. Returns null when there is no WebUnit Client with DM fields.
        public static string ExcludeFromBuild(Scene scene, BuildTarget target)
        {
            if (typeof(Client).GetField("DmExtraPlayers") == null) return null; // official Client: nothing of ours
            int removed = 0, clients = 0;
            foreach (Client client in Resources.FindObjectsOfTypeAll<Client>().Where(c => c.gameObject.scene == scene))
            {
                clients++;
                foreach (Transform child in client.transform.Cast<Transform>().ToArray())
                    if (IsOwnedName(child.name) && OwnedShape(child)) { Object.DestroyImmediate(child.gameObject); removed++; }
                var udon = client.GetComponent<UdonSharpBehaviour>();
                var current = udon != null ? udon.GetProgramVariable("DmExtraPlayers") as VRCAVProVideoPlayer[] : null;
                if (current != null && current.Length > 0) { udon.SetProgramVariable("DmExtraPlayers", new VRCAVProVideoPlayer[0]); }
            }
            return "build target " + target + ": PC feature not included (no DM transport players; WebUnit Clients in scene " + clients + ", transport objects left out of this build " + removed + ")";
        }

        // Applies the transport players to every WebUnit Client of the scene. Idempotent. Throws without changing
        // anything when a check fails. If a later step fails, a StepFailure is thrown after the rollback: created
        // objects are removed, DmExtraPlayers gets its previous value, and every reused transport object gets back
        // the state saved before it was touched (StepFailure.SceneUnchanged tells whether that fully worked).
        public static string Apply(Scene scene)
        {
            string gate = Gate();
            if (gate == null) return null;
            var clients = Resources.FindObjectsOfTypeAll<Client>().Where(c => c.gameObject.scene == scene).ToArray();
            if (clients.Length == 0) return gate + " / no WebUnit Client in scene " + scene.name;

            // 1. Checks and plan (no changes yet).
            var plans = new List<Plan>();
            foreach (Client client in clients)
            {
                var plan = new Plan { Client = client, Udon = client.GetComponent<UdonSharpBehaviour>() };
                if (UdonSharpEditorUtility.GetBackingUdonBehaviour(client) == null) throw new System.Exception("Client '" + client.name + "' has no Udon behaviour");
                object revision = plan.Udon.GetProgramVariable("DmRevision");
                // The code revision was checked in Gate(); the saved runtime value only has to be in range.
                if (!(revision is int) || (int)revision < MinimumRuntimeRevision || (int)revision > RequiredRevision) throw new System.Exception("Client '" + client.name + "' DmRevision is " + (revision ?? "null") + ", expected " + MinimumRuntimeRevision + ".." + RequiredRevision);
                var own = client.GetComponents<VRCAVProVideoPlayer>();
                if (own.Length != 1) throw new System.Exception("Client '" + client.name + "' has " + own.Length + " VRCAVProVideoPlayer components, expected 1");
                plan.A = own[0];
                if (!plan.A.enabled || !client.gameObject.activeInHierarchy) throw new System.Exception("transport player A of '" + client.name + "' is disabled or inactive");
                plan.Keep = new Transform[TransportPlayers - 1];
                foreach (Transform child in client.transform)
                {
                    if (!IsOwnedName(child.name)) continue; // not ours: never touched
                    if (!OwnedShape(child)) throw new System.Exception("'" + child.name + "' under '" + client.name + "' has a DM transport name but is not a DM transport object (expected only Transform + VRCAVProVideoPlayer, no children)");
                    int index = -1;
                    for (int i = 0; i < plan.Keep.Length; i++) if (child.name == OwnedName(i)) index = i;
                    if (index >= 0 && plan.Keep[index] == null) plan.Keep[index] = child;
                    else plan.Surplus.Add(child.gameObject); // a second copy, or a letter beyond the last transport player
                }
                plan.Before = plan.Udon.GetProgramVariable("DmExtraPlayers") as VRCAVProVideoPlayer[];
                plans.Add(plan);
            }

            // 2. Changes, undone on failure. Every transport object that may be reused is saved first.
            var created = new List<GameObject>();
            var saved = new List<Saved>();
            foreach (Plan plan in plans) foreach (Transform keep in plan.Keep) if (keep != null) saved.Add(new Saved(keep, keep.GetComponent<VRCAVProVideoPlayer>()));
            List<string> before = Fingerprint(plans.Select(p => p.Client.transform));
            try
            {
                foreach (Plan plan in plans)
                {
                    var players = new VRCAVProVideoPlayer[TransportPlayers - 1];
                    for (int i = 0; i < players.Length; i++)
                    {
                        if (plan.Keep[i] == null)
                        {
                            var go = new GameObject(OwnedName(i));
                            created.Add(go);
                            go.transform.SetParent(plan.Client.transform, false);
                            players[i] = go.AddComponent<VRCAVProVideoPlayer>();
                            plan.Created++;
                        }
                        else players[i] = plan.Keep[i].GetComponent<VRCAVProVideoPlayer>();
                        if (SettingDifferences(plan.A, players[i]).Count > 0) EditorUtility.CopySerialized(plan.A, players[i]);
                        if (!players[i].gameObject.activeSelf) players[i].gameObject.SetActive(true);
                        DevHook?.Invoke("copied:" + i);
                    }
                    plan.Touched = true;
                    plan.Udon.SetProgramVariable("DmExtraPlayers", players);
                    DevHook?.Invoke("stored");

                    // 3. Verify what the Client will see.
                    var stored = plan.Udon.GetProgramVariable("DmExtraPlayers") as VRCAVProVideoPlayer[];
                    if (stored == null || stored.Length != players.Length) throw new System.Exception("DmExtraPlayers of '" + plan.Client.name + "' was not stored");
                    for (int i = 0; i < players.Length; i++)
                    {
                        if (stored[i] == null || stored[i] != players[i]) throw new System.Exception("DmExtraPlayers[" + i + "] of '" + plan.Client.name + "' is not " + OwnedName(i));
                        if (!stored[i].enabled || !stored[i].gameObject.activeInHierarchy) throw new System.Exception(OwnedName(i) + " of '" + plan.Client.name + "' is disabled or inactive");
                        var differences = SettingDifferences(plan.A, stored[i]);
                        if (differences.Count > 0) throw new System.Exception(OwnedName(i) + " differs from transport player A: " + string.Join(", ", differences));
                    }
                    if (stored.Distinct().Count() != stored.Length || stored.Contains(plan.A)) throw new System.Exception("transport players of '" + plan.Client.name + "' are not " + TransportPlayers + " different players");
                }
            }
            catch (System.Exception primary)
            {
                // Rollback. Each part runs on its own so that one failing part neither stops the others nor hides
                // the primary failure; the result is then checked against the fingerprint taken before the changes.
                var problems = new List<string>();
                foreach (Plan plan in plans)
                {
                    if (!plan.Touched) continue;
                    try { plan.Udon.SetProgramVariable("DmExtraPlayers", plan.Before); }
                    catch (System.Exception ex) { problems.Add("DmExtraPlayers of '" + plan.Client.name + "': " + ex.Message); }
                }
                foreach (GameObject go in created)
                {
                    try { if (go != null) Object.DestroyImmediate(go); }
                    catch (System.Exception ex) { problems.Add("removing a created transport object: " + ex.Message); }
                }
                foreach (Saved s in saved)
                {
                    try { s.Restore(); }
                    catch (System.Exception ex) { problems.Add("restoring " + s.Name + ": " + ex.Message); }
                }
                try
                {
                    List<string> after = Fingerprint(plans.Select(p => p.Client.transform));
                    if (!before.SequenceEqual(after)) problems.Add("state after the rollback differs from the state before the step (" + FirstDifferences(before, after) + ")");
                }
                catch (System.Exception ex) { problems.Add("comparing the state after the rollback: " + ex.Message); }

                Debug.LogError("[DM Modified WebUnit] primary failure: " + primary);
                if (problems.Count == 0) throw new StepFailure(primary.Message, true, primary);
                foreach (string problem in problems) Debug.LogError("[DM Modified WebUnit] rollback failure: " + problem);
                throw new StepFailure(primary.Message + " | rollback failures: " + string.Join(" || ", problems), false, primary);
            }

            // 4. Only now remove surplus DM-owned objects (second copies, letters beyond the last transport player).
            int removed = 0;
            try { foreach (Plan plan in plans) foreach (GameObject go in plan.Surplus) { Object.DestroyImmediate(go); removed++; } }
            catch (System.Exception ex) { throw new StepFailure("the transport players are set up, but removing surplus DM transport objects failed after " + removed + ": " + ex.Message, false, ex); }
            return gate + " / clients " + plans.Count + " / transport players per client " + TransportPlayers + " / created " + plans.Sum(p => p.Created) + " / reused " + plans.Sum(p => p.Keep.Count(k => k != null)) + " / surplus removed " + removed;
        }

        class Plan
        {
            public Client Client; public UdonSharpBehaviour Udon; public VRCAVProVideoPlayer A;
            public Transform[] Keep; public List<GameObject> Surplus = new List<GameObject>();
            public VRCAVProVideoPlayer[] Before; public int Created; public bool Touched;
        }
    }
}
#endif
