// Where the add-on's own files are. They are found by asset GUID, never by a fixed folder, so the same code works
// when the add-on is installed by VCC (Packages/com.dismoni.yamaplayer.localplaylist) and from Assets/.
using System.IO;
using UnityEditor;
using UnityEngine;

namespace DM.YamaMyList.Editor
{
    public static class MyListPackagePaths
    {
        public const string PackageName = "com.dismoni.yamaplayer.localplaylist";
        public const string PrefabGuid = "bbb2fe26704b2d34faa72dc5f6bb3b9f";   // Prefabs/PersistentMyList.prefab
        public const string ReadmeGuid = "b6e31298af062744da7ea02967e1fdda";   // Documentation/README.md

        public const string ExtraPrefabGuid = "a8599608f4b461b42bc6b1ad8b06eaec";   // Prefabs/DM Local Playlist UI.prefab (additional screen)
        public static string PrefabPath { get { return AssetDatabase.GUIDToAssetPath(PrefabGuid); } }
        public static string ExtraPrefabPath { get { return AssetDatabase.GUIDToAssetPath(ExtraPrefabGuid); } }
        public static string ReadmePath { get { return AssetDatabase.GUIDToAssetPath(ReadmeGuid); } }

        // Asset path -> path usable with System.IO (a package may be stored outside the project's Packages folder).
        public static string Physical(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath) || !assetPath.StartsWith("Packages/")) return assetPath;
            var info = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(assetPath);
            if (info == null || string.IsNullOrEmpty(info.resolvedPath)) return assetPath;
            string rest = assetPath.Substring(("Packages/" + info.name).Length).TrimStart('/');
            return Path.Combine(info.resolvedPath, rest).Replace('\\', '/');
        }

        // "1.0.0" when installed as a package, "" from Assets/.
        public static string Version()
        {
            var info = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(PrefabPath ?? "");
            return info != null && info.name == PackageName ? info.version : "";
        }
    }
}
