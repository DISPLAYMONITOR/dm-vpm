using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DM.YamaMyList.Editor
{
    // Build-copy only. Keep every component and object, including unsynced Udon behaviours.
    public sealed class MyListAndroidBuild : IProcessSceneWithReport
    {
        public int callbackOrder => 1;

        public void OnProcessScene(Scene scene, BuildReport report)
        {
            var target = report == null ? EditorUserBuildSettings.activeBuildTarget : report.summary.platform;
            if (target != BuildTarget.Android) return; // iOS policy is deliberately not inferred here.
            Apply(scene);
        }

        public static int Apply(Scene scene)
        {
            int changed = 0;
            foreach (var view in Resources.FindObjectsOfTypeAll<MyListPersistentView>().Where(v => v.gameObject.scene == scene))
            {
                changed += Hide(view.createImportRow);
                changed += Hide(view.playlistUrlInput == null ? null : view.playlistUrlInput.gameObject);
                changed += Hide(view.retryPanel);
            }
            Debug.Log("[DM Quest] Android build copy: disabled UI objects=" + changed + "; no objects/components removed");
            return changed;
        }

        private static int Hide(GameObject go)
        {
            if (go == null || !go.activeSelf) return 0;
            go.SetActive(false);
            return 1;
        }
    }
}
