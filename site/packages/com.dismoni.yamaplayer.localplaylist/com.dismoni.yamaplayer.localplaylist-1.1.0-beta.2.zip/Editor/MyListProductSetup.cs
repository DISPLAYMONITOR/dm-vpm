using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UdonSharp;
using UdonSharpEditor;
using VRC.SDK3.Components;
using Yamadev.YamaStream;
using Yamadev.YamaStream.UI;
using Object = UnityEngine.Object;

namespace DM.YamaMyList.Editor
{
    // Zero Config: binds each placed DM Persistent MyList prefab to its YamaPlayer.
    // Writes ONLY fields of DM-owned objects; YamaPlayer objects are read, never modified. Every pass
    // compares a serialized snapshot of the YamaPlayer before/after (YAMAPLAYER_EXISTING_SERIALIZED_CHANGES = 0).
    [InitializeOnLoad]
    public class MyListProductSetup : IProcessSceneWithReport
    {
        public int callbackOrder => -100;
        static bool queued, configuring;
        public static bool SuppressAuto;
        public static string LastReport = "";

        static MyListProductSetup()
        {
            EditorApplication.hierarchyChanged += Queue;
            EditorSceneManager.sceneOpened += (scene, mode) => Queue();
        }

        static void Queue()
        {
            if (SuppressAuto || queued || EditorApplication.isPlayingOrWillChangePlaymode) return;
            queued = true;
            EditorApplication.delayCall += () =>
            {
                queued = false;
                if (SuppressAuto || EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) return;
                for (int i = 0; i < SceneManager.sceneCount; i++)
                {
                    var scene = SceneManager.GetSceneAt(i);
                    if (scene.isLoaded) ConfigureScene(scene);
                }
            };
        }

        public void OnProcessScene(Scene scene, BuildReport report) { ConfigureScene(scene); }

        public static Dictionary<Object, string> Capture(GameObject root)
        {
            var result = new Dictionary<Object, string>();
            foreach (Transform t in root.GetComponentsInChildren<Transform>(true))
            {
                result[t.gameObject] = EditorJsonUtility.ToJson(t.gameObject);
                foreach (Component c in t.GetComponents<Component>())
                    if (c) result[c] = EditorJsonUtility.ToJson(c);
            }
            return result;
        }

        public static List<string> Changes(Dictionary<Object, string> before)
        {
            var changes = new List<string>();
            foreach (var pair in before)
                if (!pair.Key) changes.Add("deleted object");
                else if (EditorJsonUtility.ToJson(pair.Key) != pair.Value) changes.Add(pair.Key.name + " / " + pair.Key.GetType().Name);
            return changes;
        }

        // An additional UI (the "DM Local Playlist UI" prefab): the view and the UI kit only. It has no Store and no
        // playback objects of its own; it shares those of the PersistentMyList of the same YamaPlayer.
        public static bool IsExtra(MyListPersistentView view) { return view && !view.GetComponentInChildren<MyListStore>(true); }

        // The object a screen with its own controls was placed as (YamaPlayer's SubScreen, a tablet controller ...):
        // the outermost prefab instance around its UIController, or the UIController's own object.
        public static GameObject ScreenRoot(UIController ui)
        {
            if (!ui) return null;
            var root = PrefabUtility.GetOutermostPrefabInstanceRoot(ui.gameObject);
            return root ? root : ui.gameObject;
        }

        // False for anything below an object tagged EditorOnly: Unity leaves those out of the build, so a YamaPlayer
        // there (for example a tablet's built-in player that was switched off in favour of a controller app) is not
        // one the world will have.
        public static bool InBuild(Component c)
        {
            for (Transform t = c ? c.transform : null; t; t = t.parent) if (t.CompareTag("EditorOnly")) return false;
            return c;
        }

        public static Controller ControllerOf(UIController ui)
        {
            return ui ? new SerializedObject(ui).FindProperty("_controller")?.objectReferenceValue as Controller : null;
        }

        // The UIController of the YamaPlayer's own screen: the one inside the YamaPlayer object. (Other UIControllers
        // may point at the same Controller: every additional screen has one.)
        public static UIController OwnUi(Controller target, GameObject[] roots)
        {
            var all = roots.SelectMany(r => r.GetComponentsInChildren<UIController>(true)).Where(c => ControllerOf(c) == target).ToArray();
            GameObject yama = YamaRoot(target);
            var inside = all.FirstOrDefault(c => c.transform.IsChildOf(yama.transform));
            return inside ? inside : all.FirstOrDefault();
        }

        // The screen a PersistentMyList serves. A connection that exists and is valid (a UIController of this
        // Controller, in the same scene) is kept as it is: a scene set up with an earlier version is never moved to
        // another screen by an update. Only without one the YamaPlayer's own screen is taken.
        public static UIController MainUi(MyListPersistentView view, Controller target, GameObject[] roots)
        {
            if (view && view.yamaUI && view.yamaUI.gameObject.scene == target.gameObject.scene && ControllerOf(view.yamaUI) == target) return view.yamaUI;
            return OwnUi(target, roots);
        }

        public static GameObject YamaRoot(Controller controller)
        {
            var yama = controller.GetComponentInParent<Yamadev.YamaStream.Script.YamaPlayer>();
            return yama ? yama.gameObject : controller.transform.root.gameObject;
        }

        // Dry run of ConfigureScene: the fields it would write ("Object.field: old -> new"). Nothing is written.
        static List<string> preview;
        public static string[] Preview(Scene scene)
        {
            if (configuring) return new string[0];
            string keep = LastReport;
            preview = new List<string>();
            try { ConfigureScene(scene); return preview.Distinct().ToArray(); }
            finally { preview = null; LastReport = keep; }
        }

        // ---- YamaPlayer compatibility gate: checked BEFORE anything is connected ----
        public const string Verified = "VERIFIED", NotVerified = "NOT VERIFIED";
        const string AllowKey = "DM.YamaPlayer.LocalPlaylist.AllowUnverifiedYamaPlayer:";
        static DM.YamaMyList.Compatibility.MyListCompatibilityReport compatibility;
        static string warnedBlock = "";
        // Set only by the product checks (through reflection) to stand in for another installed YamaPlayer.
        static Func<DM.YamaMyList.Compatibility.MyListCompatibilityReport> compatibilityForChecks;

        // The contract result for the installed YamaPlayer (checked once per script reload; refresh = check again now).
        public static DM.YamaMyList.Compatibility.MyListCompatibilityReport Compatibility(bool refresh = false)
        {
            if (compatibilityForChecks != null) return compatibilityForChecks();
            if (compatibility == null || refresh) compatibility = DM.YamaMyList.Compatibility.MyListCompatibility.Run();
            return compatibility;
        }

        // An unverified YamaPlayer version (contract holds, version not in the list) is connected only after the user
        // said so in Auto Setup, for this project and exactly that version.
        public static bool UnverifiedAllowed(string version) { return EditorPrefs.GetBool(AllowKey + Application.dataPath + ":" + version, false); }
        public static void AllowUnverified(string version, bool allow)
        {
            if (allow) EditorPrefs.SetBool(AllowKey + Application.dataPath + ":" + version, true);
            else EditorPrefs.DeleteKey(AllowKey + Application.dataPath + ":" + version);
        }

        // "" when connecting is allowed; otherwise the reason. Nothing is written when this is not "".
        public static string CompatibilityBlock()
        {
            var c = Compatibility();
            if (c.Status == Verified) return "";
            if (c.Status == NotVerified) return UnverifiedAllowed(c.YamaPlayerVersion) ? "" : "UNVERIFIED_YAMAPLAYER " + c.YamaPlayerVersion;
            return "INCOMPATIBLE_YAMAPLAYER " + c.YamaPlayerVersion + (c.Failed.Count > 0 ? ": " + string.Join("; ", c.Failed.Take(5)) : "");
        }

        // True while an explicit Auto Setup run is writing: its changes are then recorded for Undo.
        public static bool RecordUndo;
        public const string UndoName = "DM YamaPlayer Local Playlist: Auto Setup";

        public static string ConfigureScene(Scene scene)
        {
            // Edit-time binding is serialized with the scene; play-mode scene loads need no rebinding.
            if (configuring || !scene.IsValid() || !scene.isLoaded || Application.isPlaying) return "";
            configuring = true;
            var report = new List<string>();
            try
            {
                var roots = scene.GetRootGameObjects();
                var allViews = roots.SelectMany(r => r.GetComponentsInChildren<MyListPersistentView>(true)).ToArray();
                if (allViews.Length == 0) return "";
                var views = allViews.Where(v => !IsExtra(v)).ToArray();
                var extras = allViews.Where(IsExtra).ToArray();
                string block = CompatibilityBlock();
                if (block != "")
                {
                    // contract not met, or an unverified version the user has not accepted: nothing is connected or changed
                    if (preview == null && warnedBlock != block)
                    {
                        warnedBlock = block;
                        Debug.LogWarning("[DM MyList] Not connected: " + block + ". Run Tools > DIS_MONI Tools > DM YamaPlayer Local Playlist > 自動配置・セットアップ (Auto Setup) for details.");
                    }
                    LastReport = block;
                    return block;
                }
                var controllers = roots.SelectMany(r => r.GetComponentsInChildren<Controller>(true)).Where(InBuild).ToArray();
                var claimed = new HashSet<Controller>();
                foreach (var view in views.OrderBy(v => v.targetYamaPlayer ? 0 : 1).ThenBy(v => Path(v.transform), StringComparer.Ordinal))
                {
                    Controller target = null;
                    if (view.targetYamaPlayer) target = view.targetYamaPlayer.GetComponentInChildren<Controller>(true);
                    else
                    {
                        var free = controllers.Where(c => !claimed.Contains(c)).ToArray();
                        if (free.Length > 1)
                            Debug.LogWarning("[DM MyList] Several YamaPlayers found; binding the nearest one. Set 'Target Yama Player' on " + view.name + " to choose explicitly.", view);
                        target = free.OrderBy(c => (YamaRoot(c).transform.position - view.transform.position).sqrMagnitude)
                            .ThenBy(c => Path(c.transform), StringComparer.Ordinal).FirstOrDefault();
                    }
                    if (!target) { report.Add("NO_TARGET " + Path(view.transform)); Debug.LogWarning("[DM MyList] No YamaPlayer found for " + view.name, view); continue; }
                    if (!claimed.Add(target)) { report.Add("TARGET_ALREADY_CLAIMED " + Path(view.transform)); Debug.LogError("[DM MyList] Two DM addons target the same YamaPlayer.", view); continue; }
                    var before = Capture(YamaRoot(target));
                    string result = Bind(view, target, roots);
                    var changes = Changes(before);
                    if (changes.Count > 0)
                        throw new InvalidOperationException("YAMAPLAYER_EXISTING_SERIALIZED_CHANGES=" + changes.Count + ": " + string.Join(", ", changes.Take(10)));
                    report.Add(result + " TARGET=" + Path(target.transform));
                }
                ConfigureExtras(views, extras, roots, report);
            }
            finally { configuring = false; }
            LastReport = string.Join("\n", report);
            return LastReport;
        }

        // Additional UIs: each is connected to the UIController of its screen and to the PersistentMyList of the
        // YamaPlayer that screen controls. Only DM objects are written; the screen and the YamaPlayer are compared
        // before / after like the YamaPlayer itself.
        static void ConfigureExtras(MyListPersistentView[] primaries, MyListPersistentView[] extras, GameObject[] roots, List<string> report)
        {
            var perPrimary = primaries.ToDictionary(p => p, p => new List<MyListPersistentView>());
            var claimed = new HashSet<UIController>(primaries.Where(p => p.yamaUI).Select(p => p.yamaUI));
            // A UI that is already connected keeps its screen; a later duplicate for the same screen is the one refused.
            foreach (var extra in extras.OrderBy(v => v.primary && v.yamaUI ? 0 : 1).ThenBy(v => Path(v.transform), StringComparer.Ordinal))
            {
                var ui = extra.targetScreen ? extra.targetScreen.GetComponentInChildren<UIController>(true) : null;
                if (!ui) { report.Add("NO_SCREEN " + Path(extra.transform)); Debug.LogWarning("[DM MyList] '" + extra.name + "': set 'Target Screen' to the screen (an object with a YamaPlayer UIController) this UI belongs to.", extra); continue; }
                Controller target = ControllerOf(ui);
                var primary = target ? primaries.FirstOrDefault(p => p.controller == target) : null;
                if (!primary) { report.Add("NO_PRIMARY " + Path(extra.transform)); Debug.LogWarning("[DM MyList] '" + extra.name + "': the YamaPlayer of this screen has no DM Persistent MyList. Run Auto Setup first.", extra); continue; }
                if (!claimed.Add(ui)) { report.Add("SCREEN_ALREADY_HAS_UI " + Path(extra.transform)); Debug.LogError("[DM MyList] Two DM UIs target the same screen (" + Path(ui.transform) + ").", extra); continue; }
                var before = Capture(YamaRoot(target));
                GameObject screen = ScreenRoot(ui);
                var beforeScreen = screen && !screen.transform.IsChildOf(YamaRoot(target).transform) ? Capture(screen) : new Dictionary<Object, string>();
                string result = BindUi(extra, target, ui, roots);
                if (result != "UNSUPPORTED_UI")
                {
                    bool changed = Set(extra, "primary", primary);
                    if (changed && preview == null) EditorSceneManager.MarkSceneDirty(extra.gameObject.scene);
                    if (changed) result = "BOUND";
                    perPrimary[primary].Add(extra);
                }
                var changes = Changes(before).Concat(Changes(beforeScreen)).ToList();
                if (changes.Count > 0)
                    throw new InvalidOperationException("YAMAPLAYER_EXISTING_SERIALIZED_CHANGES=" + changes.Count + ": " + string.Join(", ", changes.Take(10)));
                report.Add(result + " SCREEN=" + Path(ui.transform));
            }
            foreach (var pair in perPrimary)
                if (SetArray(pair.Key, "extraViews", pair.Value.Cast<Object>().ToArray()) && preview == null) EditorSceneManager.MarkSceneDirty(pair.Key.gameObject.scene);
        }

        static string Bind(MyListPersistentView view, Controller target, GameObject[] roots)
        {
            var ui = MainUi(view, target, roots);
            if (!ui) { Debug.LogWarning("[DM MyList] YamaPlayer ScreenUI (UIController) not found for " + Path(target.transform), view); return "NO_UI"; }
            string result = BindUi(view, target, ui, roots);
            if (result == "UNSUPPORTED_UI") return result;
            bool changed = false;
            if (view.adapter)
            {
                changed |= Set(view.adapter, "controller", target);
                string countNote;
                int staticCount = StaticPlaylistCount(target, out countNote);
                if (countNote != "" && preview == null && warnedCount != countNote) { warnedCount = countNote; Debug.LogWarning("[DM MyList] " + countNote, view); }
                changed |= SetInt(view.adapter, "expectedStaticCount", staticCount);
                if (view.adapter.slot) changed |= Set(view.adapter.slot, "_controller", target);
            }
            if (view.playbackGuard)
            {
                changed |= Set(view.playbackGuard, "controller", target);
                changed |= Set(view.playbackGuard, "resolver", roots.SelectMany(r => r.GetComponentsInChildren<Yamadev.YamaStream.Modules.VideoResolver>(true))
                    .FirstOrDefault(r => new SerializedObject(r).FindProperty("_controller")?.objectReferenceValue == target));
            }
            if (changed && preview == null) EditorSceneManager.MarkSceneDirty(view.gameObject.scene);
            return changed ? "BOUND" : result;
        }

        // The references into one screen UI (the YamaPlayer's own, or an additional screen's).
        static string BindUi(MyListPersistentView view, Controller target, UIController ui, GameObject[] roots)
        {
            var uiSo = new SerializedObject(ui);
            var lists = uiSo.FindProperty("_playlists")?.objectReferenceValue as LoopScroll;
            var tracks = uiSo.FindProperty("_playlistTracks")?.objectReferenceValue as LoopScroll;
            var name = uiSo.FindProperty("_playlistName")?.objectReferenceValue as Text;
            var tabs = uiSo.FindProperty("_playlistSelector")?.objectReferenceValue as Transform;
            var canvas = ui.transform.Find("Canvas");
            var modal = canvas ? canvas.Find("Modal")?.GetComponent<Modal>() : null;
            var control = canvas ? canvas.Find("Control")?.GetComponent<Animator>() : null;
            if (!lists || !tracks || !name || !tabs || !modal)
            { Debug.LogWarning("[DM MyList] Unsupported YamaPlayer UI layout (expected YamaPlayer 1.5.18).", view); return "UNSUPPORTED_UI"; }
            var toggles = tabs.GetComponentsInChildren<Toggle>(true);
            var videoInfo = roots.SelectMany(r => r.GetComponentsInChildren<VideoInfo>(true))
                .FirstOrDefault(v => new SerializedObject(v).FindProperty("_controller")?.objectReferenceValue == target);

            bool changed = false;
            changed |= Set(view, "controller", target);
            changed |= Set(view, "yamaUI", ui);
            changed |= Set(view, "modal", modal);
            changed |= Set(view, "videoInfo", videoInfo);
            changed |= Set(view, "nativePlaylists", lists);
            changed |= Set(view, "nativeTracks", tracks.gameObject);
            changed |= Set(view, "nativeName", name);
            changed |= Set(view, "nativeInfo", name.transform.parent);
            changed |= Set(view, "controlAnimator", control);
            changed |= Set(view, "queueTab", toggles.Length > 0 ? toggles[0] : null);
            changed |= Set(view, "historyTab", toggles.Length > 1 ? toggles[1] : null);
            changed |= Set(view, "playlistTab", toggles.Length > 2 ? toggles[2] : null);
            changed |= Set(view, "nativeAddPlaylistRow", lists.GetComponent<ScrollRect>().content.Find("AddPlaylist"));
            changed |= Set(view, "modalContent", modal.transform.Find("Scroll View/Viewport/Content"));
            // YamaPlayer's Back / Play / Stop / Next group; null on another layout (the seek buttons then stay hidden).
            changed |= Set(view, "nativeTransport", canvas.Find("Control/Main/Bottom/Actions"));
            // F1b "play again": the parent of YamaPlayer's error panel (_loading), when it is the UI Toggle of the
            // 1.5.18 layout. Otherwise F1b is not used on this screen (a warning; everything else is set up as usual).
            var loading = uiSo.FindProperty("_loading")?.objectReferenceValue as GameObject;
            var retryHost = loading && loading.transform.parent && loading.transform.parent.GetComponent<Toggle>() ? loading.transform.parent : null;
            changed |= Set(view, "retryHost", retryHost);
            if (!retryHost && preview == null && warnedRetry.Add(view.GetInstanceID()))
                Debug.LogWarning("[DM MyList] F1b (play again) is not available on this screen: YamaPlayer's error panel was not found where 1.5.18 has it.", view);
            // YamaPlayer's build step fills UIColor._uiController only under its own UIController;
            // DM copies are moved there at runtime, so they are given the same reference here.
            foreach (var color in view.GetComponentsInChildren<UIColor>(true)) changed |= Set(color, "_uiController", ui);
            if (changed && preview == null) EditorSceneManager.MarkSceneDirty(view.gameObject.scene);
            return changed ? "BOUND" : "UNCHANGED";
        }

        static string warnedCount = "";
        static readonly System.Collections.Generic.HashSet<int> warnedRetry = new System.Collections.Generic.HashSet<int>();

        // The number of static playlists the Controller will have at runtime (what the adapter's slot registration
        // compares with). Controller._playlists is empty in the editor: YamaPlayer 1.5.18 fills it in its build step
        // (PlaylistBuildProcess, callbackOrder -100, the same order as this setup, which Unity may call first). So the
        // entries are counted here by that step's own rule, which gives the same number before and after it ran:
        //   - every PlayListContainer of a saved scene; its YamaPlayer is the one above it, its Controller that
        //     YamaPlayer's first active Controller;
        //   - one playlist for every child of the container from the second child on whose GameObject is active
        //     (activeSelf); the first child is not an entry.
        // Without a container for this Controller the serialized array is what the runtime gets. Several containers
        // with different numbers for one Controller cannot be predicted: -1 is returned, and the runtime then refuses
        // to register the slot (nothing is guessed). Nothing of YamaPlayer is written here.
        public static int StaticPlaylistCount(Controller target, out string note)
        {
            note = "";
            int serialized = new SerializedObject(target).FindProperty("_playlists").arraySize;
            var counts = new List<int>();
            foreach (var container in Resources.FindObjectsOfTypeAll<Yamadev.YamaStream.Script.PlayListContainer>())
            {
                if (container.gameObject.scene != target.gameObject.scene) continue;
                if (!AssetDatabase.GetAssetOrScenePath(container).Contains(".unity")) continue;   // the build step takes saved scenes only
                var yama = container.GetComponentInParent<Yamadev.YamaStream.Script.YamaPlayer>(true);
                if (!yama || yama.GetComponentInChildren<Controller>() != target) continue;
                int count = 0;
                for (int i = 1; i < container.transform.childCount; i++)
                    if (container.transform.GetChild(i).gameObject.activeSelf) count++;
                counts.Add(count);
            }
            if (counts.Count == 0) return serialized;
            if (counts.Distinct().Count() > 1)
            {
                note = "The YamaPlayer '" + YamaRoot(target).name + "' has " + counts.Count + " PlayListContainers with different numbers of playlists (" + string.Join(", ", counts) +
                    "). The number of its playlists at runtime cannot be predicted, so DM playback will not start (the playback slot is not registered). Keep one PlayListContainer per YamaPlayer.";
                return -1;
            }
            return counts[0];
        }

        static bool Set(Object target, string field, Object value)
        {
            var so = new SerializedObject(target);
            var p = so.FindProperty(field);
            if (p == null) throw new InvalidOperationException("Field not found: " + target.GetType().Name + "." + field);
            if (p.objectReferenceValue == value) return false;
            if (preview != null) { preview.Add(target.name + "." + field + ": " + Name(p.objectReferenceValue) + " -> " + Name(value)); return true; }
            RecordForUndo(target);
            p.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
            Commit(target);
            return true;
        }

        static bool SetArray(Object target, string field, Object[] values)
        {
            var so = new SerializedObject(target);
            var p = so.FindProperty(field);
            if (p == null) throw new InvalidOperationException("Field not found: " + target.GetType().Name + "." + field);
            bool same = p.arraySize == values.Length;
            for (int i = 0; same && i < values.Length; i++) same = p.GetArrayElementAtIndex(i).objectReferenceValue == values[i];
            if (same) return false;
            if (preview != null) { preview.Add(target.name + "." + field + ": " + p.arraySize + " -> " + values.Length + " object(s)"); return true; }
            RecordForUndo(target);
            p.arraySize = values.Length;
            for (int i = 0; i < values.Length; i++) p.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
            so.ApplyModifiedPropertiesWithoutUndo();
            Commit(target);
            return true;
        }

        static bool SetInt(Object target, string field, int value)
        {
            var so = new SerializedObject(target);
            var p = so.FindProperty(field);
            if (p == null) throw new InvalidOperationException("Field not found: " + target.GetType().Name + "." + field);
            if (p.intValue == value) return false;
            if (preview != null) { preview.Add(target.name + "." + field + ": " + p.intValue + " -> " + value); return true; }
            RecordForUndo(target);
            p.intValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
            Commit(target);
            return true;
        }

        static string Name(Object o) { return o ? o.name : "(none)"; }

        // Before a field of a DM object is written in an explicit run: the object and, for a U# behaviour, the
        // UdonBehaviour behind it are recorded, so that one Undo puts both back.
        static void RecordForUndo(Object target)
        {
            if (!RecordUndo) return;
            Undo.RecordObject(target, UndoName);
            if (target is UdonSharpBehaviour behaviour)
            {
                var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(behaviour);
                if (backing) Undo.RecordObject(backing, UndoName);
            }
        }

        static void Commit(Object target)
        {
            if (target is UdonSharpBehaviour behaviour) UdonSharpEditorUtility.CopyProxyToUdon(behaviour);
            EditorUtility.SetDirty(target);
            PrefabUtility.RecordPrefabInstancePropertyModifications(target);
            if (target is UdonSharpBehaviour u)
            {
                var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(u);
                if (backing) { EditorUtility.SetDirty(backing); PrefabUtility.RecordPrefabInstancePropertyModifications(backing); }
            }
        }

        public static string Path(Transform t) => t.parent ? Path(t.parent) + "/" + t.name : t.name;
    }
}
