// Inspector of the PersistentMyList prefab (MyListPersistentView): a "WebUnit" section on top of the normal fields.
// The WebUnit Client is one file of the project, so this section shows the state of the PROJECT and is the same on
// every PersistentMyList in every scene. Nothing here is stored in the prefab. It only reads the state; the Client
// is replaced only by the buttons (through MyListWebUnitInstaller, the same functions the Tools menu calls).
using UdonSharpEditor;
using UnityEditor;
using UnityEngine;

namespace DM.YamaMyList.Editor
{
    // What the WebUnit section says for one project state. Plain data, so that it can be checked without a window.
    public struct MyListWebUnitSummary
    {
        public MyListWebUnitInstaller.State State;
        public bool Modified;          // which of the two radio buttons is on (false also for "no / unsupported WebUnit")
        public string Current;         // "Official YamachanWebUnit 1.1.0" / "DM Modified WebUnit v5.4" / "DM Modified WebUnit (older revision)" / "Unknown / Unsupported"
        public string Status;          // "" / UP TO DATE / UPDATE AVAILABLE / UNKNOWN / REPAIR REQUIRED / ...
        public string PcExtension;     // Disabled / Ready / Not included on Android builds / ...
        public bool CanInstall, CanUpdate, CanRestore;
        public bool Payload;           // the DM Client is shipped with this build of the add-on
        public MessageType Level;
    }

    public static class MyListWebUnitSetup
    {
        public const string ProjectWideNote = "WebUnitの選択はこのUnityプロジェクト全体に適用されます。\nThe WebUnit choice applies to this whole Unity project.";

        // What an Android build contains, exactly. Shown by Auto Setup, the Inspector and the WebUnit warning.
        public const string AndroidNoteJa = "Android 向けビルドでは、PC 専用の追加 Transport（B〜K）および PC 向け再生改善処理は有効になりません。" +
            "ただし、DM Modified WebUnit を導入済みの場合、改変 Client のプログラム自体は Android ビルドに含まれます。Quest / Android での動作は未検証です。";
        public const string AndroidNoteEn = "In Android builds the PC-only extra transports (B..K) and the PC playback improvement are not active. " +
            "If the DM Modified WebUnit is installed, the modified Client program itself is still part of the Android build. Quest / Android is not verified.";
        public const string AndroidNote = AndroidNoteJa + "\n" + AndroidNoteEn;

        public const string Compiling = "compiling"; // gateError value: the new Client is on disk but not compiled yet

        // Pure rule: project state + build target -> what is shown. gateError: "" when the build check accepts the
        // installed Client (asked only for a current DM Client on a Windows target).
        public static MyListWebUnitSummary Describe(MyListWebUnitInstaller.State state, bool current, BuildTarget target, string gateError)
        {
            return Describe(state, current, target, gateError, true);
        }

        public const string NotIncludedNote = "このパッケージには DM Modified WebUnit v5.4 は同梱されていません（Official YamachanWebUnit で動作します）。\nThis package does not include the DM Modified WebUnit v5.4 (it works with the official YamachanWebUnit).";

        // payload: false for a build of the add-on that ships without the DM Client (nothing can be installed or updated).
        public static MyListWebUnitSummary Describe(MyListWebUnitInstaller.State state, bool current, BuildTarget target, string gateError, bool payload)
        {
            var s = new MyListWebUnitSummary { State = state, Level = MessageType.Info, Payload = payload };
            bool pc = target == BuildTarget.StandaloneWindows64;
            string other = "Not included on " + target + " builds";
            switch (state)
            {
                case MyListWebUnitInstaller.State.Official:
                    s.Current = "Official YamachanWebUnit " + MyListWebUnitInstaller.RequiredVersion;
                    s.Status = "";
                    s.PcExtension = "Disabled";
                    s.CanInstall = payload;
                    break;
                case MyListWebUnitInstaller.State.DmModified:
                    s.Modified = true;
                    // Only the Production SHA is v5.4; any other verified Client is an older revision (its version is not claimed).
                    s.Current = current ? "DM Modified WebUnit v5.4" : "DM Modified WebUnit (older revision)";
                    s.CanRestore = true;
                    if (!current && !payload) { s.Status = "OLDER REVISION (no update in this package)"; s.Level = MessageType.Warning; s.PcExtension = pc ? "Update required" : other; }
                    else if (!current) { s.Status = "UPDATE AVAILABLE"; s.CanUpdate = true; s.Level = MessageType.Warning; s.PcExtension = pc ? "Update required" : other; }
                    else if (!pc) { s.Status = "UP TO DATE"; s.PcExtension = other; }
                    else if (gateError == Compiling) { s.Status = "UP TO DATE"; s.PcExtension = "Waiting for the scripts to compile"; }
                    else if (!string.IsNullOrEmpty(gateError)) { s.Status = "UNKNOWN / REPAIR REQUIRED"; s.Level = MessageType.Error; s.PcExtension = "Not ready: " + gateError; }
                    else { s.Status = "UP TO DATE"; s.PcExtension = "Ready"; }
                    break;
                case MyListWebUnitInstaller.State.NoWebUnit:
                    s.Current = "YamachanWebUnit is not installed";
                    s.Status = "";
                    s.PcExtension = "Disabled";
                    break;
                case MyListWebUnitInstaller.State.OtherVersion:
                    s.Current = "Unknown / Unsupported";
                    s.Status = "UNSUPPORTED VERSION (verified only with YamachanWebUnit " + MyListWebUnitInstaller.RequiredVersion + ")";
                    s.PcExtension = "Disabled";
                    s.Level = MessageType.Warning;
                    break;
                default:
                    s.Current = "Unknown / Unsupported";
                    s.Status = "UNKNOWN / REPAIR REQUIRED";
                    s.PcExtension = pc ? "Not ready" : other;
                    s.Level = MessageType.Error;
                    break;
            }
            return s;
        }

        static double readAt = -10;
        static MyListWebUnitSummary cached;
        static string cachedDetail = "";

        // The state of the project right now (file check; read again at most once per second and after every action).
        public static MyListWebUnitSummary Read(out string detail)
        {
            if (EditorApplication.timeSinceStartup - readAt < 1.0 && EditorApplication.timeSinceStartup >= readAt) { detail = cachedDetail; return cached; }
            MyListWebUnitInstaller.State state = MyListWebUnitInstaller.Inspect(out detail);
            bool current = state == MyListWebUnitInstaller.State.DmModified && MyListWebUnitInstaller.IsCurrent();
            string gateError = "";
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
#if WEB_UNIT_INCLUDED
            if (current && MyListModifiedWebUnitBuild.IsPcTarget(target))
            {
                if (EditorApplication.isCompiling) gateError = Compiling;
                else
                {
                    try { if (MyListModifiedWebUnitBuild.Gate() == null) gateError = Compiling; }
                    catch (System.Exception ex) { gateError = ex.Message; }
                }
            }
#endif
            cached = Describe(state, current, target, gateError, MyListWebUnitInstaller.PayloadAvailable());
            cachedDetail = detail; readAt = EditorApplication.timeSinceStartup;
            return cached;
        }

        public static void Forget() { readAt = -10; }

        public static void Draw()
        {
            string detail;
            MyListWebUnitSummary s = Read(out detail);
            EditorGUILayout.LabelField("WebUnit", EditorStyles.boldLabel);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.HelpBox(ProjectWideNote, MessageType.None);
                EditorGUILayout.LabelField("Current WebUnit", s.Current);
                bool selectable = s.CanInstall || s.CanRestore;
                EditorGUILayout.LabelField("Playback WebUnit");
                using (new EditorGUI.DisabledScope(!selectable || EditorApplication.isCompiling || EditorApplication.isPlayingOrWillChangePlaymode))
                {
                    // The two radio buttons always show what the project really has; choosing the other one asks first.
                    bool official, modified;
                    using (new EditorGUILayout.HorizontalScope()) { GUILayout.Space(16); official = GUILayout.Toggle(s.State == MyListWebUnitInstaller.State.Official, " Official YamachanWebUnit", EditorStyles.radioButton); }
                    using (new EditorGUI.DisabledScope(!s.Payload && !s.Modified))
                    using (new EditorGUILayout.HorizontalScope()) { GUILayout.Space(16); modified = GUILayout.Toggle(s.Modified, " DM Modified WebUnit v5.4 (PC)", EditorStyles.radioButton); }
                    if (modified && !s.Modified && s.CanInstall) Act(MyListWebUnitInstaller.InstallWithDialog);
                    else if (official && s.Modified && s.CanRestore) Act(MyListWebUnitInstaller.RestoreWithDialog);
                }
                if (!s.Payload) EditorGUILayout.HelpBox(NotIncludedNote, MessageType.None);
                EditorGUILayout.Space(2);
                EditorGUILayout.LabelField("WebUnit Status", s.Current + (s.Status != "" ? "  —  " + s.Status : ""));
                EditorGUILayout.LabelField("PC Extension", s.PcExtension);
                EditorGUILayout.LabelField(AndroidNote, EditorStyles.wordWrappedMiniLabel);
                if (s.Level != MessageType.Info) EditorGUILayout.HelpBox(s.Status + "\n" + detail, s.Level);
                using (new EditorGUI.DisabledScope(EditorApplication.isCompiling || EditorApplication.isPlayingOrWillChangePlaymode))
                {
                    if (s.CanInstall && GUILayout.Button("Install DM Modified WebUnit v5.4")) Act(MyListWebUnitInstaller.InstallWithDialog);
                    if (s.Modified && s.Payload && GUILayout.Button(s.CanUpdate ? "Update Modified WebUnit" : "Check / Update Modified WebUnit")) Act(MyListWebUnitInstaller.UpdateWithDialog);
                    if (s.CanRestore && GUILayout.Button("Restore Official WebUnit")) Act(MyListWebUnitInstaller.RestoreWithDialog);
                }
                if (s.State == MyListWebUnitInstaller.State.Unknown || s.State == MyListWebUnitInstaller.State.OtherVersion)
                    EditorGUILayout.HelpBox("YamachanWebUnit " + MyListWebUnitInstaller.RequiredVersion + " を入れ直すと（VCC）、公式の状態に戻ります。 / Add YamachanWebUnit " + MyListWebUnitInstaller.RequiredVersion + " again (VCC) to get back to the official state.", MessageType.None);
            }
        }

        static void Act(System.Func<string> action)
        {
            action();
            Forget();
            GUIUtility.ExitGUI(); // the dialog ended this GUI pass
        }
    }

    [CustomEditor(typeof(MyListPersistentView))]
    public class MyListPersistentViewEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            if (UdonSharpGUI.DrawDefaultUdonSharpBehaviourHeader(target)) return;
            MyListWebUnitSetup.Draw();
            EditorGUILayout.Space();
            serializedObject.Update();
            DrawPropertiesExcluding(serializedObject, "m_Script"); // the header above already shows the script
            serializedObject.ApplyModifiedProperties();
        }
    }
}
