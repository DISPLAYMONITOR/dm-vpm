# DM YamaPlayer Local Playlist — Terms of Use (English reference translation)

Effective date: 2026-10-27
Copyright holder: DISPLAY_MONITOR

These Terms set out the conditions for using DM YamaPlayer Local Playlist, provided by DISPLAY_MONITOR (the "Rights Holder"). **The Japanese version is the authoritative text.** This English version is a reference translation; if the two differ in interpretation, the Japanese version prevails.

## Article 1 (Definitions)

1. "Package": DM YamaPlayer Local Playlist (package ID `com.dismoni.yamaplayer.localplaylist`). This means the complete set of files of every version that the Rights Holder provides through the Official Source, including source code, prefabs, scenes, images and documents, and the data Unity generates from them.
2. "Official Source": the VPM repository operated by the Rights Holder, `https://displaymonitor.github.io/dm-vpm/index.json`.
3. "User": any individual or group that installs and uses the Package.
4. "World": a world uploaded to VRChat and the Unity project for it.
5. "Redistribution": making the Package or any part of it available to a third party by any means other than those allowed in Articles 2 to 5. This includes modified versions and differences (patches) from which the Package can be reconstructed.

## Article 2 (License)

Provided that the User complies with these Terms, the Rights Holder grants the User, free of charge, a non-exclusive and non-transferable license to use the Package for the following purposes:

1. incorporating it into the User's Worlds;
2. installing and updating it from the Official Source, including with VPM-compatible tools such as VCC and ALCOM;
3. modifying it within the scope of Article 4.

## Article 3 (Free, paid and commercial Worlds)

Worlds that incorporate the Package may be published and operated whether they are free, paid, commercial or non-commercial. No notice to the Rights Holder and no payment is required.

## Article 4 (Modification for Worlds)

1. The User may modify the Package for the User's own Worlds.
2. These Terms also apply to modified versions.
3. The Rights Holder provides no support or warranty for modified versions.

## Article 5 (Publishing Worlds and sharing projects)

1. A World that incorporates the Package (including a modified version) may be uploaded to VRChat and offered publicly or privately. Uploading and publishing a World is not Redistribution.
2. Solely for the purpose of jointly creating the same World, a Unity project containing the Package may be shared within the team. Persons who receive it are also bound by these Terms.
3. When creating a World on commission, a Unity project containing the Package may be handed over to the client to the extent necessary to create and deliver that specific World. The client is also bound by these Terms.
4. Persons who received a project under the two preceding paragraphs, and clients, may not pass the Package on to further third parties without limit.

## Article 6 (Prohibited acts)

The User must not:

1. redistribute or resell the Package in any way described in Article 7;
2. present the Package or a modified version as the User's own work;
3. remove the copyright notice, these Terms or the NOTICE of the Package when sharing or handing over a project under Article 5;
4. use third-party software in breach of its terms or licenses (Article 8);
5. use the Package for purposes that violate laws or the VRChat Terms of Service.

## Article 7 (No redistribution or resale)

1. The Package must not be redistributed or resold without the Rights Holder's permission, whether for a fee or free, and whether modified or not.
2. The following are Redistribution (examples):
   - publishing or distributing a ZIP, unitypackage, folder or the source code of the Package in stores, on social media, file-sharing services, VPM repositories or the like;
   - distributing a modified Package, or differences from which the Package can be reconstructed, for others to use;
   - selling or distributing an "asset", "tool" or "template" that contains the Package;
   - bundling the Package itself in a world asset for sale (such as a complete world project). Where needed, direct buyers to install it as a dependency from the Official Source.
3. The following are not Redistribution:
   - uploading and publishing a World that incorporates the Package to VRChat;
   - sharing or handing over a project within the scope of Article 5, paragraphs 2 and 3;
   - telling others the URL of the Official Source.
4. The Rights Holder does not provide a contact point. Individual permission is valid only when the Rights Holder states it expressly on its own initiative.

## Article 8 (Third-party software and materials)

1. The Package is intended to be used with third-party software, mainly YamaPlayer, YamachanWebUnit, the VRChat SDK and Unity.
2. The Package does not contain the files of any third-party software. The User installs them from their respective sources and uses them under their own terms and licenses. As an exception, a modified YamachanWebUnit Client (`WebUnit/Client.dm-v5.4.cs.txt`) is bundled with the permission of the rights holder of YamachanWebUnit. The parts of that file that come from YamachanWebUnit are subject to the conditions of the YamachanWebUnit rights holder, not to these Terms (see NOTICE.md).
3. Where the terms or licenses of third-party software differ from these Terms, the third party's conditions prevail for that software. The Rights Holder grants the User no rights to any third-party software.
4. Notices about third-party software are in the bundled NOTICE.md.

## Article 9 (Copyright and ownership)

1. Copyright and all other rights in the Package belong to the Rights Holder, except for parts belonging to third parties.
2. These Terms grant a license to use; they do not transfer any rights.
3. Rights in Worlds created by the User, and in parts the User created independently, belong to the User.

## Article 10 (Support and updates)

1. The Rights Holder has no obligation to provide support, fix defects, release updates or keep providing the Package.
2. Updates are provided by adding new versions to the Official Source. A published version is never replaced under the same version number.
3. The Package may stop working because of changes in third-party software or in VRChat.

## Article 11 (Disclaimer)

1. The Package is provided as is, without any warranty, including warranties of operation, fitness for a purpose, or non-infringement of third-party rights.
2. The Rights Holder is not liable for any damage to the User or third parties arising from the use of, or inability to use, the Package, including the loss of world data or players' saved data, except where such exclusion is not permitted by law.

## Article 12 (Changes to these Terms; breaches)

1. The Rights Holder may change these Terms. Changed Terms are shown by including them in versions provided through the Official Source.
2. Changed Terms apply, in principle, to versions obtained or updated after the change. They are not applied retroactively and unilaterally to versions already obtained.
3. If a User breaches these Terms, the Rights Holder notifies the User of the breach. In principle, a 14-day period to remedy the breach is allowed from the notice. If the breach is not remedied within that period, the Rights Holder may terminate the license.
4. In the following cases, the Rights Holder may terminate the license or take other measures without allowing the remedy period of the preceding paragraph:
   - serious infringement of rights;
   - malicious unauthorized resale;
   - where the damage continues or may spread.
5. How already-published Worlds are treated after termination is decided case by case.

## Article 13 (Contact)

The Rights Holder does not provide a contact point (see Article 10 for support).
