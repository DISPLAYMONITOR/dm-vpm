// DM Modified WebUnit v5.4 installer (optional, PC). Replaces exactly one file of the installed YamachanWebUnit 1.1.0
// package, Runtime/Client.cs, with the verified DM modified Client shipped next to this add-on, and puts the official
// file back on request.
//
// What other code can call:
//   - reading the state (Inspect, IsCurrent, PayloadAvailable, OfficialBackupReady, WarningText): nothing is written;
//   - InstallWithDialog / UpdateWithDialog / RestoreWithDialog / InstallOrUpdateWithDialog: each shows the project-wide
//     warning first and writes only after the user pressed Apply. The Tools menu, the PersistentMyList Inspector and
//     Auto Setup all use these.
// The functions that write (Install / Update / Restore) are private: there is no way to change the Client from outside
// this class without the warning. Nothing here runs on editor start, on placing the prefab, on a package update or on
// a build.
//
// Nothing is written unless every check passes:
//   - the package is YamachanWebUnit 1.1.0 at Packages/net.kwxxw.yamachan-web-unit,
//   - the installed Client.cs is byte-for-byte the official 1.1.0 file (install) or a verified DM file (update / restore),
//   - the file to be written has the verified SHA256,
//   - the file that is about to be replaced has been copied to the backup folder and read back.
// If a write fails, the previous bytes are written back and the result is compared with the SHA256 recorded before the
// change; only a match is reported as a verified rollback. Existing backups are never deleted or overwritten.
// Works on file paths only, so it compiles with or without WebUnit.
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace DM.YamaMyList.Editor
{
    public static class MyListWebUnitInstaller
    {
        // The shipped DM Client is found by its asset GUID, so the add-on works from Packages/ (VCC) and from Assets/.
        public const string PayloadGuid = "8cd821b0426641f7986ce243ca6aa270";
        public const string PayloadFileName = "Client.dm-v5.4.cs.txt";
        public const string PackageDir = "Packages/net.kwxxw.yamachan-web-unit";
        public const string TargetPath = PackageDir + "/Runtime/Client.cs";
        public const string BackupDir = "DMYamaPlayerPersistentMyList_Backup";
        public const string BackupPath = BackupDir + "/YamachanWebUnit-1.1.0-Client.cs";
        public const string RequiredVersion = "1.1.0";
        public const string OfficialSha256 = "57c6be2a92d2cb442d51acfc361cd49e9ef09a6d003258d2b7bb50b4e4ff7e7c";
        const string Menu = "Tools/DIS_MONI Tools/DM YamaPlayer Local Playlist/WebUnit/";
        const string DialogTitle = "DM Modified WebUnit v5.4 (PC)";

        public enum State { NoWebUnit, OtherVersion, Official, DmModified, Unknown }
        public enum Change { Install, Update, Restore }

        public const string Cancelled = "CANCELLED: nothing was written";
        public const string RollbackVerified = "ROLLBACK VERIFIED";
        public const string RollbackFailed = "ROLLBACK FAILED";

        // ---------------------------------------------------------------- reading (nothing is written)

        static string Sha256(byte[] data)
        {
            using (var sha = SHA256.Create()) return string.Concat(sha.ComputeHash(data).Select(b => b.ToString("x2")));
        }

        static string ShaOfFile(string path)
        {
            try { return File.Exists(path) ? Sha256(File.ReadAllBytes(path)) : "missing"; }
            catch (Exception ex) { return "unreadable (" + ex.Message + ")"; }
        }

        // Path of the shipped DM Client on disk, or null when this build of the add-on does not include it.
        public static string FindPayload()
        {
            string path = AssetDatabase.GUIDToAssetPath(PayloadGuid);
            if (string.IsNullOrEmpty(path) || !path.EndsWith("/" + PayloadFileName))
                path = AssetDatabase.FindAssets("Client.dm-v5.4.cs").Select(AssetDatabase.GUIDToAssetPath).FirstOrDefault(p => p.EndsWith("/" + PayloadFileName));
            if (string.IsNullOrEmpty(path)) return null;
            string physical = MyListPackagePaths.Physical(path);
            return File.Exists(physical) ? physical : null;
        }

        // False for a build of the add-on that ships without the DM Client: the UI then offers no install.
        public static bool PayloadAvailable() { return FindPayload() != null; }

        public static State Inspect(out string detail)
        {
            if (!File.Exists(TargetPath) || !File.Exists(PackageDir + "/package.json")) { detail = "YamachanWebUnit was not found at " + PackageDir; return State.NoWebUnit; }
            var version = Regex.Match(File.ReadAllText(PackageDir + "/package.json"), "\"version\"\\s*:\\s*\"([^\"]+)\"");
            string found = version.Success ? version.Groups[1].Value : "unknown";
            if (found != RequiredVersion) { detail = "YamachanWebUnit version is " + found + "; verified only with " + RequiredVersion; return State.OtherVersion; }
            string sha = Sha256(File.ReadAllBytes(TargetPath));
            if (sha == OfficialSha256) { detail = "official YamachanWebUnit " + found + " Client (sha256 " + sha + ")"; return State.Official; }
            if (MyListModifiedWebUnitRevisions.Verified.Contains(sha)) { detail = "DM Modified WebUnit Client (sha256 " + sha + ")"; return State.DmModified; }
            detail = "Client.cs is neither the official " + RequiredVersion + " file nor a verified DM file (sha256 " + sha + ")";
            return State.Unknown;
        }

        // True when the verified official file is in the backup folder (what Restore needs).
        public static bool OfficialBackupReady()
        {
            return File.Exists(BackupPath) && Sha256(File.ReadAllBytes(BackupPath)) == OfficialSha256;
        }

        // True when the installed Client is exactly the DM file this add-on ships (nothing to update).
        public static bool IsCurrent()
        {
            return File.Exists(TargetPath) && Sha256(File.ReadAllBytes(TargetPath)) == MyListModifiedWebUnitRevisions.Production;
        }

        // ---------------------------------------------------------------- writing (private)

        // Every write of this class goes through here. Set only by the product checks (through reflection) to make
        // a write fail; never set in normal use.
        static Action<string, byte[]> writeForChecks;

        static void Write(string path, byte[] data)
        {
            if (writeForChecks != null) writeForChecks(path, data); else File.WriteAllBytes(path, data);
        }

        // Makes sure `data` is in the backup folder under `path` and can be read back. An existing backup with the same
        // content is kept as it is; an existing file with other content is kept under another name, never overwritten.
        static void Backup(string path, byte[] data, string what)
        {
            try
            {
                string wanted = Sha256(data);
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                if (File.Exists(path))
                {
                    string existing = Sha256(File.ReadAllBytes(path));
                    if (existing == wanted) return;
                    string aside = path + ".kept-" + existing.Substring(0, 8);
                    for (int n = 2; File.Exists(aside); n++) aside = path + ".kept-" + existing.Substring(0, 8) + "-" + n;
                    File.Move(path, aside);
                }
                Write(path, data);
                if (ShaOfFile(path) != wanted) throw new IOException("the backup could not be read back");
            }
            catch (Exception ex) { throw new Exception(what + ", nothing was written to WebUnit: the backup at " + path + " could not be made (" + ex.Message + ")"); }
        }

        // Writes the Client and reads it back. On any failure the previous bytes are written back, and the file is then
        // compared with the SHA256 it had before the change. `savedAt`: where the previous file is kept.
        static void Replace(byte[] data, string expectedSha, byte[] previous, string savedAt, string what)
        {
            string before = Sha256(previous);
            try
            {
                Write(TargetPath, data);
                if (ShaOfFile(TargetPath) != expectedSha) throw new IOException("the written file could not be verified");
            }
            catch (Exception ex)
            {
                string writeBack = "";
                if (ShaOfFile(TargetPath) != before)
                {
                    try { Write(TargetPath, previous); }
                    catch (Exception again) { writeBack = " Writing the previous file back failed: " + again.Message + "."; }
                }
                string now = ShaOfFile(TargetPath);
                if (now == before)
                    throw new Exception(what + ": " + ex.Message + ". " + RollbackVerified + ": Client.cs is the file it was before the change (sha256 " + before + ").");
                throw new Exception(what + ": " + ex.Message + ". " + RollbackFailed + ": Client.cs is now '" + now + "', not the file it was before the change (sha256 " + before + ")." + writeBack +
                    "\n\n元のファイルは " + savedAt + " に保存されています。Unity を閉じ、このファイルを " + TargetPath + " へ手でコピーしてください。" +
                    "できない場合は、VCC / ALCOM で YamachanWebUnit を一度外し、" + RequiredVersion + " を入れ直すと公式の状態に戻ります。" +
                    "\nThe file from before the change is kept at " + savedAt + ". Close Unity and copy it to " + TargetPath + " by hand, or remove YamachanWebUnit and add version " + RequiredVersion + " again (VCC / ALCOM).");
            }
        }

        static string ModifiedBackupPath(byte[] modified) { return BackupDir + "/DM-Modified-Client-" + Sha256(modified).Substring(0, 8) + ".cs"; }

        // ---------------------------------------------------------------- the user's choice (to notice a lost Client)

        // What the user last chose here ("DmModified" / "Official"). Kept next to the backups (outside Packages/), so a
        // VCC / ALCOM reinstall of YamachanWebUnit, which puts the official Client back, can be noticed.
        public const string ChoicePath = BackupDir + "/selected-webunit.txt";
        const string ChoseModified = "DmModified", ChoseOfficial = "Official";

        static void SaveChoice(string choice)
        {
            try { Directory.CreateDirectory(BackupDir); File.WriteAllText(ChoicePath, choice); }
            catch (Exception ex) { Debug.LogWarning("[DM Modified WebUnit] the choice could not be recorded at " + ChoicePath + " (" + ex.Message + ")"); }
        }

        // True when the DM Modified Client was chosen here but the project now has the official Client again (for
        // example after YamachanWebUnit was reinstalled or updated with VCC / ALCOM). Anything that cannot be read is
        // "not lost" (no notice), never an exception.
        public static bool ModifiedLost()
        {
            try
            {
                string detail;
                if (Inspect(out detail) != State.Official) return false;
                return File.Exists(ChoicePath) && File.ReadAllText(ChoicePath).Trim() == ChoseModified;
            }
            catch (Exception) { return false; }
        }

        // A project that already has a DM Modified Client but no recorded choice (installed before this record existed):
        // the existing Client is the user's earlier choice, so it is recorded (only the record file is written).
        static void RecordExistingModified()
        {
            try
            {
                string detail;
                if (File.Exists(ChoicePath) || Inspect(out detail) != State.DmModified) return;
                SaveChoice(ChoseModified);
                Debug.Log("[DM Modified WebUnit] the installed DM Modified Client was recorded as the chosen WebUnit (" + ChoicePath + ")");
            }
            catch (Exception) { }
        }

        public const string LostNote = "DM Modified WebUnit v5.4 を選んでいましたが、今の YamachanWebUnit の Client.cs は公式のものです（VCC・ALCOM で YamachanWebUnit を入れ直した・更新した場合に起きます）。改変版を使うには「Install DM Modified WebUnit v5.4」を、公式のまま使うには「公式のまま使う」を押してください。\n" +
            "The DM Modified WebUnit v5.4 was chosen, but YamachanWebUnit's Client.cs is the official one now (this happens when YamachanWebUnit is reinstalled or updated with VCC / ALCOM). Install it again, or choose to keep the official Client.";

        // Records that the official Client is wanted (nothing in WebUnit is written).
        public static void KeepOfficial() { SaveChoice(ChoseOfficial); Debug.Log("[DM Modified WebUnit] the official YamachanWebUnit Client is kept (choice recorded)"); }

        [InitializeOnLoadMethod]
        static void WarnWhenLost()
        {
            EditorApplication.delayCall += () =>
            {
                try
                {
                    RecordExistingModified();
                    if (ModifiedLost()) Debug.LogWarning("[DM Modified WebUnit] " + LostNote);
                }
                catch (Exception) { }
            };
        }

        static byte[] VerifiedPayload(string what)
        {
            string payloadPath = FindPayload();
            if (payloadPath == null) throw new Exception(what + ", nothing was written: " + PayloadFileName + " is not included in this package");
            byte[] payload = File.ReadAllBytes(payloadPath);
            if (Sha256(payload) != MyListModifiedWebUnitRevisions.Production) throw new Exception(what + ", nothing was written: " + payloadPath + " is not the verified file (sha256 " + Sha256(payload) + ")");
            return payload;
        }

        // Replaces the official Client with the DM modified one. Returns a report; throws without writing when a check fails.
        static string Install()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.DmModified && IsCurrent()) { SaveChoice(ChoseModified); return "ALREADY INSTALLED: " + detail; }
            if (state != State.Official) throw new Exception("not installed, nothing was written: " + detail);
            byte[] payload = VerifiedPayload("not installed");
            byte[] official = File.ReadAllBytes(TargetPath);
            Backup(BackupPath, official, "not installed");
            Replace(payload, MyListModifiedWebUnitRevisions.Production, official, BackupPath, "not installed");
            SaveChoice(ChoseModified);
            AssetDatabase.Refresh();
            return "INSTALLED DM Modified WebUnit v5.4 (sha256 " + MyListModifiedWebUnitRevisions.Production + "); official file kept at " + BackupPath;
        }

        // Puts the official Client back. Returns a report; throws without writing when a check fails.
        static string Restore()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.Official) { SaveChoice(ChoseOfficial); return "ALREADY OFFICIAL: " + detail; }
            if (state != State.DmModified) throw new Exception("not restored, nothing was written: " + detail);
            if (!File.Exists(BackupPath)) throw new Exception("not restored, nothing was written: " + BackupPath + " is missing. Remove YamachanWebUnit and add version " + RequiredVersion + " again (VCC) to get the official file back.");
            byte[] official = File.ReadAllBytes(BackupPath);
            if (Sha256(official) != OfficialSha256) throw new Exception("not restored, nothing was written: " + BackupPath + " is not the official " + RequiredVersion + " file. Remove YamachanWebUnit and add version " + RequiredVersion + " again (VCC).");
            byte[] modified = File.ReadAllBytes(TargetPath);
            Backup(ModifiedBackupPath(modified), modified, "not restored");
            Replace(official, OfficialSha256, modified, ModifiedBackupPath(modified), "not restored");
            SaveChoice(ChoseOfficial);
            AssetDatabase.Refresh();
            return "RESTORED the official YamachanWebUnit " + RequiredVersion + " Client (sha256 " + OfficialSha256 + ")";
        }

        // Replaces an older verified DM Client with the one this add-on ships. Never touches the official file or an
        // unknown file. Returns a report; throws without writing when a check fails.
        static string Update()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.DmModified && IsCurrent()) { SaveChoice(ChoseModified); return "UP TO DATE: " + detail; }
            if (state != State.DmModified) throw new Exception("not updated, nothing was written: " + detail);
            byte[] payload = VerifiedPayload("not updated");
            byte[] previous = File.ReadAllBytes(TargetPath);
            Backup(ModifiedBackupPath(previous), previous, "not updated");
            Replace(payload, MyListModifiedWebUnitRevisions.Production, previous, ModifiedBackupPath(previous), "not updated");
            SaveChoice(ChoseModified);
            AssetDatabase.Refresh();
            return "UPDATED to DM Modified WebUnit v5.4 (sha256 " + MyListModifiedWebUnitRevisions.Production + ")";
        }

        // ---------------------------------------------------------------- the warning

        // The warning every WebUnit change shows first (same text from the Tools menu, the Inspector and Auto Setup).
        public static string WarningText(Change change)
        {
            string what = change == Change.Install ? "Official YamachanWebUnit → DM Modified WebUnit v5.4 へ変更します。"
                : change == Change.Update ? "導入済みの DM Modified WebUnit を、同梱の v5.4 へ更新します。"
                : "DM Modified WebUnit → Official YamachanWebUnit " + RequiredVersion + " へ戻します。";
            string text = what + "\n（YamachanWebUnit " + RequiredVersion + " の Runtime/Client.cs 1 ファイルを置き換えます）\n\n" +
                "この操作はUnityプロジェクト全体のYamachanWebUnitを変更します。\n" +
                "既存の動画プレイヤーやWebUnitを利用する他のギミックにも影響する可能性があります。\n\n" +
                "変更前のWebUnitは " + BackupDir + "/ にバックアップされますが、Unityプロジェクト全体のバックアップも推奨します。\n\n" +
                "YamaPlayerの登録済みプレイリストを削除・初期化する操作ではありません。\n";
            if (change != Change.Restore) text += "\nWindows 向けの追加機能です。" + MyListWebUnitSetup.AndroidNoteJa + "\n";
            else text += "\nOfficial へ戻すと、改変 Client のプログラムは、Android 向けを含むどのビルドにも含まれなくなります。\n";
            if (change != Change.Install && !OfficialBackupReady())
                text += "\n注意: 公式ファイルのバックアップ（" + BackupPath + "）が見つからないか、内容が一致しません。" +
                    (change == Change.Restore ? "この状態では元に戻せません。VCC で YamachanWebUnit " + RequiredVersion + " を入れ直してください。\n"
                        : "更新後に「Restore Official WebUnit」は使えません（VCC で YamachanWebUnit を入れ直すと公式版に戻ります）。\n");
            text += "\n変更を適用しますか？\n\n" +
                "This changes the YamachanWebUnit of the whole Unity project and may affect other video players or gimmicks that use WebUnit. " +
                "The current file is backed up; backing up the whole project is also recommended. It does not delete or reset YamaPlayer playlists. " +
                (change != Change.Restore ? MyListWebUnitSetup.AndroidNoteEn + " " : "After the restore the modified Client program is in no build. ") + "Apply?";
            return text;
        }

        // Set only by the product checks (through reflection) to answer the warning without a window. Not a public
        // route: every menu, Inspector and Auto Setup action shows the real dialog.
        static Func<Change, string, bool> confirmForChecks;

        static bool Confirm(Change change)
        {
            string text = WarningText(change);
            if (confirmForChecks != null) return confirmForChecks(change, text);
            return EditorUtility.DisplayDialog(DialogTitle, text, "適用 / Apply", "キャンセル / Cancel");
        }

        // ---------------------------------------------------------------- the only entries that can change the Client

        // Each asks first (when there is something to change) and returns what happened.
        public static string InstallWithDialog()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.Official && PayloadAvailable() && !Confirm(Change.Install)) return Cancelled;
            return Run(Install);
        }

        public static string UpdateWithDialog()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.DmModified && !IsCurrent() && PayloadAvailable() && !Confirm(Change.Update)) return Cancelled;
            return Run(Update);
        }

        public static string RestoreWithDialog()
        {
            string detail;
            State state = Inspect(out detail);
            if (state == State.DmModified && !Confirm(Change.Restore)) return Cancelled;
            return Run(Restore);
        }

        // Install when the project has the official Client, update when it has an older DM Client.
        public static string InstallOrUpdateWithDialog()
        {
            string detail;
            return Inspect(out detail) == State.DmModified ? UpdateWithDialog() : InstallWithDialog();
        }

        [MenuItem(Menu + "Install or Update Modified WebUnit", false, 1100)]
        static void InstallMenu() { InstallOrUpdateWithDialog(); }

        [MenuItem(Menu + "Restore Official WebUnit", false, 1101)]
        static void RestoreMenu() { RestoreWithDialog(); }

        [MenuItem(Menu + "Verify Status", false, 1102)]
        static void StatusMenu()
        {
            string detail;
            State state = Inspect(out detail);
            if (!PayloadAvailable()) detail += "\n\nこのパッケージには DM Modified WebUnit は同梱されていません。 / This package does not include the DM Modified WebUnit.";
            Debug.Log("[DM Modified WebUnit] " + state + ": " + detail);
            EditorUtility.DisplayDialog(DialogTitle, state + "\n\n" + detail, "OK");
        }

        static string Run(Func<string> action)
        {
            try
            {
                string report = action();
                Debug.Log("[DM Modified WebUnit] " + report);
                if (confirmForChecks == null) EditorUtility.DisplayDialog(DialogTitle, report, "OK");
                return report;
            }
            catch (Exception ex)
            {
                Debug.LogError("[DM Modified WebUnit] " + ex.Message);
                if (confirmForChecks == null) EditorUtility.DisplayDialog(DialogTitle, ex.Message, "OK");
                return "ERROR: " + ex.Message;
            }
        }
    }
}
