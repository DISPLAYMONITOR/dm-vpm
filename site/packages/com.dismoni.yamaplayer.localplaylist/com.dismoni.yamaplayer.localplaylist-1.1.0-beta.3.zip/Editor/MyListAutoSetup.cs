// "自動配置・セットアップ" (Tools > DIS_MONI Tools > DM YamaPlayer Local Playlist): places the PersistentMyList prefab in
// the open scene when it is not there yet, lets the existing setup (MyListProductSetup) bind it to the YamaPlayer,
// checks the result, and then asks which WebUnit the project should use.
//   - Nothing is placed without a YamaPlayer, and never a second PersistentMyList. Nothing is ever deleted.
//   - With several YamaPlayers the user picks the one to use; none is chosen for them.
//   - The WebUnit is only changed by the user's choice, through MyListWebUnitInstaller (the same functions as the
//     Inspector and the WebUnit menu). The default choice is the official WebUnit, which changes nothing.
// The reference binding itself is not implemented here: MyListProductSetup.ConfigureScene does it, as it always did.
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Yamadev.YamaStream;
using Yamadev.YamaStream.UI;

namespace DM.YamaMyList.Editor
{
    public static class MyListAutoSetup
    {
        public const string MenuRoot = "Tools/DIS_MONI Tools/DM YamaPlayer Local Playlist/";
        // Found by asset GUID: the add-on may be in Packages/ (VCC) or in Assets/ (unitypackage).
        public static string PrefabPath { get { return MyListPackagePaths.PrefabPath; } }
        public static string ReadmePath { get { return MyListPackagePaths.ReadmePath; } }
        const string Title = "DM YamaPlayer Local Playlist";

        // References the product needs on a placed PersistentMyList (fields of MyListPersistentView).
        public static readonly string[] RequiredReferences = {
            "controller", "yamaUI", "modal", "nativePlaylists", "nativeTracks", "nativeName", "nativeInfo", "controlAnimator",
            "queueTab", "historyTab", "playlistTab", "nativeAddPlaylistRow", "modalContent", "nativeTransport",
            "adapter", "playbackGuard", "importTemplate", "trackScroll", "seekRoot", "nameInput", "toastRoot" };
        // An additional UI takes the adapter, the playback guard and the import template from its primary at runtime.
        public static readonly string[] SharedReferences = { "adapter", "playbackGuard", "importTemplate" };
        public static string ExtraPrefabPath { get { return MyListPackagePaths.ExtraPrefabPath; } }

        public class Scan
        {
            public Scene Scene;
            public Controller[] Players = new Controller[0];       // YamaPlayers that have their screen UI in the scene
            public Controller[] PlayersWithoutUi = new Controller[0];
            public MyListPersistentView[] Views = new MyListPersistentView[0];      // PersistentMyList objects (with Store and playback)
            public MyListPersistentView[] ExtraViews = new MyListPersistentView[0]; // additional UIs (DM Local Playlist UI)
            // Screens with their own controls that point at a YamaPlayer of the scene and are not that YamaPlayer's
            // own screen (YamaPlayer's SubScreen prefab, a tablet controller ...), and which of them have a DM UI.
            public UIController[] ExtraScreens = new UIController[0];
            public UIController[] ExtraScreensWithoutUi = new UIController[0];
        }

        public class Result
        {
            public bool Ok;
            public string Code = "";          // PLACED / CHECKED / REPAIRED / NO_YAMAPLAYER / CHOOSE_YAMAPLAYER / NO_PREFAB / FAILED / INCOMPATIBLE_YAMAPLAYER / UNVERIFIED_YAMAPLAYER
            public string YamaPlayer = "", MyList = "", References = "", Message = "";
            public MyListPersistentView View;
            public string[] Missing = new string[0];
            public string Compatibility = ""; // installed YamaPlayer version and whether it is a verified one
            public string Protection = "";    // what the before / after comparison of the existing YamaPlayers says
            public string[] YamaPlayerChanges = new string[0];
            public string F1b = "";           // whether F1b "play again" can be shown (not a required reference)
        }

        // Everything of the existing YamaPlayers that the setup must leave alone: every serialized component, the prefab
        // connection and the list of prefab overrides.
        public class Protected
        {
            public GameObject[] Roots = new GameObject[0];
            public Dictionary<Object, string>[] Serialized = new Dictionary<Object, string>[0];
            public string[] Prefab = new string[0];
            public int Objects;
        }

        static string PrefabState(GameObject root)
        {
            var mods = PrefabUtility.GetPropertyModifications(root);
            return PrefabUtility.GetPrefabInstanceStatus(root) + "|" + (mods == null ? "none" : mods.Length + ":" +
                string.Join(";", mods.Select(m => (m.target ? m.target.GetInstanceID() : 0) + "." + m.propertyPath + "=" + m.value + "/" + (m.objectReference ? m.objectReference.GetInstanceID() : 0))));
        }

        public static Protected Protect(Scene scene)
        {
            var p = new Protected();
            if (!scene.IsValid() || !scene.isLoaded) return p;
            // Unity's UI keeps values that follow from the layout (scrollbar size, layout-driven RectTransforms) and
            // refreshes them whenever the canvases update. Both snapshots are taken right after such an update, so
            // that only real changes show up in the comparison.
            Canvas.ForceUpdateCanvases();
            var roots = scene.GetRootGameObjects();
            // the YamaPlayers, and every other screen that controls one of them (SubScreen, tablet controller ...)
            p.Roots = roots.SelectMany(r => r.GetComponentsInChildren<Controller>(true)).Select(MyListProductSetup.YamaRoot)
                .Concat(roots.SelectMany(r => r.GetComponentsInChildren<UIController>(true)).Where(u => MyListProductSetup.ControllerOf(u)).Select(MyListProductSetup.ScreenRoot))
                .Where(r => r).Distinct().ToArray();
            p.Roots = p.Roots.Where(r => !p.Roots.Any(o => o != r && r.transform.IsChildOf(o.transform))).ToArray();
            p.Serialized = p.Roots.Select(MyListProductSetup.Capture).ToArray();
            p.Prefab = p.Roots.Select(PrefabState).ToArray();
            p.Objects = p.Serialized.Sum(d => d.Count);
            return p;
        }

        // What differs now from the snapshot. Empty = the YamaPlayers are exactly as they were.
        public static string[] Differences(Protected before)
        {
            var changes = new List<string>();
            Canvas.ForceUpdateCanvases();
            for (int i = 0; i < before.Roots.Length; i++)
            {
                if (!before.Roots[i]) { changes.Add("YamaPlayer object removed"); continue; }
                changes.AddRange(MyListProductSetup.Changes(before.Serialized[i]));
                if (PrefabState(before.Roots[i]) != before.Prefab[i]) changes.Add(before.Roots[i].name + " / prefab connection or overrides");
            }
            return changes.ToArray();
        }

        // A static playlist object of the YamaPlayer that already has the name of DM's own playback slot. DM never uses
        // or overwrites it: at runtime the registration of DM's slot is refused instead (see MyListNativePlaylistAdapter).
        public static string[] SlotNameCollisions(Scene scene, MyListPersistentView view)
        {
            if (!scene.IsValid() || !scene.isLoaded) return new string[0];
            Playlist own = view && view.adapter ? view.adapter.slot : null;
            var objects = scene.GetRootGameObjects().SelectMany(r => r.GetComponentsInChildren<Playlist>(true))
                .Where(p => p != own && p.gameObject.name == "DM_PERSISTENT_PLAYBACK_SLOT" && !p.GetComponentInParent<MyListPersistentView>())
                .Select(p => MyListProductSetup.Path(p.transform));
            // YamaPlayer's build step names the playlist object after the entry's playlist name
            var entries = scene.GetRootGameObjects().SelectMany(r => r.GetComponentsInChildren<Yamadev.YamaStream.Script.PlayList>(true))
                .Where(e => e.gameObject.activeSelf && e.PlayListName == "DM_PERSISTENT_PLAYBACK_SLOT")
                .Select(e => MyListProductSetup.Path(e.transform) + " (playlist name)");
            return objects.Concat(entries).ToArray();
        }

        static GameObject Prefab()
        {
            var prefab = string.IsNullOrEmpty(PrefabPath) ? null : AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if (prefab && prefab.GetComponent<MyListPersistentView>()) return prefab;
            // The add-on folder may have been moved.
            return AssetDatabase.FindAssets("PersistentMyList t:Prefab").Select(AssetDatabase.GUIDToAssetPath).Where(p => p.EndsWith("/PersistentMyList.prefab"))
                .Select(AssetDatabase.LoadAssetAtPath<GameObject>).FirstOrDefault(p => p && p.GetComponent<MyListPersistentView>());
        }

        // Found by component type, never by object name.
        public static Scan Analyze(Scene scene)
        {
            var scan = new Scan { Scene = scene };
            if (!scene.IsValid() || !scene.isLoaded) return scan;
            var roots = scene.GetRootGameObjects();
            // YamaPlayers and screens the build will contain (nothing below an EditorOnly object)
            var controllers = roots.SelectMany(r => r.GetComponentsInChildren<Controller>(true)).Where(MyListProductSetup.InBuild).ToArray();
            var uis = roots.SelectMany(r => r.GetComponentsInChildren<UIController>(true)).Where(MyListProductSetup.InBuild).ToArray();
            System.Func<Controller, bool> hasUi = c => uis.Any(u => new SerializedObject(u).FindProperty("_controller")?.objectReferenceValue == c);
            scan.Players = controllers.Where(hasUi).ToArray();
            scan.PlayersWithoutUi = controllers.Where(c => !hasUi(c)).ToArray();
            var all = roots.SelectMany(r => r.GetComponentsInChildren<MyListPersistentView>(true)).ToArray();
            scan.Views = all.Where(v => !MyListProductSetup.IsExtra(v)).ToArray();
            scan.ExtraViews = all.Where(MyListProductSetup.IsExtra).ToArray();
            // "additional" = not the screen the PersistentMyList of that YamaPlayer serves (or will serve: its own screen)
            System.Func<Controller, UIController> main = c => MyListProductSetup.MainUi(scan.Views.FirstOrDefault(v => v.controller == c), c, roots);
            scan.ExtraScreens = uis.Where(u => { var c = MyListProductSetup.ControllerOf(u); return c && scan.Players.Contains(c) && main(c) != u; }).ToArray();
            scan.ExtraScreensWithoutUi = scan.ExtraScreens.Where(u => !all.Any(v => v.yamaUI == u)).ToArray();
            return scan;
        }

        public static string[] MissingReferences(MyListPersistentView view)
        {
            var missing = new List<string>();
            var so = new SerializedObject(view);
            bool extra = MyListProductSetup.IsExtra(view);
            foreach (string field in RequiredReferences)
            {
                if (extra && SharedReferences.Contains(field)) continue;
                var p = so.FindProperty(field);
                if (p == null || p.objectReferenceValue == null) missing.Add((extra ? view.name + ": " : "") + field);
            }
            if (extra)
            {
                if (!view.primary) missing.Add(view.name + ": primary");
                else if (view.primary.extraViews == null || !view.primary.extraViews.Contains(view)) missing.Add(view.name + ": not listed on its primary");
                return missing.ToArray();
            }
            if (view.adapter && !view.adapter.controller) missing.Add("adapter.controller");
            if (view.playbackGuard && !view.playbackGuard.controller) missing.Add("playbackGuard.controller");
            return missing.ToArray();
        }

        // The whole automatic part, without any dialog. `chosen` is needed only when the scene has several YamaPlayers
        // and no PersistentMyList yet. Running it again changes nothing that is already right.
        public static Result Run(Scene scene, Controller chosen) { return Run(scene, chosen, false); }

        // allowUnverified: the user's explicit "continue" for a YamaPlayer version that is not in the verified list.
        public static Result Run(Scene scene, Controller chosen, bool allowUnverified)
        {
            // 1. The compatibility contract, before anything is placed or connected.
            var compatibility = MyListProductSetup.Compatibility(true);
            string verified = string.Join(", ", DM.YamaMyList.Compatibility.MyListCompatibility.VerifiedVersions());
            if (compatibility.Status != MyListProductSetup.Verified && compatibility.Status != MyListProductSetup.NotVerified)
            {
                // contract not met: nothing is placed, the existing DM object and the YamaPlayer are not touched
                return new Result
                {
                    Code = "INCOMPATIBLE_YAMAPLAYER", Compatibility = compatibility.YamaPlayerVersion + " - " + compatibility.Status,
                    YamaPlayer = "Not compatible",
                    Message = "導入されている YamaPlayer " + compatibility.YamaPlayerVersion + " は、このバージョンの DM YamaPlayer Local Playlist が必要とする構造と一致しません。何も配置・変更していません。\n" +
                        "確認済みの YamaPlayer: " + verified + "\n" +
                        "The installed YamaPlayer does not have what this version of the add-on needs. Nothing was placed or changed.\n" + string.Join("\n", compatibility.Failed.Take(8)),
                };
            }
            bool unverified = compatibility.Status == MyListProductSetup.NotVerified;
            if (unverified && !allowUnverified && !MyListProductSetup.UnverifiedAllowed(compatibility.YamaPlayerVersion))
            {
                // structure matches, but the version was never verified: stops here until the user decides
                return new Result
                {
                    Code = "UNVERIFIED_YAMAPLAYER", Compatibility = compatibility.YamaPlayerVersion + " - " + MyListProductSetup.NotVerified,
                    YamaPlayer = "Not verified",
                    Message = "導入されている YamaPlayer " + compatibility.YamaPlayerVersion + " は、このバージョンの DM YamaPlayer Local Playlist では動作を確認していません（確認済み: " + verified + "）。\n" +
                        "必要な構造は見つかりましたが、動作は保証できません。何も配置・変更していません。続ける場合は、プロジェクトのバックアップを取ってから「未確認のバージョンで続行」を押してください。\n" +
                        "This YamaPlayer version has not been verified with this version of the add-on. Nothing was placed or changed.",
                };
            }
            if (unverified && allowUnverified) MyListProductSetup.AllowUnverified(compatibility.YamaPlayerVersion, true);

            // 2. Place / connect, as one Undo step.
            Protected before = Protect(scene);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(MyListProductSetup.UndoName);
            Result result;
            MyListProductSetup.RecordUndo = true;
            try { result = RunUnchecked(scene, chosen); }
            finally { MyListProductSetup.RecordUndo = false; Undo.CollapseUndoOperations(group); }
            result.Compatibility = compatibility.YamaPlayerVersion + " - " + (unverified ? MyListProductSetup.NotVerified + " (continued by the user; not guaranteed)" : compatibility.Status) +
                (compatibility.RealClientPending ? " (contract and editor checks; real VRChat check pending)" : "");
            if (unverified) result.Message = (result.Message != "" ? result.Message + "\n\n" : "") + "YamaPlayer " + compatibility.YamaPlayerVersion + " は未確認のバージョンです。動作は保証されません。\nThis YamaPlayer version is not verified; behaviour is not guaranteed.";
            result.YamaPlayerChanges = Differences(before);
            result.Protection = before.Roots.Length == 0 ? "" : result.YamaPlayerChanges.Length == 0
                ? "Unchanged (" + before.Objects + " serialized objects compared before / after)"
                : "CHANGED: " + string.Join(", ", result.YamaPlayerChanges.Take(10));
            if (result.YamaPlayerChanges.Length > 0)
            {
                result.Ok = false; result.Code = "FAILED";
                result.Message = "既存のYamaPlayerに変更が検出されました。Undo（Ctrl+Z）で元に戻し、シーンを保存しないでください。\nA change of the existing YamaPlayer was detected. Undo it and do not save the scene.\n" + result.Protection;
            }
            else if (result.Ok)
            {
                string[] collisions = SlotNameCollisions(scene, result.View);
                if (collisions.Length > 0)
                    result.Message = (result.Message != "" ? result.Message + "\n\n" : "") + "YamaPlayer に「DM_PERSISTENT_PLAYBACK_SLOT」という名前のプレイリストがあります（" + string.Join(", ", collisions) +
                        "）。DM はこれを使用・上書きしません。この名前は DM の再生用スロットと重なるため、実行時に DM の再生は開始されません。名前を変更してください。\n" +
                        "A YamaPlayer playlist object is named DM_PERSISTENT_PLAYBACK_SLOT. DM does not use or overwrite it; rename it, otherwise DM playback is refused at runtime.";
            }
            return result;
        }

        // Places a DM Local Playlist UI for one additional screen (a UIController that points at a YamaPlayer which
        // already has its PersistentMyList) and connects it. One Undo step; the YamaPlayer and the screen are compared
        // before / after. Never a second UI for the same screen; nothing is removed.
        public static Result AddScreenUi(Scene scene, UIController screen)
        {
            var result = new Result { YamaPlayer = "Detected" };
            string block = MyListProductSetup.CompatibilityBlock();
            if (block != "") { result.Code = block.Split(' ')[0]; result.Message = block; return result; }
            Scan scan = Analyze(scene);
            if (!screen || !scan.ExtraScreens.Contains(screen)) { result.Code = "NO_SCREEN"; result.Message = "この画面は YamaPlayer の追加画面ではありません。\nThis is not an additional screen of a YamaPlayer in the scene."; return result; }
            Controller target = MyListProductSetup.ControllerOf(screen);
            if (!scan.Views.Any(v => v.controller == target)) { result.Code = "NO_PRIMARY"; result.Message = "先に「自動配置・セットアップ」で PersistentMyList を配置してください。\nRun Auto Setup first: the YamaPlayer of this screen has no PersistentMyList yet."; return result; }
            var existing = scan.ExtraViews.FirstOrDefault(v => v.yamaUI == screen || (v.targetScreen && v.targetScreen.GetComponentInChildren<UIController>(true) == screen));
            Protected before = Protect(scene);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(MyListProductSetup.UndoName);
            MyListProductSetup.RecordUndo = true;
            try
            {
                if (existing) { result.View = existing; result.MyList = "Already placed"; result.Code = "CHECKED"; }
                else
                {
                    string path = ExtraPrefabPath;
                    GameObject prefab = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<GameObject>(path);
                    if (!prefab || !prefab.GetComponent<MyListPersistentView>()) { result.Code = "NO_PREFAB"; result.Message = "DM Local Playlist UI.prefab was not found. Install DM YamaPlayer Local Playlist again."; return result; }
                    GameObject root = MyListProductSetup.ScreenRoot(screen);
                    var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
                    Undo.RegisterCreatedObjectUndo(instance, MyListProductSetup.UndoName);
                    instance.name = prefab.name + " (" + root.name + ")";
                    instance.transform.position = root.transform.position;
                    var view = instance.GetComponent<MyListPersistentView>();
                    var so = new SerializedObject(view);
                    so.FindProperty("targetScreen").objectReferenceValue = root;
                    so.ApplyModifiedPropertiesWithoutUndo();
                    UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(view);
                    EditorSceneManager.MarkSceneDirty(scene);
                    result.View = view; result.MyList = "Placed"; result.Code = "PLACED";
                }
                try { MyListProductSetup.ConfigureScene(scene); }
                catch (System.Exception ex) { result.Code = "FAILED"; result.Message = ex.Message; result.References = "Failed"; return result; }
            }
            finally { MyListProductSetup.RecordUndo = false; Undo.CollapseUndoOperations(group); }
            result.Missing = MissingReferences(result.View);
            result.References = result.Missing.Length == 0 ? "Configured" : "Missing: " + string.Join(", ", result.Missing);
            result.F1b = F1bStatus(new[] { result.View });
            result.Ok = result.Missing.Length == 0;
            result.YamaPlayerChanges = Differences(before);
            result.Protection = result.YamaPlayerChanges.Length == 0 ? "Unchanged (" + before.Objects + " serialized objects compared before / after)" : "CHANGED: " + string.Join(", ", result.YamaPlayerChanges.Take(10));
            if (result.YamaPlayerChanges.Length > 0)
            {
                result.Ok = false; result.Code = "FAILED";
                result.Message = "既存のYamaPlayerまたは画面に変更が検出されました。Undo（Ctrl+Z）で元に戻し、シーンを保存しないでください。\nA change of the existing YamaPlayer or screen was detected. Undo it and do not save the scene.\n" + string.Join("\n", result.YamaPlayerChanges.Take(10));
            }
            else if (!result.Ok) result.Message = "一部の参照を設定できませんでした（YamaPlayer 1.5.18・1.5.19 の ScreenUI を前提にしています）。\nSome references could not be set (the setup expects the ScreenUI of YamaPlayer 1.5.18 / 1.5.19).";
            return result;
        }

        // What an explicit re-run would write to the existing DM objects (derived references only). Nothing is written.
        public static string[] PreviewRepair(Scene scene) { return MyListProductSetup.Preview(scene); }

        static Result RunUnchecked(Scene scene, Controller chosen)
        {
            var result = new Result();
            Scan scan = Analyze(scene);
            if (scan.Players.Length == 0)
            {
                result.Code = "NO_YAMAPLAYER";
                result.YamaPlayer = scan.PlayersWithoutUi.Length > 0 ? "Found, but its screen UI (UIController) is not in the scene" : "Not found";
                result.Message = "YamaPlayerがScene内に見つかりません。\n先にYamaPlayerをSceneへ配置してください。\n\nNo YamaPlayer was found in the scene. Place a YamaPlayer first.";
                return result; // nothing is placed
            }
            result.YamaPlayer = "Detected" + (scan.Players.Length > 1 ? " (" + scan.Players.Length + ")" : "");

            if (scan.Views.Length == 0)
            {
                Controller target = scan.Players.Length == 1 ? scan.Players[0] : chosen;
                if (target == null || !scan.Players.Contains(target))
                {
                    result.Code = "CHOOSE_YAMAPLAYER";
                    result.Message = "YamaPlayerが複数あります。対象を選んでください。\nThe scene has several YamaPlayers. Choose the one to use.";
                    return result; // none is picked automatically, nothing is placed
                }
                GameObject prefab = Prefab();
                if (!prefab) { result.Code = "NO_PREFAB"; result.Message = "PersistentMyList.prefab was not found. Install DM YamaPlayer Local Playlist again."; return result; }
                GameObject yamaRoot = MyListProductSetup.YamaRoot(target);
                // A normal prefab instance (not unpacked), as its own root object next to the YamaPlayer.
                var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
                Undo.RegisterCreatedObjectUndo(instance, MyListProductSetup.UndoName);
                instance.transform.position = yamaRoot.transform.position;
                if (yamaRoot.transform.parent == null) instance.transform.SetSiblingIndex(yamaRoot.transform.GetSiblingIndex() + 1);
                var view = instance.GetComponent<MyListPersistentView>();
                if (scan.Players.Length > 1)
                {
                    var so = new SerializedObject(view);
                    so.FindProperty("targetYamaPlayer").objectReferenceValue = yamaRoot;
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                EditorSceneManager.MarkSceneDirty(scene);
                result.View = view; result.MyList = "Placed"; result.Code = "PLACED";
            }
            else
            {
                result.View = scan.Views[0];
                result.MyList = scan.Views.Length == 1 ? "Already placed" : "Already placed: " + scan.Views.Length + " objects (nothing was removed)";
                result.Code = "CHECKED";
            }

            string[] before = scan.Views.Length > 0 ? scan.Views.SelectMany(MissingReferences).ToArray() : new string[0];
            string report;
            try { report = MyListProductSetup.ConfigureScene(scene); }
            catch (System.Exception ex) { result.Code = "FAILED"; result.Message = ex.Message; result.References = "Failed"; return result; }

            var after = Analyze(scene);
            var views = after.Views;
            result.Missing = views.Concat(after.ExtraViews).SelectMany(MissingReferences).Distinct().ToArray();
            if (before.Length > 0 && result.Missing.Length == 0) { result.Code = "REPAIRED"; result.MyList += " (repaired: " + before.Distinct().Count() + " reference(s))"; }
            result.References = result.Missing.Length == 0 ? "Configured" : "Missing: " + string.Join(", ", result.Missing);
            result.F1b = F1bStatus(views.Concat(after.ExtraViews));
            result.Ok = result.Missing.Length == 0;
            if (!result.Ok) result.Message = "一部の参照を設定できませんでした（YamaPlayer 1.5.18・1.5.19 の画面構成を前提にしています）。\nSome references could not be set (the setup expects the screen layout of YamaPlayer 1.5.18 / 1.5.19).\n" + report;
            else if (views.Length > 1 && views.Length > scan.Players.Length)
                result.Message = "PersistentMyList が " + views.Length + " 個あります（YamaPlayer は " + scan.Players.Length + " 個）。余分なものは手動で削除してください。自動では削除しません。\nThere are more PersistentMyList objects than YamaPlayers. Nothing was removed.";
            return result;
        }

        // F1b "play again" panel: retryHost (the parent of YamaPlayer's error panel) and the DM panel parts. This says
        // only that the panel can be shown; whether F1b acts also depends on WebUnit at runtime and on the separate F1b
        // capability of the compatibility check. Not a required reference: without it everything else works as before.
        public static string F1bStatus(IEnumerable<MyListPersistentView> views)
        {
            var list = views.Where(v => v).ToArray();
            if (list.Length == 0) return "";
            int ready = list.Count(v => v.retryHost && v.retryPanel && v.retryButton && v.retryButtonText && v.retryText);
            string note = " (F1b also needs WebUnit on PC; see the compatibility check)";
            return ready == list.Length ? "Panel set on " + ready + " screen(s)" + note
                : "Panel not set on " + (list.Length - ready) + " of " + list.Length + " screen(s) (YamaPlayer error panel or DM Play Again panel not found)" + note;
        }

        public static string Summary(Result result)
        {
            string detail;
            MyListWebUnitSetup.Forget();
            MyListWebUnitSummary web = MyListWebUnitSetup.Read(out detail);
            return "YamaPlayer: " + result.YamaPlayer + (result.Compatibility != "" ? "\nYamaPlayer version: " + result.Compatibility : "") + (result.Protection != "" ? "\nExisting YamaPlayer data: " + result.Protection : "") +
                "\nPersistentMyList: " + result.MyList + "\nReferences: " + result.References + (result.F1b != "" ? "\nF1b (play again) panel: " + result.F1b : "") +
                "\nWebUnit: " + web.Current + (web.Status != "" ? " (" + web.Status + ")" : "") + "\nPC Extension: " + web.PcExtension;
        }

        [MenuItem(MenuRoot + "自動配置・セットアップ (Auto Setup)", false, 1000)]
        static void AutoSetupMenu() { MyListAutoSetupWindow.Open(); }

        [MenuItem(MenuRoot + "Documentation", false, 1200)]
        static void DocumentationMenu()
        {
            var readme = AssetDatabase.LoadAssetAtPath<Object>(ReadmePath);
            if (readme) { Selection.activeObject = readme; EditorGUIUtility.PingObject(readme); AssetDatabase.OpenAsset(readme); }
            else EditorUtility.DisplayDialog(Title, "Documentation/README.md was not found.", "OK");
        }
    }

    public class MyListAutoSetupWindow : EditorWindow
    {
        const string Title = "DM YamaPlayer Local Playlist";
        MyListAutoSetup.Result result;
        int chosenPlayer = -1;
        Controller lastChosen;
        bool wantModified;        // the WebUnit choice shown in the window; starts at what the project has (official by default)
        bool choiceTouched;
        string applied = "";
        string screenNote = "";   // result of the last "also show on this screen"
        Vector2 scroll;

        public static void Open()
        {
            var window = GetWindow<MyListAutoSetupWindow>(true, "DM YamaPlayer Local Playlist - 自動配置・セットアップ", true);
            window.minSize = new Vector2(520, 520);
            window.Begin();
            window.Show();
        }

        // What the one click does: with exactly one YamaPlayer and no PersistentMyList it places and configures at once.
        void Begin()
        {
            result = null; applied = ""; screenNote = ""; choiceTouched = false; chosenPlayer = -1;
            Scene scene = SceneManager.GetActiveScene();
            var scan = MyListAutoSetup.Analyze(scene);
            if (scan.Players.Length == 0) { result = MyListAutoSetup.Run(scene, null); return; }
            if (scan.Views.Length > 0)
            {
                // Shown before anything is written: the references a repair would set. Saved playlists, the save keys
                // and every other setting of the existing object are not part of a repair.
                string[] pending = MyListAutoSetup.PreviewRepair(scene);
                string diff = pending.Length == 0 ? "変更が必要な参照はありません（確認のみ）。 / Nothing needs to be changed (check only)."
                    : "次の参照を設定し直します / These references will be set:\n" + string.Join("\n", pending.Take(12)) + (pending.Length > 12 ? "\n… (" + pending.Length + ")" : "");
                if (!EditorUtility.DisplayDialog(Title,
                    "DM YamaPlayer Local Playlistは\nすでにこのSceneに配置されています。\n\n既存オブジェクトの設定を確認・修復しますか？\n" +
                    "保存済みのプレイリストや既存の設定は初期化しません。YamaPlayer は変更しません。\n\n" + diff + "\n\n" +
                    "It is already placed in this scene. Check / repair the existing setup? Saved data and settings are not reset.", "設定を確認 / 修復", "キャンセル")) { Close(); return; }
                result = MyListAutoSetup.Run(scene, null);
                return;
            }
            if (scan.Players.Length == 1) result = MyListAutoSetup.Run(scene, null);
            // several YamaPlayers: the window asks which one
        }

        void OnGUI()
        {
            Scene scene = SceneManager.GetActiveScene();
            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.LabelField("自動配置・セットアップ / Auto Setup", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Scene", string.IsNullOrEmpty(scene.path) ? "(unsaved scene)" : scene.path);
            EditorGUILayout.Space();

            bool busy = EditorApplication.isCompiling || EditorApplication.isPlayingOrWillChangePlaymode;
            if (result == null || result.Code == "CHOOSE_YAMAPLAYER")
            {
                var scan = MyListAutoSetup.Analyze(scene);
                if (scan.Players.Length <= 1 || scan.Views.Length > 0)
                {
                    // e.g. after a script reload: nothing is done until the user asks again
                    using (new EditorGUI.DisabledScope(busy))
                        if (GUILayout.Button("自動配置・セットアップを実行 / Run Auto Setup", GUILayout.Height(28))) { Begin(); GUIUtility.ExitGUI(); }
                    EditorGUILayout.EndScrollView();
                    return;
                }
                EditorGUILayout.HelpBox("YamaPlayerが複数あります。対象を選んでください。\nThe scene has several YamaPlayers. Choose the one to use.", MessageType.Info);
                string[] names = scan.Players.Select(p => Label(MyListProductSetup.YamaRoot(p).transform)).ToArray();
                chosenPlayer = GUILayout.SelectionGrid(chosenPlayer, names, 1, EditorStyles.radioButton);
                using (new EditorGUI.DisabledScope(busy || chosenPlayer < 0 || chosenPlayer >= scan.Players.Length))
                    if (GUILayout.Button("このYamaPlayerに配置・セットアップ / Set up for this YamaPlayer", GUILayout.Height(28)))
                    { lastChosen = scan.Players[chosenPlayer]; result = MyListAutoSetup.Run(scene, lastChosen); }
                EditorGUILayout.EndScrollView();
                return;
            }

            EditorGUILayout.LabelField("YamaPlayer", result.YamaPlayer);
            if (result.Compatibility != "") EditorGUILayout.LabelField("YamaPlayer version", result.Compatibility);
            if (result.Protection != "") EditorGUILayout.LabelField("Existing YamaPlayer data", result.Protection);
            if (result.MyList != "") EditorGUILayout.LabelField("PersistentMyList", result.MyList);
            if (result.References != "") EditorGUILayout.LabelField("References", result.References);
            if (result.F1b != "") EditorGUILayout.LabelField("F1b (play again) panel", result.F1b);
            if (result.Message != "") EditorGUILayout.HelpBox(result.Message, result.Ok ? MessageType.Warning : MessageType.Error);
            if (!result.Ok)
            {
                if (result.Code == "UNVERIFIED_YAMAPLAYER")
                    using (new EditorGUI.DisabledScope(busy))
                        if (GUILayout.Button("未確認のバージョンで続行（動作保証なし） / Continue with the unverified version", GUILayout.Height(26)) &&
                            EditorUtility.DisplayDialog(Title, result.Message + "\n\n続行しますか？ / Continue?", "続行 / Continue", "キャンセル / Cancel"))
                        { result = MyListAutoSetup.Run(scene, lastChosen, true); GUIUtility.ExitGUI(); }
                using (new EditorGUI.DisabledScope(busy)) if (GUILayout.Button("もう一度確認 / Check again")) Begin();
                EditorGUILayout.EndScrollView();
                return;
            }
            if (result.View && GUILayout.Button("配置したオブジェクトを選択 / Select the object")) { Selection.activeGameObject = result.View.gameObject; EditorGUIUtility.PingObject(result.View.gameObject); }

            // ---- additional screens of the same YamaPlayer (SubScreen, tablet controller ...) ----
            var screens = MyListAutoSetup.Analyze(scene);
            if (screens.ExtraScreens.Length > 0)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("追加の操作画面 / Additional screens", EditorStyles.boldLabel);
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField("同じ YamaPlayer を操作する画面が他にもあります。選んだ画面にも Local Playlist と Seek ボタンを表示できます。" +
                        "保存データと再生は PersistentMyList のものを共有します（追加されるのは表示用のオブジェクトだけです）。", EditorStyles.wordWrappedLabel);
                    EditorGUILayout.LabelField("Other screens control the same YamaPlayer. The Local Playlist and the seek buttons can be shown there too; data and playback are shared.", EditorStyles.wordWrappedMiniLabel);
                    foreach (var screen in screens.ExtraScreens)
                    {
                        bool has = !screens.ExtraScreensWithoutUi.Contains(screen);
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            EditorGUILayout.LabelField(Label(MyListProductSetup.ScreenRoot(screen).transform), has ? "配置済み / Placed" : "未配置 / Not placed");
                            using (new EditorGUI.DisabledScope(busy || has))
                                if (GUILayout.Button("この画面にも表示 / Show here too", GUILayout.Width(200)))
                                {
                                    var added = MyListAutoSetup.AddScreenUi(scene, screen);
                                    screenNote = Label(MyListProductSetup.ScreenRoot(screen).transform) + ": " + added.Code + (added.References != "" ? " / References: " + added.References : "") +
                                        (added.Protection != "" ? "\nExisting YamaPlayer data: " + added.Protection : "") + (added.Message != "" ? "\n" + added.Message : "");
                                    GUIUtility.ExitGUI();
                                }
                        }
                    }
                    if (screenNote != "") EditorGUILayout.HelpBox(screenNote, MessageType.Info);
                }
            }

            // ---- WebUnit choice (project-wide) ----
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("WebUnitを選択 / Choose the WebUnit", EditorStyles.boldLabel);
            string detail;
            MyListWebUnitSummary web = MyListWebUnitSetup.Read(out detail);
            if (!choiceTouched) wantModified = web.Modified; // official unless the project already uses the DM Client
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("DM YamaPlayer Local Playlistは、どちらのWebUnitでも使用できます。", EditorStyles.wordWrappedLabel);
                EditorGUILayout.HelpBox(MyListWebUnitSetup.ProjectWideNote, MessageType.None);
                EditorGUILayout.LabelField("Current WebUnit", web.Current + (web.Status != "" ? "  —  " + web.Status : ""));
                bool selectable = web.CanInstall || web.CanRestore || web.Modified;
                if (!web.Payload) { EditorGUILayout.HelpBox(MyListWebUnitSetup.NotIncludedNote, MessageType.Info); if (!web.Modified) wantModified = false; }
                using (new EditorGUI.DisabledScope(!selectable || busy))
                {
                    bool official = GUILayout.Toggle(!wantModified, " Official YamachanWebUnit", EditorStyles.radioButton);
                    EditorGUILayout.LabelField("      標準構成です。追加変更なし。 / Standard. Nothing is changed.", EditorStyles.miniLabel);
                    bool modified;
                    using (new EditorGUI.DisabledScope(!web.Payload && !web.Modified))
                        modified = GUILayout.Toggle(wantModified, " DM Modified WebUnit v5.4 (PC)", EditorStyles.radioButton);
                    EditorGUILayout.LabelField("      PC向けの再生改善版です。Unityプロジェクト全体のWebUnitを変更します。", EditorStyles.miniLabel);
                    EditorGUILayout.LabelField("      PC playback improvement. Changes the WebUnit of the whole Unity project.", EditorStyles.miniLabel);
                    if (official && wantModified) { wantModified = false; choiceTouched = true; }
                    else if (modified && !wantModified) { wantModified = true; choiceTouched = true; }
                }
                EditorGUILayout.LabelField("※ " + MyListWebUnitSetup.AndroidNote, EditorStyles.wordWrappedMiniLabel);
                if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneWindows64)
                    EditorGUILayout.HelpBox("現在のビルドターゲットは " + EditorUserBuildSettings.activeBuildTarget + " です。このターゲットのビルドでは PC Extension（追加 Transport B〜K と PC 向け再生改善処理）は有効になりません。DM Modified WebUnit を導入すると、改変 Client のプログラム自体はこのビルドにも含まれます。\nFor the current target the PC Extension is not active; the modified Client program itself is still part of the build when the DM Modified WebUnit is installed.", MessageType.Info);
                if (!selectable) EditorGUILayout.HelpBox(web.Current + (web.Status != "" ? " — " + web.Status : "") + "\n" + detail, web.Level == MessageType.Info ? MessageType.Info : web.Level);
                if (wantModified && web.Modified) EditorGUILayout.LabelField(web.CanUpdate ? "更新があります。 / An update is available." : OlderWithoutUpdate(web) ? OlderNote : "DM Modified WebUnit v5.4は、すでに最新です。 / Already up to date.", EditorStyles.wordWrappedLabel);
                using (new EditorGUI.DisabledScope(busy))
                using (new EditorGUILayout.HorizontalScope())
                {
                    string apply = wantModified && web.CanUpdate ? "Update" : "適用 / Apply";
                    if (GUILayout.Button(apply, GUILayout.Height(28))) { ApplyChoice(web); GUIUtility.ExitGUI(); }
                    if (GUILayout.Button("キャンセル / Cancel", GUILayout.Height(28))) { Close(); GUIUtility.ExitGUI(); }
                }
            }

            if (applied != "")
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("DM YamaPlayer Local Playlist セットアップ完了 / Setup complete", EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(MyListAutoSetup.Summary(result) + (applied != "-" ? "\n\n" + applied : ""), MessageType.Info);
                if (GUILayout.Button("閉じる / Close")) { Close(); GUIUtility.ExitGUI(); }
            }
            EditorGUILayout.EndScrollView();
        }

        // An older verified DM Client, and this build of the add-on has no Client to update it with.
        static bool OlderWithoutUpdate(MyListWebUnitSummary web) { return web.Modified && !web.CanUpdate && web.Status.StartsWith("OLDER REVISION"); }
        const string OlderNote = "古い版の DM Modified WebUnit です（このパッケージには更新用の Client がありません）。 / An older DM Modified WebUnit revision; this package has no update for it.";

        // The only place of the setup that can change the WebUnit, and only as chosen here.
        void ApplyChoice(MyListWebUnitSummary web)
        {
            if (!wantModified)
            {
                if (web.Modified)
                {
                    // Official was chosen while the DM Client is installed: the installer's warning asks first, never restored silently.
                    applied = "Official WebUnit: " + MyListWebUnitInstaller.RestoreWithDialog();
                }
                else applied = "Official WebUnit: nothing was changed.";
            }
            else
            {
                if (web.State == MyListWebUnitInstaller.State.Official) applied = "DM Modified WebUnit v5.4: " + MyListWebUnitInstaller.InstallWithDialog();
                else if (web.Modified && web.CanUpdate) applied = "DM Modified WebUnit v5.4: " + MyListWebUnitInstaller.UpdateWithDialog();
                else if (web.Modified && OlderWithoutUpdate(web)) applied = OlderNote + " Nothing was written.";
                else if (web.Modified) applied = "DM Modified WebUnit v5.4は、すでに最新です。 / Already up to date. Nothing was written.";
                else applied = "The WebUnit of this project cannot be changed here: " + web.Current + ".";
            }
            MyListWebUnitSetup.Forget();
            choiceTouched = false;
            Repaint();
        }

        static string Label(Transform t)
        {
            string path = t.name;
            for (Transform p = t.parent; p != null; p = p.parent) path = p.name + "/" + path;
            return " " + path;
        }

        void OnInspectorUpdate() { Repaint(); } // the WebUnit state is re-read while the window is open
    }
}
