# NOTICE — DM YamaPlayer Local Playlist

© 2026 DISPLAY_MONITOR（第三者に属する部分を除きます）

## 利用条件 / Terms

利用条件は、同梱の **LICENSE.md**（利用規約。日本語版が正本）に従います。英語の参考訳は **LICENSE.en.md** です。
The terms of use are in **LICENSE.md** (Japanese, authoritative) and **LICENSE.en.md** (English reference translation).

正規の配布元 / Official source: `https://displaymonitor.github.io/dm-vpm/index.json`

## 一緒に使う第三者のソフトウェア

このパッケージは、次のソフトウェアと一緒に使います。下の「YamachanWebUnit について」に書いた改変版の Client を除き、どのファイルもこのパッケージには含まれていません。VCC・ALCOM が各作者の配布元から導入します。それぞれの作者の規約・ライセンスに従って使ってください。このパッケージの作者は、これらのソフトウェアについて何も許諾しません。

- **YamaPlayer**（`net.kwxxw.yama-stream` 1.5.18・1.5.19）— やま@kwxxw 氏 — https://yamadev.booth.pm ／ 配布元 https://vpm.kwxxw.net/index.json
- **YamachanWebUnit**（`net.kwxxw.yamachan-web-unit` 1.1.0）— kwxxw 氏 — 配布元 https://vpm.kwxxw.net/index.json
- **VRChat SDK - Worlds**（3.10.5 以上）— VRChat Inc.

### YamaPlayer の UI について

`Prefabs/` の画面の行は、YamaPlayer の UI の行を元に作った構造です。YamaPlayer の画像・フォント・アニメーター・スクリプトを参照していますが、それらのファイル自体は含みません。

クレジット：**YamaPlayer — やま@kwxxw 氏（https://yamadev.booth.pm）**

### YamachanWebUnit について

このパッケージは、公式の YamachanWebUnit 1.1.0 で動作します。公式の YamachanWebUnit のファイルは含みません（VCC・ALCOM が配布元から導入します）。

このパッケージは、YamachanWebUnit 1.1.0 の `Runtime/Client.cs` を改変したファイル **`WebUnit/Client.dm-v5.6.cs.txt`（DM Modified WebUnit v5.6）** を含みます。1.1.1 で同梱していた v5.5（1.1.0 までの v5.4 に変更を加えたもの）に、さらに変更を加えたものです。

- YamachanWebUnit の作者から個別に再配布の許可を得て、同梱しています。許可の対象には、公開 VPM への同梱と、他の利用者への配布が含まれます。
- このファイルは、このパッケージの作者が改変した**非公式の版**です。YamachanWebUnit の公式の版ではなく、YamachanWebUnit の作者が動作を保証するものではありません。このファイルに関する不具合を YamachanWebUnit の作者に問い合わせないでください。
- このファイルのうち YamachanWebUnit に由来する部分の権利は、YamachanWebUnit の権利者に属します。このパッケージの作者は、その部分について利用者に何も許諾しません。
- このファイルは、利用者が次のどれかを操作したときにだけ、プロジェクトの YamachanWebUnit の `Runtime/Client.cs` に書き込まれます（どれも書き込みの前に確認の画面が出ます）：WebUnit の設定欄（Auto Setup・インスペクター）で「DM Modified WebUnit (PC)」を選ぶ、インスペクターの「Install DM Modified WebUnit v5.6」「Update Modified WebUnit」、メニューの「Install or Update Modified WebUnit」。公式のファイルは、書き込みの前に `DMYamaPlayerPersistentMyList_Backup/` に退避され、「Restore Official WebUnit」で戻せます。
- 以前の改変版（v5.5・v5.4・v5.2）は含みません。導入済みの v5.5・v5.4 などは「Update Modified WebUnit」で v5.6 に更新されます。
- このファイルの冒頭のコメントにある「personal use only, not for redistribution」は、再配布の許可を得る前に書いた注記です（ファイルの内容を変えないため、そのまま残しています）。このファイルは、上に書いたとおり、YamachanWebUnit の権利者の許可によって同梱しています。

## このパッケージの作者が作ったもの

- `Icons/` の 4 点は、このパッケージの作者が新たに作ったものです（既存の画像の加工ではありません）。
- `Runtime/*.asset` は、このパッケージのコードから UdonSharp が生成したデータです。
