using UdonSharp;
using VRC.SDK3.Components.Video;
using VRC.Udon;

namespace DM.YamaMyList
{
    // DM Modified WebUnit v5.6: answer relay of one transport player (B, C, ...). It is never placed by hand: the DM
    // build step (MyListModifiedWebUnitBuild) adds one to each DM transport object of a v5.6 Client while a world is
    // built for Windows, and it exists only in that build. It forwards the player's answer (ready / start / end /
    // error) of a LoadURL to the Client (DmTransportReady / Start / End / Error, one event per kind: the
    // Client keeps a per-player state from them) and says once that it is there (DmTransportRelayReady),
    // so that the Client never calls LoadURL on a player that has not answered. It never calls the player itself.
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class DmWebUnitTransportRelay : UdonSharpBehaviour
    {
        public UdonBehaviour client; // the WebUnit Client (its Udon behaviour)
        public int slot;             // 1 = transport player B, 2 = C, ... (0 is the Client's own player A)

        void Start()
        {
            if (client == null) return;
            client.SetProgramVariable("DmTransportAnswer", slot);
            client.SendCustomEvent("DmTransportRelayReady");
        }

        void Answer(string clientEvent)
        {
            if (client == null) return;
            client.SetProgramVariable("DmTransportAnswer", slot);
            client.SendCustomEvent(clientEvent);
        }

        public override void OnVideoReady() { Answer("DmTransportReady"); }
        public override void OnVideoStart() { Answer("DmTransportStart"); }
        public override void OnVideoEnd() { Answer("DmTransportEnd"); }
        public override void OnVideoError(VideoError videoError) { Answer("DmTransportError"); }
    }
}
