namespace DM.YamaMyList
{
    // Automatic retry (Docs/AUTO_RETRY_SPEC.md): the pure rules of its state machine. No Unity, no Udon state, no
    // network: MyListPersistentView keeps the state and calls these, so the rules are tested on their own
    // (Tests/AutoRetry). It retries a failed WebUnit track of DM's playlist during continuous playback, on this client
    // only (YamaPlayer's own reload: no shared URL, no sync). It does not fix the cause (PLAYBACK-01) and never skips.
    public static class MyListAutoRetryRules
    {
        // Phases
        public const int Off = 0;       // no failure of the current track is being handled
        public const int Waiting = 1;   // failed: the next attempt is due at a time
        public const int Loading = 2;   // DM's reload is in flight: waiting for a start or an error
        public const int Done = 3;      // no more automatic attempts for this track (used up, cancelled, manual, no response)

        // Fixed by the spec (2026-11-03): at most 3 attempts after the first playback, 10 s / 15 s / 20 s after a failure.
        public const int MaxAttempts = 3;
        // A due attempt waits while YamaPlayer is loading or the WebUnit Client is sending; it looks again every 5 s and
        // gives up after 120 s (no attempt used). An attempt with neither a start nor an error after 120 s ends the
        // automatic retry (no attempt added, the manual "play again" stays), unless YamaPlayer still loads it (below).
        public const float BusyRecheckSeconds = 5f;
        public const float BusyCeilingSeconds = 120f;
        public const float LoadCeilingSeconds = 120f;
        // PLAYBACK-01 (2026-11-11): the result of an attempt came 138-183 s after it, and YamaPlayer was still loading
        // at 120 s every time. So at 120 s an attempt that YamaPlayer is still loading is watched further, every 5 s, up
        // to 300 s after the attempt. An attempt that is not loading at 120 s, or that was cancelled (a mode change or
        // the manual press), still ends there. Only the automatic retry; the first playback and the manual "play
        // again" keep their 120 s (MyListPlayAgainRules).
        public const float LoadExtendRecheckSeconds = 5f;
        public const float LoadExtendMaxSeconds = 300f;

        // The wait before attempt `used + 1` (used = attempts already made for this track).
        public static float WaitSeconds(int used)
        {
            if (used <= 0) return 10f;
            if (used == 1) return 15f;
            return 20f;
        }

        // All conditions under which a failure of the current track may be retried automatically.
        // target: a WebUnit YouTube track (no VRCUrl; YamaPlayer's own retry then always cancels itself, YAMA-RETRY-001).
        // continuous: DM's playlist slot is the active playlist with a track index, auto forward on, loop off.
        // supported: every YamaPlayer / WebUnit member this needs was found, and the WebUnit Client drops a request on a
        // stop (DM Modified WebUnit v5.5 or later). Anything missing means off (fail closed).
        // stopped: the manual "play again" was used for this track (manual has priority), or a mode change cancelled the
        // retry; automatic attempts do not come back for this track.
        public static bool Eligible(bool target, bool continuous, bool supported, bool stopped)
        {
            return target && continuous && supported && !stopped;
        }

        // The phase after an error of the current track. A duplicate notice while waiting changes nothing.
        public static int OnError(int phase, int used, bool eligible)
        {
            if (phase == Waiting || phase == Done) return phase;
            if (!eligible) return Done;
            return used < MaxAttempts ? Waiting : Done;
        }

        // What the due timer does. preconditions: same track, not stopped, not playing, YamaPlayer not in a reload, the
        // player type matches the track, and still eligible.
        public const int DueIgnore = 0;    // not waiting (cancelled or handled): nothing
        public const int DueFire = 1;      // make the attempt now
        public const int DueRecheck = 2;   // loading or busy: look again later, no attempt used
        public const int DueGiveUp = 3;    // busy for too long, or the preconditions no longer hold: Done

        public static int OnDue(int phase, bool preconditions, bool loadingOrBusy, float secondsSinceDue)
        {
            if (phase != Waiting) return DueIgnore;
            if (!preconditions) return DueGiveUp;
            if (loadingOrBusy) return secondsSinceDue < BusyCeilingSeconds ? DueRecheck : DueGiveUp;
            return DueFire;
        }

        // The load ceiling timer of an attempt still waiting for a start or an error (from 120 s after the attempt).
        public const int CeilIgnore = 0;    // not loading an attempt (a start, an error, a stop or another track came first)
        public const int CeilRecheck = 1;   // YamaPlayer still loads it: look again later (within 300 s of the attempt)
        public const int CeilDone = 2;      // the automatic retry ends; the manual "play again" follows

        public static int OnLoadCeiling(int phase, bool cancelled, bool loading, float secondsSinceAttempt)
        {
            if (phase != Loading) return CeilIgnore;
            if (!cancelled && loading && secondsSinceAttempt < LoadExtendMaxSeconds) return CeilRecheck;
            return CeilDone;
        }

        // The delay until the next look while the ceiling is extended: 5 s, never beyond 300 s after the attempt.
        public static float CeilingRecheckDelay(float secondsSinceAttempt)
        {
            float left = LoadExtendMaxSeconds - secondsSinceAttempt;
            return left < LoadExtendRecheckSeconds ? (left > 0f ? left : 0f) : LoadExtendRecheckSeconds;
        }

        // A start of playback ends every retry state (success): back to Off with no attempt used. A stop by the user or
        // another track also goes back to Off (the view resets).
        // A change of loop / shuffle / slide / karaoke / playlists, or the manual "play again", cancels what is still to
        // come: a waiting retry becomes Done. An attempt already loading is never aborted and stays Loading, so its
        // ceiling still watches it (a cancelled attempt is not extended: Done at 120 s, or at the next 5 s look once
        // extended) and its failure or silence still reaches the manual "play again" (nothing stops silently); the view
        // marks it cancelled, so no further attempt follows and its line is no longer shown.
        public static int OnCancel(int phase)
        {
            return phase == Waiting ? Done : phase;
        }

        // What the panel line shows for the automatic retry.
        public const int ShowNothing = 0;
        public const int ShowWaiting = 1;   // "retrying automatically (n/3)" before the attempt
        public const int ShowLoading = 2;   // "retrying automatically (n/3)" while it loads

        public static int Display(int phase, bool cancelled)
        {
            if (cancelled) return ShowNothing;
            if (phase == Waiting) return ShowWaiting;
            if (phase == Loading) return ShowLoading;
            return ShowNothing;
        }

        // Delayed events carry no arguments: the view keeps one set of timer data per timer and acts only when the
        // generation is the one the timer was made for and its due time has been reached (as MyListPlayAgainRules).
        public static int TimerCheck(int gen, int timerGen, float now, float due)
        {
            if (gen != timerGen) return MyListPlayAgainRules.TimerStale;
            return now >= due ? MyListPlayAgainRules.TimerDue : MyListPlayAgainRules.TimerEarly;
        }
    }
}
