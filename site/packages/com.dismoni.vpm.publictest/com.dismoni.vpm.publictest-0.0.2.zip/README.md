# DM VPM Public Test (dummy) 0.0.2

Second version (0.0.2): this text differs from 0.0.1.

Test fixture for the DIS_MONI public VPM listing. It contains no code and no assets.
Safe to remove.
